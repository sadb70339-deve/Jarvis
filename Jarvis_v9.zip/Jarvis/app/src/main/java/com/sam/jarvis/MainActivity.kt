package com.sam.jarvis
import android.Manifest
import android.animation.ObjectAnimator
import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.provider.AlarmClock
import android.provider.ContactsContract
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val BLUE = Color.rgb(77, 171, 255)
    private val BTN = Color.rgb(100, 180, 255)
    private val INK = Color.rgb(8, 20, 36)
    private val GRAY = Color.rgb(150, 155, 170)
    private val h = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleV: TextView
    private lateinit var drawerLayer: FrameLayout
    private var drawerOpen = false
    private var rightOpen = false
    private var page = "home"
    private var searchQ = ""
    private var statusV: TextView? = null
    private var replyV: TextView? = null
    private var heardV: TextView? = null
    private var dtV: TextView? = null
    private var topBox: View? = null
    private var rowBox: View? = null
    private var micLbl: TextView? = null
    private var chatBox: LinearLayout? = null
    private var chatScroll: ScrollView? = null
    private var chatShown = 0
    private var tickN = 0
    private var typed = 0
    private var typedFor = ""
    private var dx0 = 0f
    private var tracking = false
    private val samples = ArrayList<DoubleArray>()
    private val phrases = listOf("Hey Jarvis, it's me. Good to see you.", "The quick brown fox jumps over the lazy dog.", "Open YouTube and play something relaxing.", "Remind me to drink water every two hours.", "Jarvis, what is on my schedule for tomorrow?")

    // ---------- helpers ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun glass(a: Int = 22, s: Int = 55, r: Int = 16) = GradientDrawable().apply { setColor(Color.argb(a, 255, 255, 255)); setStroke(dp(1), Color.argb(s, 120, 190, 255)); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun serif(t: String, size: Float) = tv(t, size).apply { typeface = Typeface.SERIF; gravity = Gravity.CENTER }
    private fun sec(t: String) = tv(t, 11f, BLUE, true).apply { letterSpacing = 0.15f; setPadding(0, dp(18), 0, dp(6)) }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun lp(w: Int = -1, ht: Int = -2, m: Int = 8) = LinearLayout.LayoutParams(w, ht).apply { setMargins(0, dp(m), 0, 0) }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun pf() = Brain.prefs(this)
    private fun speak(r: String) { JarvisService.inst?.say(r) }
    private fun scroll(v: View) = ScrollView(this).apply { addView(v); isVerticalScrollBarEnabled = false }
    private fun fmt(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    private fun short(s: String) = if (s.isEmpty()) "Not set" else if (s.length > 16) s.take(16) + "…" else s
    private fun btn(t: String, filled: Boolean = true, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (filled) INK else BLUE)
        background = if (filled) GradientDrawable().apply { setColor(BTN); cornerRadius = dp(14).toFloat() } else glass()
        setOnClickListener { f() }
    }
    private fun field(hint: String, text: String = "") = EditText(this).apply { setHint(hint); setHintTextColor(GRAY); setTextColor(Color.WHITE); background = glass(18, 60, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); setText(text); textSize = 15f }
    private fun card(vararg v: View) = col().apply { background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12)); v.forEach { addView(it) } }
    private fun builder() = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
    private fun AlertDialog.Builder.dshow(): AlertDialog {
        val d = create()
        d.window?.setBackgroundDrawable(GradientDrawable().apply { setColor(Color.rgb(12, 18, 28)); setStroke(dp(1), Color.argb(90, 100, 180, 255)); cornerRadius = dp(20).toFloat() })
        d.show(); return d
    }
    private fun pickTime(hh: Int, mm: Int, cb: (Int, Int) -> Unit) { TimePickerDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK, { _, a, b -> cb(a, b) }, hh, mm, false).show() }
    private fun editDialog(title: String, key: String) {
        val e = field(title, pf().getString(key, if (key == "lmodel") "gemini-3.1-flash-live-preview" else if (key == "gmodel") "gemini-flash-latest" else if (key == "dmodel") "gemini-pro-latest" else "") ?: "")
        builder().setTitle(title).setView(e).setPositiveButton("Save") { _, _ -> pf().edit().putString(key, e.text.toString().trim()).apply(); go(page) }.setNegativeButton("Cancel", null).dshow()
    }
    private fun listDialog(title: String, items: List<String>, pick: (Int) -> Unit) { builder().setTitle(title).setItems(items.toTypedArray()) { _, i -> pick(i) }.dshow() }
    private fun mask(k: String) = if ((pf().getString(k, "") ?: "").isEmpty()) "Not set" else "••••••"
    private fun item(icon: String, title: String, sub: String, value: String = "", click: (() -> Unit)? = null): View {
        val r = LinearLayout(this).apply { background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12)); gravity = Gravity.CENTER_VERTICAL }
        r.addView(tv(icon, 18f).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(45, 77, 171, 255)) } }, LinearLayout.LayoutParams(dp(40), dp(40)))
        val mid = col().apply { setPadding(dp(12), 0, dp(8), 0); addView(tv(title, 15f)); if (sub.isNotEmpty()) addView(tv(sub, 12f, GRAY)) }
        r.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        if (value.isNotEmpty()) r.addView(tv(value, 13f, BLUE))
        r.addView(tv("›", 20f, GRAY).apply { setPadding(dp(8), 0, 0, 0) })
        if (click != null) r.setOnClickListener { click() }
        return r
    }
    private fun rowCard(text: String, right: String = "", click: (() -> Unit)? = null, onLong: (() -> Unit)? = null): View {
        val r = LinearLayout(this).apply { background = glass(); setPadding(dp(14), dp(14), dp(14), dp(14)); gravity = Gravity.CENTER_VERTICAL }
        r.addView(tv(text, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (right.isNotEmpty()) r.addView(tv(right, 13f, BLUE))
        if (click != null) r.setOnClickListener { click() }
        if (onLong != null) r.setOnLongClickListener { onLong(); true }
        return r
    }
    private fun animateIn(v: View) {
        val g: ViewGroup = ((v as? ScrollView)?.getChildAt(0) as? ViewGroup) ?: (v as? ViewGroup) ?: return
        for (i in 0 until g.childCount) { val ch = g.getChildAt(i); ch.alpha = 0f; ch.translationY = dp(24).toFloat(); ch.animate().alpha(1f).translationY(0f).setStartDelay(i * 45L).setDuration(280).start() }
    }

    // ---------- lifecycle ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        Sound.on = pf().getBoolean("snd", true)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val shell = col()
        topBar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(36), dp(14), dp(6)) }
        topBar.addView(tv("≡", 28f, BLUE).apply { gravity = Gravity.CENTER; setOnClickListener { openDrawer() } }, LinearLayout.LayoutParams(dp(44), -2))
        titleV = tv("Jarvis", 20f).apply { typeface = Typeface.SERIF; gravity = Gravity.CENTER }
        topBar.addView(titleV, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(tv("⚡", 22f, BLUE).apply { gravity = Gravity.CENTER; setOnClickListener { openActivity() } }, LinearLayout.LayoutParams(dp(44), -2))
        topBar.addView(tv("⚙", 22f, BLUE).apply { gravity = Gravity.CENTER; setOnClickListener { go("setup") } }, LinearLayout.LayoutParams(dp(44), -2))
        shell.addView(topBar)
        content = FrameLayout(this)
        shell.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        drawerLayer = FrameLayout(this).apply { visibility = View.GONE }
        val boot = FrameLayout(this).apply { setBackgroundColor(Color.rgb(2, 8, 15)); isClickable = true }
        boot.addView(CoreView(this, true), FrameLayout.LayoutParams(-1, -1))
        val bs = tv("INITIALIZING...", 12f, BLUE).apply { gravity = Gravity.CENTER; letterSpacing = 0.3f }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = ColorStateList.valueOf(BLUE); progressBackgroundTintList = ColorStateList.valueOf(Color.argb(40, 255, 255, 255)) }
        ObjectAnimator.ofInt(bar, "progress", 0, 100).setDuration(3800).start()
        val bc = col().apply {
            gravity = Gravity.CENTER
            addView(tv("J.A.R.V.I.S", 30f, Color.WHITE, true).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); gravity = Gravity.CENTER; letterSpacing = 0.25f })
            addView(tv("Just A Rather Very Intelligent System", 11f, BLUE).apply { gravity = Gravity.CENTER; letterSpacing = 0.12f; setPadding(0, dp(10), 0, dp(40)) })
            addView(bs)
            addView(bar, LinearLayout.LayoutParams(dp(220), dp(6)).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, dp(12), 0, 0) })
        }
        boot.addView(bc, FrameLayout.LayoutParams(-1, -1))
        root.addView(shell); root.addView(drawerLayer); root.addView(boot)
        setContentView(root)
        if (pf().getBoolean("onboarded", false)) { ensureService(); go("home") } else onboard(0)
        Sound.start(this)
        greetLoop(true, 0)
        h.postDelayed({ bs.text = "SYSTEMS ONLINE" }, 2800)
        h.postDelayed({ boot.animate().alpha(0f).setDuration(700).withEndAction { boot.visibility = View.GONE }.start() }, 4000)
        h.post(object : Runnable {
            override fun run() {
                val st = Brain.state
                statusV?.let { v ->
                    v.text = when (st) { "listening" -> "Listening..."; "thinking" -> "Thinking..."; "speaking" -> "J.A.R.V.I.S is speaking..."; else -> if (Brain.waiting()) "Waiting for your yes / no" else "Tap to speak" }
                    v.textSize = if (st == "idle") 14f else 22f; v.setTextColor(if (st == "idle") GRAY else BLUE)
                }
                val act = st != "idle"
                topBox?.visibility = if (act) View.GONE else View.VISIBLE
                rowBox?.visibility = if (act) View.GONE else View.VISIBLE
                micLbl?.text = if (act) "Tap to stop" else "Tap to speak"
                heardV?.text = if (st == "listening" && Brain.heard.isNotEmpty()) "You: " + Brain.heard else ""
                replyV?.let { r ->
                    val t = Brain.lastReply
                    if (t != typedFor) { typedFor = t; typed = 0 }
                    if (typed < t.length) { typed = minOf(t.length, typed + 8); r.text = t.substring(0, typed) }
                }
                if (++tickN % 25 == 0) {
                    dtV?.text = SimpleDateFormat("EEE, d MMM\nh:mm a", Locale.getDefault()).format(Date())
                    if (page == "chat") chatBox?.let { b -> val l = Brain.chatLog(this@MainActivity); if (l.size != chatShown) { chatShown = l.size; fillChat(b, l) } }
                }
                h.postDelayed(this, 40)
            }
        })
    }
    private fun ensureService() { if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) try { startForegroundService(Intent(this, JarvisService::class.java)) } catch (e: Exception) {} }
    private fun greetLoop(first: Boolean, n: Int) {
        if (!pf().getBoolean("onboarded", false)) return
        h.postDelayed({ val sv = JarvisService.inst; if (sv != null && sv.sayGreeting()) return@postDelayed; if (n < 15) greetLoop(false, n + 1) }, if (first) 4200L else 800L)
    }
    override fun onBackPressed() { if (drawerOpen) closeDrawer() else if (topBar.visibility == View.VISIBLE && page != "home") go("home") else super.onBackPressed() }
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (topBar.visibility == View.VISIBLE) when (e.action) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; tracking = drawerOpen || e.x < dp(28) || e.x > resources.displayMetrics.widthPixels - dp(28) }
            MotionEvent.ACTION_UP -> {
                if (tracking) {
                    val d = e.x - dx0; val W = resources.displayMetrics.widthPixels
                    if (!drawerOpen && dx0 < dp(28) && d > dp(70)) openDrawer()
                    else if (!drawerOpen && dx0 > W - dp(28) && d < -dp(70)) openActivity()
                    else if (drawerOpen && !rightOpen && d < -dp(70)) closeDrawer()
                    else if (drawerOpen && rightOpen && d > dp(70)) closeDrawer()
                }
                tracking = false
            }
        }
        return super.dispatchTouchEvent(e)
    }

    // ---------- navigation ----------
    private fun go(name: String) {
        page = name; statusV = null; replyV = null; heardV = null; dtV = null; topBox = null; rowBox = null; micLbl = null; chatBox = null; chatScroll = null; topBar.visibility = View.VISIBLE
        titleV.text = when (name) { "home" -> "Jarvis"; "today" -> "Today"; "reminders" -> "Reminders"; "memory" -> "Memory"; "history" -> "Action history"; "creator" -> "Creator"; "report" -> "Weekly report"; "search" -> "Search"; "voice" -> "Voice lock"; "profile" -> "Profile"; "chat" -> "Chat"; "perm" -> "App permissions"; "quick" -> "Quick Tools"; "notes" -> "Notes"; else -> "Settings" }
        content.removeAllViews()
        val v = when (name) { "home" -> home(); "today" -> today(); "reminders" -> reminders(); "memory" -> memory(); "history" -> history(); "creator" -> creator(); "report" -> report(); "search" -> search(); "voice" -> voice(); "profile" -> profile(); "chat" -> chat(); "perm" -> perm(); "quick" -> quick(); "notes" -> notes(); else -> setup() }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
        if (name != "home") animateIn(v)
    }
    private fun openDrawer() {
        drawerOpen = true; rightOpen = false; drawerLayer.removeAllViews(); drawerLayer.visibility = View.VISIBLE
        val w = (resources.displayMetrics.widthPixels * 0.8f).toInt()
        drawerLayer.addView(View(this).apply { setBackgroundColor(Color.argb(150, 0, 0, 0)); setOnClickListener { closeDrawer() } }, FrameLayout.LayoutParams(-1, -1))
        val panel = col().apply { setBackgroundColor(Color.argb(247, 4, 10, 18)); setPadding(dp(16), dp(44), dp(16), dp(16)); isClickable = true }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("◎", 32f, BLUE).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setStroke(dp(1), Color.argb(120, 120, 190, 255)) } }, LinearLayout.LayoutParams(dp(52), dp(52)))
        head.addView(col().apply { setPadding(dp(12), 0, 0, 0); addView(tv("J.A.R.V.I.S", 20f, Color.WHITE, true)); addView(tv("Just A Rather Very Intelligent System", 10f, GRAY)) })
        panel.addView(head)
        val sf = field("Search memory & history").apply { imeOptions = EditorInfo.IME_ACTION_SEARCH; setSingleLine(true) }
        sf.setOnEditorActionListener { _, _, _ -> searchQ = sf.text.toString().trim(); closeDrawer(); go("search"); true }
        panel.addView(sf, lp(-1, -2, 14))
        val lst = col()
        listOf("🏠  Home" to "home", "💬  Chat" to "chat", "⚡  Quick Tools" to "quick", "📅  Today" to "today", "⏰  Reminders" to "reminders", "📝  Notes" to "notes", "🧠  Memory" to "memory", "🕘  Action history" to "history", "🎬  Creator" to "creator", "📊  Weekly report" to "report", "⚙  Settings" to "setup").forEach { (l, pg) ->
            lst.addView(tv(l, 16f, if (page == pg) Color.WHITE else GRAY, page == pg).apply {
                setPadding(dp(14), dp(13), dp(14), dp(13)); if (page == pg) background = glass(30, 70, 12)
                setOnClickListener { closeDrawer(); go(pg) }
            }, lp(-1, -2, 3))
        }
        panel.addView(scroll(lst), LinearLayout.LayoutParams(-1, 0, 1f))
        val me = (pf().getString("uname", "") ?: "").ifEmpty { "You" }
        val prof = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = glass(); setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { closeDrawer(); go("profile") } }
        prof.addView(tv(me.take(1).uppercase(), 16f, INK, true).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BTN) } }, LinearLayout.LayoutParams(dp(38), dp(38)))
        prof.addView(tv(me, 15f).apply { setPadding(dp(12), 0, 0, 0) })
        panel.addView(prof, lp(-1, -2, 8))
        panel.addView(tv("⏻  Exit", 15f, GRAY).apply { setPadding(dp(14), dp(12), dp(14), dp(4)); setOnClickListener { finishAffinity() } })
        drawerLayer.addView(panel, FrameLayout.LayoutParams(w, -1))
        panel.translationX = -w.toFloat(); panel.animate().translationX(0f).setDuration(200).start()
    }
    private fun closeDrawer() {
        drawerOpen = false
        if (drawerLayer.childCount > 1) { val p = drawerLayer.getChildAt(1); p.animate().translationX(if (rightOpen) p.width.toFloat() else -p.width.toFloat()).setDuration(170).withEndAction { drawerLayer.visibility = View.GONE }.start() } else drawerLayer.visibility = View.GONE
        rightOpen = false
    }
    private fun cardView(cd: Tools.Card): View {
        val c = col().apply { background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        c.addView(tv(cd.title, 15f, Color.WHITE, true))
        if (cd.detail.isNotEmpty()) c.addView(tv(cd.detail, 13f, GRAY))
        cd.url?.let { u -> c.addView(btn("Open", false) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast("Can't open") } }, lp(-1, -2, 6)) }
        cd.code?.let { code ->
            c.addView(tv(code, 12f, Color.rgb(170, 220, 255)).apply { typeface = Typeface.MONOSPACE; setPadding(0, dp(8), 0, dp(4)) })
            c.addView(btn("Copy", false) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", code)); toast("Copied") }, lp(-1, -2, 4))
        }
        return c
    }
    private fun openActivity() {
        drawerOpen = true; rightOpen = true; drawerLayer.removeAllViews(); drawerLayer.visibility = View.VISIBLE
        val w = (resources.displayMetrics.widthPixels * 0.86f).toInt()
        drawerLayer.addView(View(this).apply { setBackgroundColor(Color.argb(150, 0, 0, 0)); setOnClickListener { closeDrawer() } }, FrameLayout.LayoutParams(-1, -1))
        val panel = col().apply { setBackgroundColor(Color.argb(247, 6, 12, 20)); setPadding(dp(16), dp(44), dp(16), dp(16)); isClickable = true }
        panel.addView(tv("Activity", 24f).apply { typeface = Typeface.SERIF })
        panel.addView(tv("What Jarvis is doing for you", 12f, GRAY))
        val list = col()
        if (Tools.cards.isEmpty()) list.addView(tv("Nothing yet. Ask Jarvis to open an app, call someone or write some code.", 14f, GRAY).apply { setPadding(0, dp(16), 0, 0) })
        Tools.cards.forEach { cd -> list.addView(cardView(cd), lp(-1, -2, 8)) }
        panel.addView(scroll(list), LinearLayout.LayoutParams(-1, 0, 1f))
        drawerLayer.addView(panel, FrameLayout.LayoutParams(w, -1, Gravity.END))
        panel.translationX = w.toFloat(); panel.animate().translationX(0f).setDuration(200).start()
    }

    // ---------- pages ----------
    private fun circ(t: String, size: Int, filled: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; gravity = Gravity.CENTER; setTextColor(if (filled) INK else BLUE)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; if (filled) setColor(BTN) else { setColor(Color.argb(22, 255, 255, 255)); setStroke(dp(1), Color.argb(90, 120, 190, 255)) } }
        setOnClickListener { f() }
    }.also { it.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(14), 0, dp(14), 0) } }

    private fun home(): View = col().apply {
        setPadding(dp(18), 0, dp(18), dp(10))
        val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val gw = if (hr < 12) "Good Morning" else if (hr < 17) "Good Afternoon" else "Good Evening"
        val top = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(col().apply { addView(tv("$gw, ${Brain.title(this@MainActivity)}", 22f)); addView(tv("How can I assist you today?", 13f, GRAY)) }, LinearLayout.LayoutParams(0, -2, 1f))
        val dt = tv(SimpleDateFormat("EEE, d MMM\nh:mm a", Locale.getDefault()).format(Date()), 13f, BLUE).apply { gravity = Gravity.END }
        dtV = dt; top.addView(dt)
        topBox = top; addView(top, lp(-1, -2, 4))
        addView(CoreView(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
        val sv0 = tv("", 14f, GRAY).apply { gravity = Gravity.CENTER; letterSpacing = 0.05f }
        statusV = sv0; addView(sv0)
        val hv = tv("", 13f, GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(2)) }
        heardV = hv; addView(hv)
        val rv0 = tv("", 16f).apply { gravity = Gravity.CENTER; minHeight = dp(72); setPadding(dp(14), dp(10), dp(14), dp(10)); background = glass(14, 40, 16) }
        replyV = rv0; addView(rv0, lp(-1, -2, 6))
        val mic = circ("🎤", 72, true) {
            val sv = JarvisService.inst
            if (sv == null) toast("Finish setup / Activate Jarvis first") else if (Brain.state != "idle") sv.stopSpeak() else sv.wakeNow()
        }
        addView(mic, LinearLayout.LayoutParams(dp(72), dp(72)).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, dp(10), 0, 0) })
        val ml = tv("Tap to speak", 12f, GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(8)) }
        micLbl = ml; addView(ml)
        val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER }
        fun q(icon: String, label: String, f: () -> Unit) { row.addView(col().apply { gravity = Gravity.CENTER_HORIZONTAL; addView(circ(icon, 52, false) { f() }); addView(tv(label, 11f, GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }) }, LinearLayout.LayoutParams(0, -2, 1f)) }
        q("💬", "Chat") { go("chat") }; q("⚡", "Quick") { go("quick") }; q("🧰", "Tools") { openActivity() }; q("⋯", "More") { openDrawer() }
        rowBox = row; addView(row)
    }

    private fun today(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val w = Brain.water(this); val goal = 8
        c.addView(sec("WATER"))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = ColorStateList.valueOf(BLUE); progressBackgroundTintList = ColorStateList.valueOf(Color.argb(40, 255, 255, 255)) }
        ObjectAnimator.ofInt(bar, "progress", 0, minOf(100, w * 100 / goal)).setDuration(800).start()
        c.addView(card(tv("$w / $goal glasses", 22f, Color.WHITE, true), bar, btn("+ 1 glass") { Brain.addWater(this); go("today") }), lp())
        c.addView(sec("DAILY CARE  (tap to mark done)"))
        listOf("Breakfast" to "mealB", "Lunch" to "mealL", "Dinner" to "mealD", "Workout" to "workout").forEach { (l, k) ->
            c.addView(rowCard(l, if (Care.doneToday(this, k)) "Done ✓" else "Not yet", { Care.log(this, k); Brain.hist(this, "$l done"); go("today") }), lp(-1, -2, 6))
        }
        c.addView(sec("TASKS  (tap = done, long-press = delete)"))
        val tk = Brain.tasks(this)
        for (i in 0 until tk.length()) { val o = tk.getJSONObject(i)
            c.addView(rowCard((if (o.getBoolean("d")) "✓ " else "") + o.getString("t"), if (o.getString("o") == "jarvis") "Jarvis" else "You", { Brain.toggleTask(this, i); go("today") }, { Brain.delTask(this, i); go("today") }), lp(-1, -2, 6)) }
        if (tk.length() == 0) c.addView(tv("No tasks. Tell Jarvis: add a task for me.", 13f, GRAY))
        c.addView(sec("DONE TODAY"))
        val l = Brain.histList(this, true).reversed()
        if (l.isEmpty()) c.addView(tv("Nothing yet.", 14f, GRAY))
        l.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }
    private fun reminders(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(btn("+ Add reminder") {
            val e = field("What should I remind you about?")
            builder().setView(e).setPositiveButton("Pick time") { _, _ -> pickTime(8, 0) { hh, mm -> Brain.addRem(this, hh, mm, e.text.toString().ifEmpty { "reminder" }, true); go("reminders") } }.dshow()
        }, lp())
        c.addView(tv("Tap = change time   ·   Long-press = delete", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val a = Brain.rems(this)
        for (i in 0 until a.length()) { val o = a.getJSONObject(i)
            val row = LinearLayout(this).apply { background = glass(); setPadding(dp(14), dp(14), dp(14), dp(14)); gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv("%02d:%02d".format(o.getInt("h"), o.getInt("m")), 20f, BLUE, true).apply { setPadding(0, 0, dp(16), 0) })
            row.addView(tv(o.getString("text"), 15f), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(tv(if (o.getBoolean("daily")) "daily" else "once", 11f, GRAY))
            row.setOnClickListener { pickTime(o.getInt("h"), o.getInt("m")) { hh, mm -> Brain.editRem(this, i, hh, mm); go("reminders") } }
            row.setOnLongClickListener { Brain.delRem(this, i); go("reminders"); true }
            c.addView(row, lp(-1, -2, 6)) }
        if (a.length() == 0) c.addView(tv("No reminders yet. Say: \"Remind me at 8:30 to drink water\".", 14f, GRAY))
        return scroll(c)
    }
    private fun memory(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(btn("+ Add memory") {
            val e = field("What should Jarvis remember?")
            builder().setView(e).setPositiveButton("Save") { _, _ -> if (e.text.isNotBlank()) { Brain.addMem(this, e.text.toString().trim()); go("memory") } }.dshow()
        }, lp())
        c.addView(tv("Long-press to delete. Jarvis asks before saving anything on his own.", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val m = Brain.mem(this)
        for (i in 0 until m.length()) c.addView(rowCard(m.getString(i), "", null, { Brain.delMem(this, i); go("memory") }), lp(-1, -2, 6))
        if (m.length() == 0) c.addView(tv("Nothing saved yet.", 14f, GRAY))
        return scroll(c)
    }
    private fun history(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val l = Brain.histList(this, false).takeLast(60).reversed()
        if (l.isEmpty()) c.addView(tv("Nothing yet.", 14f, GRAY))
        l.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }
    private fun creator(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(tv("Say: \"Get this motivational video ready for Instagram\". Tap a draft to copy it.", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val l = Brain.creator(this)
        if (l.isEmpty()) c.addView(tv("No drafts yet.", 14f, GRAY))
        l.forEach { d -> c.addView(rowCard(d, "", { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", d)); toast("Copied") }), lp(-1, -2, 8)) }
        return scroll(c)
    }
    private fun report(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val (ok, no) = Brain.week(this)
        c.addView(sec("LAST 7 DAYS"))
        c.addView(rowCard("Tasks done", "$ok"), lp()); c.addView(rowCard("Tasks missed", "$no"), lp(-1, -2, 6)); c.addView(rowCard("Water today", "${Brain.water(this)} glasses"), lp(-1, -2, 6))
        c.addView(tv("Tell Jarvis at night: \"Task done: edited video\" or \"Task missed: gym\".", 12f, GRAY).apply { setPadding(0, dp(12), 0, 0) })
        return scroll(c)
    }
    private fun search(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val q = searchQ.lowercase(); val res = ArrayList<String>()
        val m = Brain.mem(this); for (i in 0 until m.length()) if (m.getString(i).lowercase().contains(q)) res.add("Memory: " + m.getString(i))
        Brain.histList(this, false).reversed().forEach { if (it.lowercase().contains(q)) res.add(it) }
        c.addView(tv("Results for \"$searchQ\"", 13f, GRAY))
        if (res.isEmpty()) c.addView(tv("Nothing found.", 14f, GRAY).apply { setPadding(0, dp(10), 0, 0) })
        res.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }

    private fun rulesDialog() {
        val l = Brain.rules(this)
        if (l.isEmpty()) { builder().setTitle("Jarvis rules").setMessage("No rules yet. Tell Jarvis: from now on, always...").setPositiveButton("OK", null).dshow(); return }
        listDialog("Tap a rule to delete it", l) { i -> Brain.delRule(this, i); go("setup") }
    }
    private fun upgradesDialog() {
        val l = Brain.upgrades(this)
        val msg = if (l.isEmpty()) "No requests yet. Tell Jarvis: I want you to be able to..." else l.joinToString("\n\n") { "• $it" }
        builder().setTitle("Upgrade requests").setMessage(msg + "\n\nGive this list to Claude to build the next version.")
            .setPositiveButton("Copy") { _, _ -> (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", msg)); toast("Copied") }.setNegativeButton("Close", null).dshow()
    }
    override fun onResume() { super.onResume(); if (::content.isInitialized && page == "perm") go("perm") }
    private fun fillChat(b: LinearLayout, l: List<Triple<Long, String, String>>) {
        b.removeAllViews()
        if (l.isEmpty()) b.addView(tv("No messages yet. Say \"Jarvis\" or type below.", 14f, GRAY))
        val f = SimpleDateFormat("h:mm a", Locale.getDefault())
        l.forEach { (ts, who, text) ->
            val me = who == "YOU"
            val bub = col().apply {
                setPadding(dp(14), dp(10), dp(14), dp(8))
                background = if (me) GradientDrawable().apply { setColor(BTN); cornerRadius = dp(16).toFloat() } else glass()
                addView(tv(text, 15f, if (me) INK else Color.WHITE)); addView(tv(f.format(Date(ts)), 10f, if (me) INK else GRAY).apply { gravity = Gravity.END })
            }
            b.addView(bub, LinearLayout.LayoutParams(-2, -2).apply { setMargins(if (me) dp(60) else 0, dp(6), if (me) 0 else dp(60), 0); gravity = if (me) Gravity.END else Gravity.START })
        }
        chatScroll?.post { chatScroll?.fullScroll(View.FOCUS_DOWN) }
    }
    private fun chat(): View {
        val root = col().apply { setPadding(dp(18), dp(4), dp(18), dp(10)) }
        val box = col(); chatBox = box
        val sv = scroll(box); chatScroll = sv
        val l = Brain.chatLog(this); chatShown = l.size; fillChat(box, l)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val e = field("Type a message...")
        row.addView(e, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(circ("➤", 46, true) {
            val q = e.text.toString().trim()
            if (q.isNotEmpty()) { e.setText(""); val s = JarvisService.inst; if (s != null) s.typeToJarvis(q) else Brain.handle(this, q) { r -> speak(r) } }
        })
        root.addView(row, lp(-1, -2, 8))
        root.addView(btn("Delete chat (memory stays)", false) { Brain.clearChat(this); go("chat") }, lp(-1, -2, 6))
        return root
    }
    private fun quick(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        fun r(icon: String, t: String, sub: String, f: () -> Unit) = c.addView(item(icon, t, sub, "", f), lp(-1, -2, 6))
        r("📱", "Open Apps", "Launch your favorite apps") { openAppsDialog() }
        r("🎛", "System Controls", "Wi-Fi, Bluetooth, display, sound...") {
            val acts = listOf(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_BLUETOOTH_SETTINGS, Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SOUND_SETTINGS, Settings.ACTION_AIRPLANE_MODE_SETTINGS, Settings.ACTION_LOCATION_SOURCE_SETTINGS, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            listDialog("System Controls", listOf("Wi-Fi", "Bluetooth", "Display", "Sound", "Airplane mode", "Location", "Battery")) { i -> try { startActivity(Intent(acts[i])) } catch (e: Exception) { toast("Can't open") } }
        }
        r("📞", "Phone Controls", "Calls, messages, contacts") {
            listDialog("Phone", listOf("Dialer", "Contacts", "Messages")) { i ->
                try { startActivity(when (i) { 0 -> Intent(Intent.ACTION_DIAL); 1 -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI); else -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")) }) } catch (e: Exception) { toast("Can't open") }
            }
        }
        r("📅", "Calendar", "View your schedule") { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://com.android.calendar/time/" + System.currentTimeMillis()))) } catch (e: Exception) { toast("No calendar app found") } }
        r("📝", "Notes", "Create or view notes") { go("notes") }
        r("⏰", "Reminders", "Manage your reminders") { go("reminders") }
        r("🔔", "Alarms", "Open the phone's alarms") { try { startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS)) } catch (e: Exception) { toast("No alarm app found") } }
        r("⚙", "Settings", "Device & app settings") { go("setup") }
        return scroll(c)
    }
    private fun openAppsDialog() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
        listDialog("Open app", apps.map { it.loadLabel(pm).toString() }) { i -> try { startActivity(pm.getLaunchIntentForPackage(apps[i].activityInfo.packageName)) } catch (e: Exception) { toast("Can't open") } }
    }
    private fun notes(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(btn("+ New note") {
            val e = field("Write a note")
            builder().setView(e).setPositiveButton("Save") { _, _ -> if (e.text.isNotBlank()) { Brain.addNote(this, e.text.toString().trim()); go("notes") } }.dshow()
        }, lp())
        c.addView(tv("Long-press to delete. You can also say: note this down.", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val l = Brain.notes(this)
        l.forEachIndexed { i, n -> c.addView(rowCard(n, "", null, { Brain.delNote(this, i); go("notes") }), lp(-1, -2, 6)) }
        if (l.isEmpty()) c.addView(tv("No notes yet.", 14f, GRAY))
        return scroll(c)
    }
    private fun perm(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        fun ok(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        fun r(icon: String, t: String, sub: String, on: Boolean, f: () -> Unit) = c.addView(item(icon, t, sub, if (on) "On ✓" else "Off", f), lp(-1, -2, 6))
        c.addView(tv("Tap an item to turn it on or off. Jarvis reads your screen only when you ask, and never passwords.", 13f, GRAY).apply { setPadding(0, dp(6), 0, dp(6)) })
        r("🎤", "Microphone", "Hear you", ok(Manifest.permission.RECORD_AUDIO)) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3) }
        r("📞", "Phone calls", "Call people when you ask", ok(Manifest.permission.CALL_PHONE)) { requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 3) }
        r("👥", "Contacts", "Find numbers by name", ok(Manifest.permission.READ_CONTACTS)) { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 3) }
        r("🔔", "Notifications", "Reminders and care nudges", Build.VERSION.SDK_INT < 33 || ok(Manifest.permission.POST_NOTIFICATIONS)) { if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3) }
        r("🪟", "Display over other apps", "Open apps while the screen is on", Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        r("⏰", "Alarms & timers", "Set phone alarms for you", true) { toast("Always allowed") }
        r("♿", "Accessibility (screen control)", "Read, tap, scroll and type in other apps", JarvisAccess.inst != null) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        r("🔋", "Battery unrestricted", "Keeps Jarvis alive in the background", pm.isIgnoringBatteryOptimizations(packageName)) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        return scroll(c)
    }

    private fun profile(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        fun r(icon: String, t: String, sub: String, v: String, f: () -> Unit) = c.addView(item(icon, t, sub, v, f), lp(-1, -2, 6))
        c.addView(sec("ABOUT YOU"))
        r("👤", "Name", "What Jarvis calls you", short(pf().getString("uname", "") ?: "")) { editDialog("Your name", "uname") }
        r("💬", "Address me as", "Sir, Bhai, Sam...", pf().getString("title", "Sir") ?: "Sir") { editDialog("Address me as", "title") }
        r("📝", "About me", "Work, goals, anything Jarvis should know", short(pf().getString("about", "") ?: "")) { editDialog("About me", "about") }
        c.addView(sec("DAILY ROUTINE"))
        r("⏰", "Wake-up time", "Care reminders start after this", fmt(pf().getInt("wakeMin", 420))) { val m = pf().getInt("wakeMin", 420); pickTime(m / 60, m % 60) { a, b -> pf().edit().putInt("wakeMin", a * 60 + b).apply(); go("profile") } }
        r("🌙", "Sleep time", "Care reminders stop before this", fmt(pf().getInt("sleepMin", 1380))) { val m = pf().getInt("sleepMin", 1380); pickTime(m / 60, m % 60) { a, b -> pf().edit().putInt("sleepMin", a * 60 + b).apply(); go("profile") } }
        c.addView(sec("HEALTH"))
        r("💪", "Fitness goal", "e.g. lose weight, build muscle", short(pf().getString("fgoal", "") ?: "")) { editDialog("Fitness goal", "fgoal") }
        r("🍽", "Food preference", "e.g. no sugar, high protein", short(pf().getString("food", "") ?: "")) { editDialog("Food preference", "food") }
        return scroll(c)
    }

    private fun setup(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        fun r(icon: String, t: String, sub: String, v: String = "", f: () -> Unit) = c.addView(item(icon, t, sub, v, f), lp(-1, -2, 6))
        val prov = pf().getString("provider", "gemini")
        val me = (pf().getString("uname", "") ?: "").ifEmpty { "Your name" }
        val pc = LinearLayout(this).apply { background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(95, 77, 171, 255), Color.argb(18, 77, 171, 255))).apply { setStroke(dp(1), Color.argb(120, 120, 190, 255)); cornerRadius = dp(22).toFloat() }; setPadding(dp(16), dp(16), dp(16), dp(16)); gravity = Gravity.CENTER_VERTICAL; setOnClickListener { go("profile") } }
        pc.addView(tv(me.take(1).uppercase(), 22f, INK, true).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(BTN) } }, LinearLayout.LayoutParams(dp(56), dp(56)))
        pc.addView(col().apply { setPadding(dp(14), 0, 0, 0); addView(tv(me, 18f, Color.WHITE, true)); addView(tv("Edit your profile  ›", 13f, BLUE)) })
        c.addView(pc, lp(-1, -2, 4))
        c.addView(sec("PERSONALIZATION"))
        r("🎙", "Voice", "Charon is the deepest, Jarvis-like voice", pf().getString("lvoice", "Charon") ?: "Charon") {
            listDialog("Voice", listOf("Charon - deep, calm", "Puck - bright, quick", "Kore - warm, steady", "Fenrir - bold, direct", "Aoede - light, airy", "Zephyr - soft, easy")) { i -> pf().edit().putString("lvoice", listOf("Charon", "Puck", "Kore", "Fenrir", "Aoede", "Zephyr")[i]).apply(); go("setup"); toast("Applies from the next conversation") }
        }
        r("⚡", "Live conversation", "Fast voice chat with Gemini Live", if (pf().getBoolean("live", true)) "On" else "Off") { pf().edit().putBoolean("live", !pf().getBoolean("live", true)).apply(); go("setup") }
        r("🌐", "Web research", "Jarvis can search Google to learn and teach you", if (pf().getBoolean("lsearch", true)) "On" else "Off") { pf().edit().putBoolean("lsearch", !pf().getBoolean("lsearch", true)).apply(); go("setup") }
        r("⏩", "Speaking speed", "How fast Jarvis talks", "%.2fx".format(pf().getFloat("lspeed", 1.15f))) {
            listDialog("Speed", listOf("Normal (1.0x)", "Fast (1.15x)", "Faster (1.3x)", "Very fast (1.5x)")) { i -> pf().edit().putFloat("lspeed", listOf(1.0f, 1.15f, 1.3f, 1.5f)[i]).apply(); JarvisService.inst?.applyVoice(); go("setup") }
        }
        r("📜", "Jarvis rules", "Things you taught Jarvis", "${Brain.rules(this).size}") { rulesDialog() }
        r("🛠", "Upgrade requests", "Abilities Jarvis asked for", "${Brain.upgrades(this).size}") { upgradesDialog() }
        r("🎭", "Mode", "How Jarvis talks to you", Brain.mode(this)) { val ms = listOf("work", "normal", "friend", "creator", "silent"); listDialog("Mode", ms) { i -> pf().edit().putString("mode", ms[i]).apply(); go("setup") } }
        r("🌐", "Language", "Roman Urdu + English mix by default", when (pf().getString("lang", "mix")) { "english" -> "English"; "roman" -> "Roman Urdu"; "hindi" -> "Hindi"; else -> "Mix" }) {
            listDialog("Jarvis speaks", listOf("English", "Roman Urdu", "Hindi", "Roman Urdu + English")) { i -> pf().edit().putString("lang", listOf("english", "roman", "hindi", "mix")[i]).apply(); go("setup") }
        }
        r("🔊", "Startup sound", "Plays every time the app opens", if (Sound.on) "On" else "Off") { Sound.on = !Sound.on; pf().edit().putBoolean("snd", Sound.on).apply(); go("setup") }
        c.addView(sec("DAILY CARE"))
        r("💧", "Water, meals & fitness", "Jarvis reminds you on his own and learns your timings", if (pf().getBoolean("care", true)) "On" else "Off") { pf().edit().putBoolean("care", !pf().getBoolean("care", true)).apply(); go("setup") }
        r("👤", "Profile & routine", "Wake-up, sleep, fitness goal, food", "") { go("profile") }
        c.addView(sec("AI BRAIN"))
        r("🧠", "Provider", "Gemini has a free key", if (prov == "gemini") "Gemini" else "Claude") { pf().edit().putString("provider", if (prov == "gemini") "claude" else "gemini").apply(); go("setup") }
        r("🔑", "Gemini key", "aistudio.google.com", mask("gkey")) { editDialog("Gemini key", "gkey") }
        r("🧩", "Gemini model", "Change if replies fail", short(pf().getString("gmodel", "gemini-flash-latest") ?: "")) { editDialog("Gemini model", "gmodel") }
        r("🧩", "Live model", "Change if Live stops working", short(pf().getString("lmodel", "gemini-3.1-flash-live-preview") ?: "")) { editDialog("Live model", "lmodel") }
        r("🧠", "Deep thinking model", "Used for hard questions and coding", short(pf().getString("dmodel", "gemini-pro-latest") ?: "")) { editDialog("Deep thinking model", "dmodel") }
        r("🔑", "Claude key", "console.anthropic.com", mask("key")) { editDialog("Claude key", "key") }
        r("🎤", "ElevenLabs key", "Optional fallback voice", mask("elkey")) { editDialog("ElevenLabs key", "elkey") }
        c.addView(sec("VOICE LOCK"))
        r("🔒", "Only my voice", "Best-effort, not a security lock", if (VoiceLock.enabled(this)) "On" else "Off") {
            if (VoiceLock.load(this) == null) { toast("Set up your voice first"); samples.clear(); go("voice") }
            else { pf().edit().putBoolean("vlock", !pf().getBoolean("vlock", false)).apply(); JarvisService.inst?.applyLock(); go("setup") }
        }
        r("🎚", "Set up / redo my voice", "Record 5 short phrases", "") { samples.clear(); go("voice") }
        r("⚖", "Strictness", "Loose, normal or strict", pf().getString("vstrict", "normal") ?: "normal") { listDialog("Strictness", listOf("loose", "normal", "strict")) { i -> pf().edit().putString("vstrict", listOf("loose", "normal", "strict")[i]).apply(); go("setup") } }
        r("🧪", "Test my voice", "Speak for 3 seconds", "") { runTest() }
        r("📋", "Last live check", VoiceLock.status.take(30), "") { builder().setTitle("Last live check").setMessage(VoiceLock.status).setPositiveButton("OK", null).dshow() }
        r("🗑", "Delete my voice", "", "") { VoiceLock.delete(this); pf().edit().putBoolean("vlock", false).apply(); JarvisService.inst?.applyLock(); go("setup") }
        c.addView(sec("PERMISSIONS & SYSTEM"))
        r("🛂", "App permissions", "Mic, calls, contacts, accessibility, screen access", "") { go("perm") }
        r("⚡", "Activate Jarvis", "Mic, calls, contacts, notifications", "") { start() }
        r("🔋", "Battery", "Set Jarvis to Unrestricted", "") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        r("🛡", "Smart Lock / security", "Keep phone unlocked at home or with earbuds", "") { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        c.addView(sec("DATA"))
        r("☁", "Backup", "Your Google account backs up settings and memory", "") { builder().setTitle("Backup").setMessage("Turn on Settings > Google > Backup. If the app is reinstalled, your settings, memory and reminders come back.").setPositiveButton("OK", null).dshow() }
        c.addView(sec("ABOUT"))
        r("ℹ", "About J.A.R.V.I.S", "Just A Rather Very Intelligent System", "v9") { builder().setTitle("J.A.R.V.I.S").setMessage("Just A Rather Very Intelligent System\nVersion 9").setPositiveButton("OK", null).dshow() }
        r("🔁", "Restart setup", "Run the first-time steps again", "") { pf().edit().putBoolean("onboarded", false).apply(); onboard(0) }
        return scroll(c)
    }

    // ---------- voice lock ----------
    private fun withMic(sec: Int, done: (ShortArray?) -> Unit) {
        JarvisService.inst?.pauseListening(true); VoiceLock.stopCapture()
        Thread {
            val x: ShortArray? = try { VoiceLock.record(sec) } catch (e: Exception) { null }
            runOnUiThread { JarvisService.inst?.pauseListening(false); JarvisService.inst?.applyLock(); done(x) }
        }.start()
    }
    private fun runTest() {
        toast("Speak for 3 seconds...")
        withMic(3) { x -> builder().setTitle("Voice test").setMessage(if (x == null) "Mic is busy. Try again." else VoiceLock.evaluate(this, x)).setPositiveButton("OK", null).dshow() }
    }
    private fun voice(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(tv("Jarvis will answer only your voice. Record 5 short phrases in a quiet place. This is best-effort matching, not a security lock.", 13f, GRAY))
        val n = samples.size
        c.addView(tv(if (n < 5) "Say:\n\"${phrases[n]}\"" else "All 5 phrases recorded.", 18f).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(28), dp(8), dp(28)) })
        c.addView(btn(if (n < 5) "Record phrase ${n + 1} of 5 (5 sec)" else "Save my voice") {
            if (n >= 5) {
                VoiceLock.save(this, VoiceLock.build(samples)); samples.clear()
                pf().edit().putBoolean("vlock", true).apply(); JarvisService.inst?.applyLock(); toast("Voice saved. Voice lock is on."); go("setup")
            } else {
                toast("Recording... speak now")
                withMic(5) { x ->
                    val v = if (x == null) null else VoiceLock.features(x)
                    if (v == null) toast("Too quiet or too short, try again") else samples.add(v)
                    if (page == "voice") go("voice")
                }
            }
        }, lp(-1, dp(52), 8))
        if (n > 0) c.addView(btn("Start over", false) { samples.clear(); go("voice") }, lp(-1, -2, 8))
        return scroll(c)
    }

    // ---------- onboarding ----------
    private fun obCol(step: Int, title: String, body: String) = col().apply {
        gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(26), dp(50), dp(26), dp(26))
        if (step > 0) addView(tv("STEP $step OF 5", 11f, GRAY).apply { letterSpacing = 0.2f; gravity = Gravity.CENTER })
        addView(serif(title, 26f), lp(-1, -2, 12))
        if (body.isNotEmpty()) addView(tv(body, 14f, GRAY).apply { gravity = Gravity.CENTER }, lp(-1, -2, 12))
    }
    private fun previewVoice() {
        val key = pf().getString("elkey", "") ?: ""
        if (key.isEmpty()) { toast("Add your ElevenLabs key first"); return }
        toast("Loading voice...")
        thread {
            val f = File(cacheDir, "pv.mp3")
            val ok = Eleven.fetch(key, Eleven.id(this), "Good evening. All systems ready hain. Aaj ka kya plan hai?", f)
            runOnUiThread { if (ok) try { MediaPlayer().apply { setDataSource(f.path); prepare(); start(); setOnCompletionListener { it.release() } } } catch (e: Exception) {} else toast("Voice failed. Check your key.") }
        }
    }
    private fun onboard(step: Int) {
        page = "onboard"; topBar.visibility = View.GONE; statusV = null; replyV = null; content.removeAllViews()
        val v: View = when (step) {
            0 -> col().apply {
                gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(26), dp(40), dp(26), dp(30))
                addView(CoreView(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(serif("Hi. I'm Jarvis.", 32f))
                addView(tv("Your AI that talks, listens, and remembers you, right from your pocket.", 14f, GRAY).apply { gravity = Gravity.CENTER }, lp(-1, -2, 12))
                addView(btn("Meet Jarvis →") { onboard(1) }, lp(-1, dp(52), 24))
            }
            1 -> obCol(1, "What should Jarvis call you?", "So every hello is yours.").apply {
                val e = field("Your name"); e.gravity = Gravity.CENTER; addView(e, lp(-1, -2, 20))
                addView(btn("Continue →") { val n = e.text.toString().trim(); if (n.isNotEmpty()) { pf().edit().putString("uname", n).putString("title", n).apply(); onboard(2) } else toast("Please type a name") }, lp(-1, dp(52), 20))
            }
            2 -> obCol(2, "Bring your own key.", "Your key stays on this phone. Gemini has a free key: open aistudio.google.com, tap Get API key, and paste it here.").apply {
                val prov = pf().getString("provider", "gemini")
                val ch = LinearLayout(this@MainActivity)
                listOf("gemini" to "Gemini (free)", "claude" to "Claude").forEach { (k, n) ->
                    ch.addView(tv(n, 14f, if (prov == k) INK else BLUE).apply {
                        gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
                        background = if (prov == k) GradientDrawable().apply { setColor(BTN); cornerRadius = dp(12).toFloat() } else glass()
                        setOnClickListener { pf().edit().putString("provider", k).apply(); onboard(2) }
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
                }
                addView(ch, lp(-1, -2, 18))
                val kk = if (prov == "gemini") "gkey" else "key"
                val e = field(if (prov == "gemini") "Paste Gemini key" else "Paste Claude key", pf().getString(kk, "") ?: "")
                addView(e, lp(-1, -2, 14))
                addView(btn("Continue →") { pf().edit().putString(kk, e.text.toString().trim()).apply(); onboard(3) }, lp(-1, dp(52), 18))
                addView(btn("Skip for now", false) { onboard(3) }, lp(-1, -2, 6))
            }
            3 -> obCol(3, "Pick Jarvis's voice.", "You will hear it in your first chat. You can change it anytime in Settings.").apply {
                val sel = pf().getString("lvoice", "Charon")
                listOf("Charon" to "Charon - deep, calm (Jarvis-like)", "Puck" to "Puck - bright, quick", "Kore" to "Kore - warm, steady", "Fenrir" to "Fenrir - bold, direct", "Aoede" to "Aoede - light, airy", "Zephyr" to "Zephyr - soft, easy").forEach { (id, n) ->
                    val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; background = if (sel == id) GradientDrawable().apply { setColor(BTN); cornerRadius = dp(14).toFloat() } else glass(); setPadding(dp(16), dp(14), dp(16), dp(14)) }
                    row.addView(tv(n, 15f, if (sel == id) INK else Color.WHITE, sel == id), LinearLayout.LayoutParams(0, -2, 1f))
                    row.setOnClickListener { pf().edit().putString("lvoice", id).apply(); onboard(3) }
                    addView(row, lp(-1, -2, 8))
                }
                addView(View(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(btn("Sounds right →") { onboard(4) }, lp(-1, dp(52), 12))
            }
            4 -> obCol(4, "Jarvis works while you're away.", "Reminders and care nudges reach you at the right moment. One nudge when it matters, never spam. You can change this anytime in Settings.").apply {
                addView(View(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(btn("Continue →") { if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2) else onboard(5) }, lp(-1, dp(52), 12))
                addView(btn("Not now", false) { onboard(5) }, lp(-1, -2, 6))
            }
            else -> obCol(5, "Jarvis needs to hear you.", "The mic is used only while Jarvis is listening for \"Jarvis\" or a command. Calls and contacts are used only when you ask Jarvis to call or message someone.").apply {
                addView(View(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(btn("Continue →") { start() }, lp(-1, dp(52), 12))
                addView(btn("I'll type instead", false) { finishOnboarding() }, lp(-1, -2, 6))
            }
        }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }
    private fun finishOnboarding() { pf().edit().putBoolean("onboarded", true).apply(); go("home"); greetLoop(true, 0) }

    // ---------- permissions ----------
    private fun start() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (c == 2) { onboard(5); return }
        if (c == 3) { go("perm"); return }
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(Intent(this, JarvisService::class.java)); toast("Jarvis is on")
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else toast("Microphone permission is needed for voice")
        if (!pf().getBoolean("onboarded", false)) finishOnboarding()
    }
}
