package com.sam.jarvis
import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

object Tools {
    class Card(val title: String, val detail: String, val url: String?, val code: String?)
    val cards = CopyOnWriteArrayList<Card>()
    fun card(c: Context, title: String, detail: String = "", url: String? = null, code: String? = null) {
        cards.add(0, Card(title, detail, url, code)); while (cards.size > 40) cards.removeAt(cards.size - 1)
        Brain.hist(c, title + if (detail.isNotEmpty()) ": " + detail.take(60) else "")
    }
    private fun s(d: String = "") = JSONObject().put("type", "STRING").put("description", d)
    private fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject().put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", JSONArray(req)))
    val decl: JSONArray = JSONArray()
        .put(fn("open_app", "Open an app or website for the user.", JSONObject().put("app", s("App name such as youtube, google, maps, whatsapp, instagram, gmail, spotify")).put("query", s("Search words if any")), listOf("app")))
        .put(fn("call", "Call a saved contact or a phone number.", JSONObject().put("who", s("Contact name or number")), listOf("who")))
        .put(fn("send_message", "Prepare a text message. Use ONLY after the user clearly said yes to the exact text.", JSONObject().put("who", s("Contact name or number")).put("text", s("Exact message")).put("via", s("sms or whatsapp")), listOf("who", "text")))
        .put(fn("set_reminder", "Set a daily reminder.", JSONObject().put("time", s("HH:MM in 24 hour format")).put("text", s("What to remind")), listOf("time", "text")))
        .put(fn("log_health", "Log water, a meal or a workout the user just did.", JSONObject().put("kind", s("water, meal or workout")), listOf("kind")))
        .put(fn("remember", "Save an important lasting fact about the user. Ask the user first.", JSONObject().put("fact", s("The fact")), listOf("fact")))
        .put(fn("show_code", "Show code to the user in the activity panel.", JSONObject().put("language", s("Language")).put("code", s("The code")), listOf("code")))

    fun run(c: Context, name: String, a: JSONObject): String {
        when (name) {
            "open_app" -> {
                val app = a.optString("app").lowercase(); val q = a.optString("query")
                val url = when {
                    app == "youtube" && q.isNotEmpty() -> "https://www.youtube.com/results?search_query=" + Brain.enc(q)
                    app == "google" && q.isNotEmpty() -> "https://www.google.com/search?q=" + Brain.enc(q)
                    app == "maps" && q.isNotEmpty() -> "https://www.google.com/maps/search/?api=1&query=" + Brain.enc(q)
                    else -> ""
                }
                if (url.isNotEmpty()) { Brain.web(c, url); card(c, "Opened $app", q, url); return "Opened $app for $q" }
                val ok = Brain.openApp(c, app); card(c, if (ok) "Opened $app" else "Could not open $app")
                return if (ok) "Opened $app" else "I could not find an app named $app"
            }
            "call" -> {
                val who = a.optString("who"); val n = Brain.findNumber(c, who) ?: return "No contact or number found for $who"
                c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); card(c, "Calling $who", n)
                return "Calling $who"
            }
            "send_message" -> {
                val who = a.optString("who"); val text = a.optString("text"); val n = Brain.findNumber(c, who) ?: return "No contact or number found for $who"
                if (a.optString("via").lowercase() == "whatsapp") {
                    val u = "https://wa.me/" + n.replace("+", "") + "?text=" + Brain.enc(text); Brain.web(c, u); card(c, "WhatsApp to $who", text, u)
                } else { c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); card(c, "Message to $who", text) }
                return "The message is ready in the app. The user must tap Send."
            }
            "set_reminder" -> {
                val m = Regex("(\\d{1,2}):(\\d{2})").find(a.optString("time")) ?: return "Invalid time"
                val tx = a.optString("text").ifEmpty { "reminder" }
                Brain.addRem(c, m.groupValues[1].toInt(), m.groupValues[2].toInt(), tx, true); card(c, "Reminder set", a.optString("time") + "  " + tx)
                return "Reminder saved"
            }
            "log_health" -> {
                when (a.optString("kind").lowercase()) {
                    "water" -> { val n = Brain.addWater(c); card(c, "Water logged", "$n glasses today") }
                    "workout" -> { Care.log(c, "workout"); card(c, "Workout logged") }
                    else -> { Care.logMeal(c); card(c, "Meal logged") }
                }
                return "Logged"
            }
            "remember" -> { Brain.addMem(c, a.optString("fact")); card(c, "Saved to memory", a.optString("fact")); return "Saved" }
            "show_code" -> { card(c, "Code", a.optString("language"), null, a.optString("code")); return "Shown in the activity panel" }
        }
        return "Unknown tool"
    }
}
