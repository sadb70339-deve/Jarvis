package com.sam.jarvis
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

// Gemini Live: one WebSocket that hears, thinks and speaks.
class LiveClient(private val svc: JarvisService) {
    private val h = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val player = Executors.newSingleThreadExecutor()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile var active = false
    @Volatile private var ready = false
    @Volatile private var gen = 0
    @Volatile private var pgen = 0
    @Volatile private var endAt = 0L
    private var first: String? = null
    private val uT = StringBuilder(); private val oT = StringBuilder(); private var newTurn = true
    private var oldMode = AudioManager.MODE_NORMAL
    private var idle: Runnable? = null

    private fun headset(am: AudioManager) = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
        it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
    }
    private fun setup(c: Context): JSONObject {
        val p = Brain.prefs(c)
        val voice = p.getString("lvoice", "Charon") ?: "Charon"; val model = p.getString("lmodel", "gemini-3.1-flash-live-preview") ?: ""
        return JSONObject().put("setup", JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Brain.liveSystem(c)))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.decl)))
            .put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject()))
    }
    fun open(firstText: String?) {
        if (active) { if (firstText != null) sendText(firstText); return }
        val c: Context = svc; val key = Brain.prefs(c).getString("gkey", "") ?: ""
        if (key.isEmpty()) { svc.say(Brain.L(c, "Please add your Gemini key in Settings.", "Settings mein Gemini key daal do."), true); return }
        active = true; ready = false; first = firstText; Brain.state = "thinking"
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        oldMode = am.mode; am.mode = AudioManager.MODE_IN_COMMUNICATION; am.isSpeakerphoneOn = !headset(am)
        val g = ++gen
        val req = Request.Builder().url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setup(c).toString()) }
            override fun onMessage(webSocket: WebSocket, text: String) { handle(g, text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(g, bytes.utf8()) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { fail(g, Brain.L(c, "Live connection failed. Check your key and model in Settings.", "Live connection nahi bani. Settings mein key aur model check karo.")) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (g == gen) h.post { if (!ready && reason.isNotEmpty()) svc.say(reason.take(100), true); close() } }
        })
    }
    private fun fail(g: Int, msg: String) { if (g != gen) return; h.post { close(); svc.say(msg, true) } }
    fun sendText(t: String) { ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString()); h.post { resetIdle() } }
    private fun resetIdle() { idle?.let { h.removeCallbacks(it) }; val r = Runnable { close() }; idle = r; h.postDelayed(r, 60000) }

    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400)); rec = r
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true; if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true } catch (e: Exception) {}
        r.startRecording(); val g = gen
        Thread {
            val buf = ByteArray(3200)
            while (active && g == gen) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0 && ready) ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject().put("data", Base64.encodeToString(buf.copyOf(n), Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000"))).toString())
            }
        }.start()
    }
    private fun ensureTrack(): AudioTrack {
        track?.let { return it }
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4)
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        t.play(); track = t; return t
    }
    private fun enqueue(b64: String) {
        val bytes = Base64.decode(b64, Base64.DEFAULT); val g = gen; val pg = pgen
        Brain.state = "speaking"
        val now = System.currentTimeMillis(); val ms = bytes.size / 2 * 1000L / 24000
        endAt = maxOf(endAt, now) + ms
        player.execute { if (g == gen && pg == pgen && active) try { ensureTrack().write(bytes, 0, bytes.size) } catch (e: Exception) {} }
        h.postDelayed({ if (g == gen && System.currentTimeMillis() >= endAt - 50 && Brain.state == "speaking") Brain.state = "listening" }, endAt - now + 200)
    }
    fun interrupt() { pgen++; endAt = 0; try { track?.pause(); track?.flush(); track?.play() } catch (e: Exception) {}; if (active) Brain.state = "listening" }

    private fun handle(g: Int, text: String) {
        if (g != gen) return
        val m = try { JSONObject(text) } catch (e: Exception) { return }
        if (m.has("setupComplete")) {
            h.post { if (g == gen && active) { ready = true; startMic(); Brain.state = "listening"; first?.let { sendText(it) }; first = null; resetIdle() } }
            return
        }
        val c = m.optJSONObject("serverContent")
        if (c != null) {
            if (c.optBoolean("interrupted")) h.post { interrupt() }
            c.optJSONObject("inputTranscription")?.let { uT.append(it.optString("text")); svc.touch(); h.post { resetIdle() } }
            c.optJSONObject("outputTranscription")?.let { if (newTurn) { oT.setLength(0); newTurn = false }; oT.append(it.optString("text")); Brain.lastReply = oT.toString() }
            val parts = c.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) for (i in 0 until parts.length()) { val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data"); if (!d.isNullOrEmpty()) enqueue(d) }
            if (c.optBoolean("turnComplete")) {
                val u = uT.toString().trim(); val o = oT.toString().trim()
                if (u.isNotEmpty()) { Brain.chat.add("YOU" to u); Brain.hist(svc, "You: $u") }
                if (o.isNotEmpty()) { Brain.chat.add("JARVIS" to o); Brain.hist(svc, "Jarvis: $o") }
                uT.setLength(0); oT.setLength(0); newTurn = true; svc.touch(); h.post { resetIdle() }
            }
        }
        val calls = m.optJSONObject("toolCall")?.optJSONArray("functionCalls")
        if (calls != null) Thread {
            val out = JSONArray()
            for (i in 0 until calls.length()) {
                val f = calls.getJSONObject(i)
                val r = try { Tools.run(svc, f.getString("name"), f.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "Failed: " + e.message }
                out.put(JSONObject().put("id", f.getString("id")).put("name", f.getString("name")).put("response", JSONObject().put("result", r)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
        }.start()
    }
    fun close() {
        if (!active && ws == null) return
        active = false; ready = false; gen++; pgen++
        idle?.let { h.removeCallbacks(it) }
        try { ws?.close(1000, "bye") } catch (e: Exception) {}; ws = null
        try { rec?.stop(); rec?.release() } catch (e: Exception) {}; rec = null
        try { track?.release() } catch (e: Exception) {}; track = null
        try { val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager; am.mode = oldMode; am.isSpeakerphoneOn = false } catch (e: Exception) {}
        Brain.state = "idle"; svc.onLiveClosed()
    }
}
