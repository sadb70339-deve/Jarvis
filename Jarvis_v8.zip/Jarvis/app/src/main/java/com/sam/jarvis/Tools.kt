package com.sam.jarvis
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

object Tools {
    class Card(val title: String, val detail: String, val url: String?, val code: String?)
    val cards = CopyOnWriteArrayList<Card>()
    fun card(c: Context, title: String, detail: String = "", url: String? = null, code: String? = null) {
        cards.add(0, Card(title, detail, url, code)); while (cards.size > 40) cards.removeAt(cards.size - 1)
        Brain.hist(c, title + if (detail.isNotEmpty()) ": " + detail.take(60) else "")
    }
    private fun s(d: String = "") = JSONObject().put("type", "STRING").put("description", d)
    private fun b(d: String = "") = JSONObject().put("type", "BOOLEAN").put("description", d)
    private fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject().put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", JSONArray(req)))
    private fun fn0(name: String, desc: String) = JSONObject().put("name", name).put("description", desc)
    val decl: JSONArray = JSONArray()
        .put(fn("open_app", "Open an app or website for the user.", JSONObject().put("app", s("App name such as youtube, google, maps, whatsapp, instagram, gmail, spotify")).put("query", s("Search words if any")), listOf("app")))
        .put(fn("call", "Call a saved contact or a phone number.", JSONObject().put("who", s("Contact name or number")), listOf("who")))
        .put(fn("send_message", "Prepare a text message in the messaging app. Use ONLY after the user clearly said yes to the exact text.", JSONObject().put("who", s("Contact name or number")).put("text", s("Exact message")).put("via", s("sms or whatsapp")), listOf("who", "text")))
        .put(fn("set_reminder", "Set a daily reminder.", JSONObject().put("time", s("HH:MM in 24 hour format")).put("text", s("What to remind")), listOf("time", "text")))
        .put(fn("log_health", "Log water, a meal or a workout the user just did.", JSONObject().put("kind", s("water, meal or workout")), listOf("kind")))
        .put(fn("remember", "Save a fact to memory. ONLY when the user explicitly asks you to remember it.", JSONObject().put("fact", s("The fact")), listOf("fact")))
        .put(fn("show_code", "Show code to the user in the activity panel.", JSONObject().put("language", s("Language")).put("code", s("The code")), listOf("code")))
        .put(fn0("read_screen", "Read the text currently visible on the phone screen (never passwords). Use it to understand the screen and to check that an action worked."))
        .put(fn("tap_text", "Tap a button or item on the screen by its visible text. Taps on send, pay, buy, delete, confirm, post, order and similar need user_confirmed=true after the user said yes.", JSONObject().put("text", s("Visible text of the item")).put("user_confirmed", b("True only if the user clearly said yes to this exact action")), listOf("text")))
        .put(fn("scroll", "Scroll the current screen.", JSONObject().put("direction", s("up, down, left or right")), listOf("direction")))
        .put(fn("type_text", "Type text into the focused text box on screen (never into password fields).", JSONObject().put("text", s("Text to type")), listOf("text")))
        .put(fn("press", "Press a system button.", JSONObject().put("button", s("back, home, recents, notifications or quick_settings")), listOf("button")))
        .put(fn("open_settings", "Open a page of the phone's Settings.", JSONObject().put("page", s("wifi, bluetooth, display, sound, battery, apps, accessibility, location, security, airplane, language, storage, date or main")), listOf("page")))
        .put(fn("ask_brain", "Ask a stronger thinking model for hard reasoning, planning, analysis or coding. Returns text you then summarise out loud.", JSONObject().put("question", s("The full question with context")), listOf("question")))
        .put(fn("add_task", "Add a task to the task list, for the user or for yourself.", JSONObject().put("text", s("The task")).put("owner", s("user or jarvis")), listOf("text")))
        .put(fn("complete_task", "Mark a task as done.", JSONObject().put("text", s("Part of the task text")), listOf("text")))
        .put(fn("add_rule", "Save a permanent rule about how you should behave, taught by the user.", JSONObject().put("text", s("The rule")), listOf("text")))
        .put(fn("update_setting", "Change one of your own settings.", JSONObject().put("name", s("voice, mode, language, speed, address_me_as, name or care")).put("value", s("New value")), listOf("name", "value")))
        .put(fn("request_upgrade", "Record a request for a new ability that needs a new version of the app.", JSONObject().put("text", s("The ability the user wants")), listOf("text")))
        .put(fn("manage_data", "Delete data the user asked to delete.", JSONObject().put("action", s("clear_chat or clear_history")), listOf("action")))

    private val risky = Regex("(?i)\\b(send|pay|buy|order|confirm|transfer|delete|remove|uninstall|install|post|submit|purchase|checkout|sign out|log out|bhejo)\\b")
    private fun needAccess(c: Context): String {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Accessibility is off. I opened the Accessibility settings. Ask the user to turn Jarvis on."
    }
    private fun deepAsk(c: Context, q: String): String {
        val p = Brain.prefs(c); val key = p.getString("gkey", "") ?: ""
        if (key.isEmpty()) return "No Gemini key."
        for (model in listOf(p.getString("dmodel", "gemini-pro-latest") ?: "gemini-pro-latest", "gemini-flash-latest")) {
            try {
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 3000))
                val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                con.connectTimeout = 10000; con.readTimeout = 45000; con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("x-goog-api-key", key); con.setRequestProperty("Content-Type", "application/json")
                con.outputStream.write(body.toString().toByteArray())
                if (con.responseCode >= 300) continue
                val r = con.inputStream.bufferedReader().readText()
                return JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").take(2500)
            } catch (e: Exception) {}
        }
        return "The thinking model did not answer."
    }

    fun run(c: Context, name: String, a: JSONObject): String {
        val acc = JarvisAccess.inst
        when (name) {
            "open_app" -> {
                val app = a.optString("app").lowercase(); val q = a.optString("query")
                val url = when {
                    app == "youtube" && q.isNotEmpty() -> "https://www.youtube.com/results?search_query=" + Brain.enc(q)
                    app == "google" && q.isNotEmpty() -> "https://www.google.com/search?q=" + Brain.enc(q)
                    app == "maps" && q.isNotEmpty() -> "https://www.google.com/maps/search/?api=1&query=" + Brain.enc(q)
                    else -> ""
                }
                if (url.isNotEmpty()) { Brain.web(c, url); card(c, "Opened $app", q, url); return "Opened $app for $q" }
                val ok = Brain.openApp(c, app); card(c, if (ok) "Opened $app" else "Could not open $app")
                return if (ok) "Opened $app" else "I could not find an app named $app"
            }
            "call" -> {
                val who = a.optString("who"); val n = Brain.findNumber(c, who) ?: return "No contact or number found for $who"
                c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); card(c, "Calling $who", n)
                return "Calling $who"
            }
            "send_message" -> {
                val who = a.optString("who"); val text = a.optString("text"); val n = Brain.findNumber(c, who) ?: return "No contact or number found for $who"
                if (a.optString("via").lowercase() == "whatsapp") {
                    val u = "https://wa.me/" + n.replace("+", "") + "?text=" + Brain.enc(text); Brain.web(c, u); card(c, "WhatsApp to $who", text, u)
                } else { c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); card(c, "Message to $who", text) }
                return "The message is ready in the app. The user must tap Send, or you can tap Send after they confirm."
            }
            "set_reminder" -> {
                val m = Regex("(\\d{1,2}):(\\d{2})").find(a.optString("time")) ?: return "Invalid time"
                val tx = a.optString("text").ifEmpty { "reminder" }
                Brain.addRem(c, m.groupValues[1].toInt(), m.groupValues[2].toInt(), tx, true); card(c, "Reminder set", a.optString("time") + "  " + tx)
                return "Reminder saved"
            }
            "log_health" -> {
                when (a.optString("kind").lowercase()) {
                    "water" -> { val n = Brain.addWater(c); card(c, "Water logged", "$n glasses today") }
                    "workout" -> { Care.log(c, "workout"); card(c, "Workout logged") }
                    else -> { Care.logMeal(c); card(c, "Meal logged") }
                }
                return "Logged"
            }
            "remember" -> { Brain.addMem(c, a.optString("fact")); card(c, "Saved to memory", a.optString("fact")); return "Saved" }
            "show_code" -> { card(c, "Code", a.optString("language"), null, a.optString("code")); return "Shown in the activity panel" }
            "read_screen" -> { if (acc == null) return needAccess(c); return acc.readScreen().take(3500) }
            "tap_text" -> {
                if (acc == null) return needAccess(c)
                val t = a.optString("text")
                if (risky.containsMatchIn(t) && !a.optBoolean("user_confirmed", false)) return "BLOCKED: \"$t\" is a sensitive action. Ask the user to confirm this exact action, then call again with user_confirmed=true."
                val r = acc.tapText(t); card(c, "Tapped", t); return r
            }
            "scroll" -> { if (acc == null) return needAccess(c); return if (acc.scroll(a.optString("direction"))) "Scrolled" else "Could not scroll" }
            "type_text" -> { if (acc == null) return needAccess(c); val r = acc.typeText(a.optString("text")); card(c, "Typed text", a.optString("text").take(60)); return r }
            "press" -> { if (acc == null) return needAccess(c); return if (acc.press(a.optString("button"))) "Done" else "Could not press that" }
            "open_settings" -> {
                val act = when (a.optString("page").lowercase()) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS; "battery" -> Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS; "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                    "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS; "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS; "security" -> Settings.ACTION_SECURITY_SETTINGS
                    "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS; "language" -> Settings.ACTION_LOCALE_SETTINGS; "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
                    "date" -> Settings.ACTION_DATE_SETTINGS; else -> Settings.ACTION_SETTINGS
                }
                c.startActivity(Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); card(c, "Opened settings", a.optString("page"))
                return "Opened the ${a.optString("page")} settings page. You can now read_screen and tap_text to change things."
            }
            "ask_brain" -> { val r = deepAsk(c, a.optString("question")); card(c, "Thought it through", a.optString("question").take(60)); return r }
            "add_task" -> { Brain.addTask(c, a.optString("text"), if (a.optString("owner").lowercase() == "jarvis") "jarvis" else "user"); card(c, "Task added", a.optString("text")); return "Task added" }
            "complete_task" -> return if (Brain.completeTask(c, a.optString("text"))) "Marked done" else "No open task matches that"
            "add_rule" -> { Brain.addRule(c, a.optString("text")); card(c, "New rule learned", a.optString("text")); return "Rule saved. It applies from the next conversation." }
            "update_setting" -> {
                val n = a.optString("name").lowercase(); val v = a.optString("value"); val e = Brain.prefs(c).edit()
                when (n) {
                    "voice" -> { val ok = listOf("Charon", "Puck", "Kore", "Fenrir", "Aoede", "Zephyr").firstOrNull { it.equals(v, true) } ?: return "Unknown voice"; e.putString("lvoice", ok) }
                    "mode" -> { if (v.lowercase() !in listOf("work", "normal", "friend", "creator", "silent")) return "Unknown mode"; e.putString("mode", v.lowercase()) }
                    "language" -> { if (v.lowercase() !in listOf("english", "roman", "hindi", "mix")) return "Use english, roman, hindi or mix"; e.putString("lang", v.lowercase()) }
                    "speed" -> { val f = v.toFloatOrNull()?.coerceIn(0.8f, 1.6f) ?: return "Invalid speed"; e.putFloat("lspeed", f) }
                    "address_me_as" -> e.putString("title", v)
                    "name" -> e.putString("uname", v)
                    "care" -> e.putBoolean("care", v.equals("on", true) || v.equals("true", true))
                    else -> return "I can change: voice, mode, language, speed, address_me_as, name, care"
                }
                e.apply(); card(c, "Setting changed", "$n = $v"); return "Changed. Voice, speed and language apply from the next conversation."
            }
            "request_upgrade" -> { Brain.addUpgrade(c, a.optString("text")); card(c, "Upgrade requested", a.optString("text")); return "Saved in the Upgrade requests list. It needs a new app version, so the user has to build it." }
            "manage_data" -> {
                return when (a.optString("action")) {
                    "clear_chat" -> { Brain.clearChat(c); "Chat deleted. Saved memory is untouched." }
                    "clear_history" -> { Brain.prefs(c).edit().remove("hist").apply(); "Action history deleted." }
                    else -> "Unknown action"
                }
            }
        }
        return "Unknown tool"
    }
}
