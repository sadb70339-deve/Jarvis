package com.sam.jarvis
import android.content.Context
import org.json.JSONArray
import java.util.Calendar

// Jarvis looks after water, meals and fitness by himself and learns your timings after 3+ logs.
object Care {
    private fun p(c: Context) = Brain.prefs(c)
    fun log(c: Context, kind: String) {
        val k = "hab_$kind"; val a = JSONArray(p(c).getString(k, "[]")); val cal = Calendar.getInstance()
        a.put(cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE))
        val b = JSONArray(); for (i in maxOf(0, a.length() - 7) until a.length()) b.put(a.get(i))
        p(c).edit().putString(k, b.toString()).putString("ld_$kind", Brain.today()).putLong("lt_$kind", System.currentTimeMillis()).apply()
    }
    fun logMeal(c: Context) { val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); log(c, if (hr < 12) "mealB" else if (hr < 17) "mealL" else "mealD") }
    fun doneToday(c: Context, kind: String) = p(c).getString("ld_$kind", "") == Brain.today()
    private fun at(c: Context, kind: String, def: Int): Int {
        val a = JSONArray(p(c).getString("hab_$kind", "[]")); if (a.length() < 3) return def
        return (0 until a.length()).map { a.getInt(it) }.sorted()[a.length() / 2]
    }
    fun tick(c: Context, say: (String) -> Unit): Boolean {
        val pr = p(c)
        if (!pr.getBoolean("care", true) || Brain.mode(c) == "silent") return false
        val cal = Calendar.getInstance(); val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE); val day = Brain.today()
        val wake = pr.getInt("wakeMin", 7 * 60); val sleep = pr.getInt("sleepMin", 23 * 60)
        if (now < wake + 30 || now > sleep - 30) return false
        val t = Brain.title(c)
        fun due(key: String, time: Int, within: Int = 90) = now >= time && now < time + within && pr.getString("f_$key", "") != day
        fun mark(key: String) { pr.edit().putString("f_$key", day).apply() }
        if (due("mB", at(c, "mealB", wake + 90)) && !doneToday(c, "mealB")) { mark("mB"); say(Brain.L(c, "$t, have you had breakfast yet? Start the day right.", "$t, nashta kar liya? Din ki acchi shuruaat karo.")); return true }
        if (due("mL", at(c, "mealL", 14 * 60)) && !doneToday(c, "mealL")) { mark("mL"); say(Brain.L(c, "$t, it's lunch time. Eat something light.", "$t, lunch ka time ho gaya. Kuch halka sa kha lo.")); return true }
        if (due("mD", at(c, "mealD", 20 * 60 + 30)) && !doneToday(c, "mealD")) { mark("mD"); say(Brain.L(c, "$t, dinner time. Eat on time tonight.", "$t, dinner ka time hai. Aaj time par kha lo.")); return true }
        if (due("fit", at(c, "workout", 18 * 60), 120) && !doneToday(c, "workout")) { mark("fit"); say(Brain.L(c, "$t, time for a workout or a walk. Even 20 minutes counts.", "$t, workout ya walk ka time hai. 20 minute bhi kaafi hain.")); return true }
        val lastW = maxOf(pr.getLong("lt_water", 0L), pr.getLong("wn", 0L))
        if (Brain.water(c) < 8 && now > wake + 60 && now < sleep - 60 && System.currentTimeMillis() - lastW > 2 * 3600_000L) {
            pr.edit().putLong("wn", System.currentTimeMillis()).apply()
            say(Brain.L(c, "$t, time to drink some water.", "$t, paani ka time ho gaya. Ek glass pi lo.")); return true
        }
        return false
    }
}
