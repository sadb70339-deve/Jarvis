package com.sam.jarvis
import android.content.Context
import android.graphics.*
import android.view.View

class CoreView(c: Context, private val big: Boolean = false) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f * (if (big) 0.92f else 1f)
        t += 1f
        val st = if (big) "idle" else Brain.state
        val pulse = when (st) {
            "listening" -> 0.9f + 0.1f * Math.sin(t / 4.0).toFloat()
            "speaking" -> 0.85f + 0.15f * Math.sin(t / 2.0).toFloat()
            "thinking" -> 0.8f
            else -> 0.75f + 0.05f * Math.sin(t / 20.0).toFloat()
        }
        val col = if (st == "thinking") Color.rgb(255, 170, 40) else Color.rgb(40, 170, 255)
        if (big) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.rgb(40, 110, 170); p.alpha = 22
            val g = r / 3f; var x = 0f
            while (x < width) { cv.drawLine(x, 0f, x, height.toFloat(), p); x += g }
            var y = 0f
            while (y < height) { cv.drawLine(0f, y, width.toFloat(), y, p); y += g }
        }
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 0.5f * pulse, intArrayOf(Color.WHITE, col, Color.TRANSPARENT), floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 0.5f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.color = col
        for (i in 0 until 60) {
            cv.save(); cv.rotate(i * 6f + t * 0.15f, cx, cy)
            p.strokeWidth = if (i % 5 == 0) 4f else 2f; p.alpha = 170
            cv.drawLine(cx, cy - r * 0.95f, cx, cy - r * (if (i % 5 == 0) 0.86f else 0.9f), p)
            cv.restore()
        }
        val sp = if (st == "thinking") 4f else 1f
        for (i in 0..2) {
            val rr = r * (0.55f + i * 0.12f)
            p.color = col; p.strokeWidth = if (i % 2 == 0) 5f else 2.5f; p.alpha = 230 - i * 50
            cv.save(); cv.rotate(t * sp * (if (i % 2 == 0) 0.8f else -1.2f) * (1 + i * 0.4f), cx, cy)
            cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, 0f, 220f - i * 30f, false, p)
            cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, 240f, 50f, false, p)
            if (i == 0) { p.color = Color.rgb(255, 190, 0); p.alpha = 255; cv.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, 225f, 14f, false, p) }
            cv.restore()
        }
        val amp = when (st) { "speaking" -> 1f; "listening" -> 0.4f; else -> 0f }
        if (amp > 0f) {
            p.color = col; p.strokeWidth = 4f; p.alpha = 220
            for (i in 0 until 48) {
                val len = r * 0.07f * (1f + Math.sin(t / 3.0 + i * 0.7).toFloat()) * amp
                cv.save(); cv.rotate(i * 7.5f, cx, cy); cv.drawLine(cx, cy - r * 0.82f, cx, cy - r * 0.82f - len, p); cv.restore()
            }
        }
        p.color = col; p.strokeWidth = 2f; p.alpha = 60
        val y = cy - r + (t * 3) % (2 * r); cv.drawLine(cx - r, y, cx + r, y, p)
        postInvalidateOnAnimation()
    }
}
