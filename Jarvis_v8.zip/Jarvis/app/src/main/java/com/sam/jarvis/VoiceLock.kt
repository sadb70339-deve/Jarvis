package com.sam.jarvis
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

// Best-effort "only my voice" matching. No ML model: it compares average voice features (MFCC mean/std + pitch).
object VoiceLock {
    const val SR = 16000
    private val ring = ShortArray(SR * 8)
    private var pos = 0
    @Volatile private var running = false
    @Volatile var speakEnd = 0L
    @Volatile var status = "No check yet"
    private const val NMEL = 24
    private const val NFFT = 512
    class Prof(val mean: DoubleArray, val scale: DoubleArray, val thr: Double)

    fun prefs(c: Context) = c.getSharedPreferences("j", 0)
    fun load(c: Context): Prof? {
        val s = prefs(c).getString("vprof", null) ?: return null
        return try {
            val o = JSONObject(s)
            fun a(k: String): DoubleArray { val j = o.getJSONArray(k); return DoubleArray(j.length()) { j.getDouble(it) } }
            Prof(a("mean"), a("scale"), o.getDouble("thr"))
        } catch (e: Exception) { null }
    }
    fun save(c: Context, p: Prof) {
        val o = JSONObject().put("mean", JSONArray(p.mean.toList())).put("scale", JSONArray(p.scale.toList())).put("thr", p.thr)
        prefs(c).edit().putString("vprof", o.toString()).apply()
    }
    fun delete(c: Context) { prefs(c).edit().remove("vprof").apply() }
    fun enabled(c: Context) = prefs(c).getBoolean("vlock", false) && load(c) != null
    private fun factor(c: Context) = when (prefs(c).getString("vstrict", "normal")) { "loose" -> 1.5; "strict" -> 1.0; else -> 1.2 }

    // ---- background capture (ring buffer of the last 8 seconds) ----
    fun startCapture() {
        if (running) return
        running = true
        Thread {
            var r: AudioRecord? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                r = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR))
                r.startRecording()
                val buf = ShortArray(1600)
                while (running) {
                    val n = r.read(buf, 0, buf.size)
                    if (n <= 0) { Thread.sleep(50); continue }
                    synchronized(ring) { for (i in 0 until n) { ring[pos] = buf[i]; pos = (pos + 1) % ring.size } }
                }
            } catch (e: Exception) {
            } finally { try { r?.stop(); r?.release() } catch (e: Exception) {}; running = false }
        }.start()
    }
    fun stopCapture() { running = false }
    private fun recent(n0: Int): ShortArray = synchronized(ring) {
        val n = min(n0, ring.size); val out = ShortArray(n); var p = (pos - n + ring.size) % ring.size
        for (i in 0 until n) { out[i] = ring[p]; p = (p + 1) % ring.size }
        out
    }
    fun record(sec: Int): ShortArray {
        val n = SR * sec; val out = ShortArray(n)
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR))
        r.startRecording()
        var got = 0
        while (got < n) { val k = r.read(out, got, min(1600, n - got)); if (k <= 0) break; got += k }
        r.stop(); r.release()
        return out
    }

    // ---- features ----
    private val fb: Array<DoubleArray> by lazy {
        fun mel(f: Double) = 2595 * log10(1 + f / 700)
        fun inv(m: Double) = 700 * (10.0.pow(m / 2595) - 1)
        val lo = mel(80.0); val hi = mel(6000.0)
        val pts = DoubleArray(NMEL + 2) { inv(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { floor((NFFT + 1) * pts[it] / SR).toInt() }
        Array(NMEL) { m ->
            val f = DoubleArray(NFFT / 2 + 1)
            for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toDouble() / max(1, bins[m + 1] - bins[m])
            for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toDouble() / max(1, bins[m + 2] - bins[m + 1])
            f
        }
    }
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size; var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { var t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len; val wr = cos(ang); val wi = sin(ang); var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = i + k + len / 2
                    val vr = re[b] * cr - im[b] * ci; val vi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - vr; im[b] = im[a] - vi; re[a] += vr; im[a] += vi
                    val ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
    fun features(x: ShortArray): DoubleArray? {
        val fl = 400; val hop = 160; val nf = (x.size - fl) / hop
        if (nf < 40) return null
        val en = DoubleArray(nf) { f -> var s = 0.0; for (i in 0 until fl) { val v = x[f * hop + i].toDouble(); s += v * v }; s / fl }
        val thr = max(62500.0, en.sorted()[(nf * 0.2).toInt()] * 6)
        val win = DoubleArray(fl) { 0.54 - 0.46 * cos(2 * PI * it / (fl - 1)) }
        val ceps = ArrayList<DoubleArray>(); val f0s = ArrayList<Double>()
        for (f in 0 until nf) {
            if (en[f] <= thr) continue
            val re = DoubleArray(NFFT); val im = DoubleArray(NFFT)
            for (i in 0 until fl) re[i] = x[f * hop + i] * win[i]
            fft(re, im)
            val lm = DoubleArray(NMEL) { m -> var s = 0.0; for (k in 0..NFFT / 2) s += fb[m][k] * (re[k] * re[k] + im[k] * im[k]); ln(s + 1e-3) }
            ceps.add(DoubleArray(12) { k -> var s = 0.0; for (m in 0 until NMEL) s += lm[m] * cos(PI * (k + 1) * (m + 0.5) / NMEL); s / NMEL })
            var best = 0.0; var bl = 0
            for (lag in 40..228) { var r = 0.0; for (i in 0 until fl - lag) r += x[f * hop + i].toDouble() * x[f * hop + i + lag].toDouble(); if (r > best) { best = r; bl = lag } }
            if (bl > 0 && best > 0.35 * en[f] * fl) f0s.add(SR.toDouble() / bl)
        }
        if (ceps.size < 25) return null
        val v = DoubleArray(25)
        for (k in 0 until 12) {
            val m = ceps.sumOf { it[k] } / ceps.size
            v[k] = m; v[12 + k] = sqrt(ceps.sumOf { (it[k] - m) * (it[k] - m) } / ceps.size)
        }
        v[24] = if (f0s.isEmpty()) 0.0 else f0s.sorted()[f0s.size / 2] / 10.0
        return v
    }
    private fun avg(l: List<DoubleArray>) = DoubleArray(25) { k -> l.sumOf { it[k] } / l.size }
    private fun dist(a: DoubleArray, b: DoubleArray, s: DoubleArray) = sqrt((0 until 25).sumOf { ((a[it] - b[it]) / s[it]).pow(2) } / 25)
    fun build(samples: List<DoubleArray>): Prof {
        val n = samples.size; val mean = avg(samples)
        val scale = DoubleArray(25) { k -> max(sqrt(samples.sumOf { (it[k] - mean[k]).pow(2) } / n), if (k == 24) 1.5 else 0.6) }
        var worst = 0.0
        for (i in 0 until n) worst = max(worst, dist(samples[i], avg(samples.filterIndexed { j, _ -> j != i }), scale))
        return Prof(mean, scale, max(worst, 1.0))
    }

    // ---- checks ----
    fun accept(c: Context): Boolean {
        if (!enabled(c)) return true
        val prof = load(c) ?: return true
        val avail = ((System.currentTimeMillis() - speakEnd) / 1000.0).coerceIn(0.0, 4.0)
        if (avail < 1.2) { status = "Too soon after Jarvis spoke (allowed)"; return true }
        val v = features(recent((avail * SR).toInt()))
        if (v == null) { status = "No clear audio captured (allowed)"; return true }
        val d = dist(v, prof.mean, prof.scale); val lim = prof.thr * factor(c)
        status = (if (d <= lim) "Match" else "Rejected") + ": %.2f / %.2f".format(d, lim)
        return d <= lim
    }
    fun evaluate(c: Context, x: ShortArray): String {
        val prof = load(c) ?: return "No voice saved yet."
        val v = features(x) ?: return "No clear audio. Speak louder or closer to the mic."
        val d = dist(v, prof.mean, prof.scale); val lim = prof.thr * factor(c)
        return (if (d <= lim) "MATCH" else "REJECTED") + "\nScore %.2f, limit %.2f\n(lower score = closer to your voice)".format(d, lim)
    }
}
