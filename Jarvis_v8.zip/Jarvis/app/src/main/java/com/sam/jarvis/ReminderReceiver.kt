package com.sam.jarvis
import android.content.*
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val tx = i.getStringExtra("text") ?: ""
        Brain.hist(c, "Reminder fired: $tx")
        c.startForegroundService(Intent(c, JarvisService::class.java).setAction("speak").putExtra("text", Brain.L(c, "${Brain.title(c)}, reminder: $tx", "${Brain.title(c)}, reminder: $tx")))
        if (i.getBooleanExtra("daily", false)) Brain.schedule(c, i.getIntExtra("id", 0), i.getIntExtra("h", 0), i.getIntExtra("m", 0), tx, true)
    }
}
