package com.sam.jarvis
import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.*
import android.speech.*
import android.speech.tts.*
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class JarvisService : Service(), TextToSpeech.OnInitListener {
    lateinit var tts: TextToSpeech
    val live = LiveClient(this)
    private var sr: SpeechRecognizer? = null
    private var mp: MediaPlayer? = null
    @Volatile private var speaking = false
    @Volatile private var paused = false
    @Volatile var ready = false
    @Volatile private var playGen = 0
    private var lastTalk = System.currentTimeMillis()
    private var ignored = 0
    private val h = Handler(Looper.getMainLooper())
    companion object { var inst: JarvisService? = null }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        inst = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "j").setContentTitle("Jarvis is listening").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        applyLock()
        h.postDelayed(checkin, 60000)
    }
    fun liveEnabled() = Brain.prefs(this).getBoolean("live", true) && !(Brain.prefs(this).getString("gkey", "") ?: "").isEmpty()
    fun touch() { lastTalk = System.currentTimeMillis(); ignored = 0 }
    fun onLiveClosed() { Brain.convUntil = 0; h.post { listen() } }
    // Jarvis says something on his own (reminders, care nudges, greeting): Gemini voice if Live is on, else the fallback voice
    fun announce(t: String) { touch(); if (liveEnabled()) live.open("Tell the user this naturally, in one short line and in your own words: $t") else say(t) }
    fun typeToJarvis(t: String) { if (liveEnabled()) live.open(t) else Brain.handle(this, t) { say(it) } }

    private val checkin = object : Runnable {
        override fun run() {
            val inCall = (getSystemService(AUDIO_SERVICE) as AudioManager).mode == AudioManager.MODE_IN_CALL
            if (!speaking && !live.active && !inCall && ready) {
                var spoke = false
                try { spoke = Care.tick(this@JarvisService) { announce(it) } } catch (e: Exception) {}
                val mode = Brain.mode(this@JarvisService)
                val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                if (!spoke && System.currentTimeMillis() - lastTalk >= 15 * 60000L && ignored < 2 && hr in 7..22 && (mode == "normal" || mode == "friend" || mode == "creator")) {
                    val t = Brain.title(this@JarvisService)
                    announce(listOf(Brain.L(this@JarvisService, "$t, is everything okay? We haven't talked in a while.", "$t, sab theek hai? Kaafi der se baat nahi hui."),
                        Brain.L(this@JarvisService, "How has your day been, $t?", "Aaj ka din kaisa gaya $t?"),
                        Brain.L(this@JarvisService, "Anything on your mind, $t?", "Kuch dimagh mein chal raha hai $t?")).random())
                    ignored++
                }
            }
            h.postDelayed(this, 60000)
        }
    }
    override fun onInit(s: Int) {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { done() }
            override fun onDone(id: String?) { done() }
        })
        applyVoice(); ready = true
        listen()
    }
    fun applyVoice() { try { tts.setLanguage(Locale("en", "IN")); tts.setPitch(0.9f); tts.setSpeechRate(Brain.prefs(this).getFloat("lspeed", 1.15f)) } catch (e: Exception) {} }
    fun sayGreeting(): Boolean {
        if (!ready) return false
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val slot = when { hr in 5..11 -> "m"; hr in 12..16 -> "a"; hr in 17..23 -> "e"; else -> return true }
        val key = Brain.today() + slot; val p = Brain.prefs(this)
        if (p.getString("gslot", "") == key) return true
        p.edit().putString("gslot", key).apply()
        val w = when (slot) { "m" -> "Good morning"; "a" -> "Good afternoon"; else -> "Good evening" }; val n = Brain.title(this)
        if (liveEnabled()) live.open("Greet the user now in one short natural sentence, like: \"$w, $n. All systems ready. Aaj ka kya plan hai?\"")
        else say(Brain.L(this, "$w, $n. All systems are ready. What's the plan for today?", "$w, $n. All systems ready hain. Aaj ka kya plan hai?"))
        return true
    }
    private fun done() { speaking = false; VoiceLock.speakEnd = System.currentTimeMillis(); Brain.state = "idle"; listen() }
    fun pauseListening(p: Boolean) { if (p) live.close(); paused = p; if (p) { h.post { sr?.cancel(); sr?.destroy(); sr = null }; Brain.state = "idle" } else listen() }
    fun applyLock() { if (VoiceLock.enabled(this)) VoiceLock.startCapture() else VoiceLock.stopCapture() }
    fun stopSpeak() { if (live.active) { live.close(); return }; playGen++; try { tts.stop(); mp?.stop() } catch (e: Exception) {}; done() }
    fun wakeNow() {
        if (liveEnabled()) { if (live.active) live.close() else { h.post { sr?.cancel(); sr?.destroy(); sr = null }; live.open(null) }; return }
        if (speaking) stopSpeak(); Brain.convUntil = System.currentTimeMillis() + 60000; ignored = 0; listen()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "speak") { val t = i.getStringExtra("text") ?: ""; h.postDelayed({ announce(t) }, 400) }
        return START_STICKY
    }
    // fallback voice: ElevenLabs if a key exists, otherwise the phone voice
    fun say(t: String, fast: Boolean = false) {
        lastTalk = System.currentTimeMillis(); Brain.lastReply = t; Brain.convUntil = lastTalk + 60000
        speaking = true; Brain.state = "speaking"; h.post { sr?.cancel() }
        val k = Eleven.key(this)
        if (!fast && k.isNotEmpty()) speakEleven(t, k, Eleven.id(this)) else speakTts(t)
    }
    private fun speakTts(t: String) { tts.speak(t, TextToSpeech.QUEUE_ADD, null, "j") }
    private fun speakEleven(t: String, key: String, vid: String) {
        val gen = ++playGen
        val parts = t.split(Regex("(?<=[.!?])\\s+")).filter { it.isNotBlank() }.take(4)
        val q = LinkedBlockingQueue<Any>()
        thread {
            for ((i, s) in parts.withIndex()) {
                if (gen != playGen) return@thread
                val f = File(cacheDir, "s${gen}_$i.mp3")
                if (Eleven.fetch(key, vid, s, f)) q.put(f) else { q.put("fail"); return@thread }
            }
            q.put("end")
        }
        thread {
            var played = 0
            while (gen == playGen) {
                val x = q.take()
                if (x is File) { playFile(x); played++ }
                else { if (x == "fail" && played == 0 && gen == playGen) h.post { speakTts(t) } else if (gen == playGen) h.post { done() }; break }
            }
        }
    }
    private fun playFile(f: File) {
        val latch = CountDownLatch(1)
        h.post {
            try { mp?.release(); mp = MediaPlayer().apply { setDataSource(f.path); setOnCompletionListener { latch.countDown() }; setOnErrorListener { _, _, _ -> latch.countDown(); true }; prepare(); start() } } catch (e: Exception) { latch.countDown() }
        }
        latch.await(30, TimeUnit.SECONDS)
    }
    private fun listen() {
        h.post {
            if (speaking || paused || live.active || !ready) return@post
            Brain.state = if (System.currentTimeMillis() < Brain.convUntil || Brain.waiting()) "listening" else "idle"
            sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    onHeard(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                    if (!speaking && !live.active) h.postDelayed({ listen() }, 100)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 500) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"))
        }
    }
    private val wakeRe = Regex("\\b(jarvis|jarwis|jarvish|jarviz|javis|jarbis|service)\\b")
    private fun onHeard(t: String) {
        val l = t.lowercase(); val now = System.currentTimeMillis()
        val hasWake = wakeRe.containsMatchIn(l)
        val lv = liveEnabled()
        if (lv && !hasWake) return
        if (!lv && !hasWake && now >= Brain.convUntil && !Brain.waiting()) return
        if (!VoiceLock.accept(this)) return
        ignored = 0
        val cmd = l.replace(Regex("\\b(hey|hi)\\b|\\b(jarvis|jarwis|jarvish|jarviz|javis|jarbis|service)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        if (cmd == "stop" || cmd == "chup" || cmd == "chup karo" || cmd == "ruko") { Brain.convUntil = 0; stopSpeak(); return }
        if (lv) { sr?.cancel(); sr?.destroy(); sr = null; live.open(cmd.ifEmpty { null }); return }
        Brain.convUntil = now + 60000
        if (cmd.isEmpty()) say(Brain.L(this, "Yes?", "Ji?"), true) else Brain.handle(this, cmd) { say(it) }
    }
    override fun onDestroy() { inst = null; live.close(); VoiceLock.stopCapture(); sr?.destroy(); tts.shutdown() }
}
