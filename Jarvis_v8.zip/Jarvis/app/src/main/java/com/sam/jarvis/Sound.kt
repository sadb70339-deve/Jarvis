package com.sam.jarvis
import android.content.Context
import android.media.MediaPlayer
object Sound {
    @Volatile var on = true
    fun play(kind: String) {}  // all small effect sounds removed
    fun start(c: Context) {
        if (!on) return
        try { val m = MediaPlayer.create(c, R.raw.jarvis_startup); m?.setOnCompletionListener { it.release() }; m?.start() } catch (e: Exception) {}
    }
}
