package com.sam.jarvis
import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
object Eleven {
    const val BUNTY = "ibbx9zDYGvLgtYzRbqqG"
    const val JARVIS = "onwK4e9ZLuTAKqWW03F9"
    fun id(c: Context) = if (Brain.prefs(c).getString("vstyle", "bunty") == "jarvis") JARVIS else BUNTY
    fun key(c: Context) = Brain.prefs(c).getString("elkey", "") ?: ""
    fun fetch(key: String, vid: String, text: String, out: File): Boolean = try {
        val con = URL("https://api.elevenlabs.io/v1/text-to-speech/$vid").openConnection() as HttpURLConnection
        con.connectTimeout = 8000; con.readTimeout = 20000; con.requestMethod = "POST"; con.doOutput = true
        con.setRequestProperty("xi-api-key", key); con.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            .put("voice_settings", JSONObject().put("stability", 0.4).put("similarity_boost", 0.8).put("style", 0.35).put("use_speaker_boost", true))
        con.outputStream.write(body.toString().toByteArray())
        if (con.responseCode >= 300) false else { out.outputStream().use { con.inputStream.copyTo(it) }; true }
    } catch (e: Exception) { false }
}
