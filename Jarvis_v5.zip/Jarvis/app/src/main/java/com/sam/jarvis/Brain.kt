package com.sam.jarvis
import android.app.*
import android.content.*
import android.net.Uri
import android.provider.ContactsContract
import org.json.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

object Brain {
    @Volatile var state = "idle"
    @Volatile var lastReply = ""
    @Volatile var pending: (() -> Unit)? = null
    @Volatile var pendingAt = 0L
    val chat = CopyOnWriteArrayList<Pair<String, String>>()

    fun prefs(c: Context) = c.getSharedPreferences("j", 0)
    fun mode(c: Context) = prefs(c).getString("mode", "normal")!!
    fun title(c: Context) = if (mode(c) == "work") "Sir" else prefs(c).getString("title", "Sir")!!
    fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun arr(c: Context, k: String) = JSONArray(prefs(c).getString(k, "[]"))
    fun mem(c: Context) = arr(c, "mem")
    fun addMem(c: Context, s: String) { val a = mem(c); a.put(s); prefs(c).edit().putString("mem", a.toString()).apply() }
    fun delMem(c: Context, i: Int) { val a = mem(c); val b = JSONArray(); for (k in 0 until a.length()) if (k != i) b.put(a.get(k)); prefs(c).edit().putString("mem", b.toString()).apply() }
    fun creator(c: Context): List<String> { val a = arr(c, "cre"); return (0 until a.length()).map { a.getString(it) }.reversed() }
    fun addCreator(c: Context, s: String) {
        val a = arr(c, "cre"); a.put(s); val b = JSONArray(); for (k in maxOf(0, a.length() - 20) until a.length()) b.put(a.get(k))
        prefs(c).edit().putString("cre", b.toString()).apply()
    }
    fun hist(c: Context, s: String) {
        val a = arr(c, "hist"); a.put(JSONObject().put("t", System.currentTimeMillis()).put("x", s))
        val b = JSONArray(); for (k in maxOf(0, a.length() - 80) until a.length()) b.put(a.get(k))
        prefs(c).edit().putString("hist", b.toString()).apply()
    }
    fun histList(c: Context, onlyToday: Boolean): List<String> {
        val a = arr(c, "hist"); val cal = Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        val out = ArrayList<String>(); val f = SimpleDateFormat("dd/MM HH:mm", Locale.US)
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (!onlyToday || o.getLong("t") >= cal.timeInMillis) out.add(f.format(Date(o.getLong("t"))) + "  " + o.getString("x")) }
        return out
    }

    fun rems(c: Context) = arr(c, "rem")
    fun saveRems(c: Context, a: JSONArray) = prefs(c).edit().putString("rem", a.toString()).apply()
    fun addRem(c: Context, h: Int, m: Int, text: String, daily: Boolean) {
        val id = (System.currentTimeMillis() % 100000000).toInt()
        val a = rems(c); a.put(JSONObject().put("id", id).put("h", h).put("m", m).put("text", text).put("daily", daily))
        saveRems(c, a); schedule(c, id, h, m, text, daily)
    }
    fun editRem(c: Context, i: Int, h: Int, m: Int) {
        val a = rems(c); val o = a.getJSONObject(i); o.put("h", h).put("m", m); saveRems(c, a)
        schedule(c, o.getInt("id"), h, m, o.getString("text"), o.getBoolean("daily"))
    }
    fun delRem(c: Context, i: Int) {
        val a = rems(c); val b = JSONArray()
        for (k in 0 until a.length()) if (k != i) b.put(a.get(k)) else cancel(c, a.getJSONObject(k).getInt("id"))
        saveRems(c, b)
    }
    private fun pi(c: Context, id: Int, i: Intent) = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context, id: Int) = (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id, Intent(c, ReminderReceiver::class.java)))
    fun schedule(c: Context, id: Int, h: Int, m: Int, text: String, daily: Boolean) {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text).putExtra("h", h).putExtra("m", m).putExtra("daily", daily)
        val p = pi(c, id, i)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, p), p)
    }

    fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        c.startActivity(pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
    private fun web(c: Context, url: String) = c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun confirm(q: String, say: (String) -> Unit, act: () -> Unit) { pending = act; pendingAt = System.currentTimeMillis(); say(q) }
    fun waiting() = pending != null && System.currentTimeMillis() - pendingAt < 60000

    fun handle(c: Context, raw: String, say0: (String) -> Unit) {
        val q = raw.lowercase().trim(); val p = prefs(c)
        chat.add("YOU" to raw); if (chat.size > 60) chat.removeAt(0)
        val say: (String) -> Unit = { lastReply = it; chat.add("JARVIS" to it); say0(it) }
        val t = title(c)
        val act = pending
        if (act != null) {
            pending = null
            if (System.currentTimeMillis() - pendingAt < 60000 && q.length < 25) {
                if (Regex("\\b(nahi|nahin|no|nope|don't|dont|cancel|never mind|mat|rehne do)\\b").containsMatchIn(q)) { say("Okay $t, cancelled."); return }
                if (Regex("\\b(haan|han|ha|yes|yeah|yep|ok|okay|sure|do it|go ahead|please|kar do|kardo|theek hai|bilkul)\\b").containsMatchIn(q)) { act(); return }
            }
        }
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(q)
        val modes = Regex("work|normal|friend|creator|silent|sleep|dnd")
        val rem = Regex("(remember( this| that)?|yaad rakh(o|na))[: ]*").find(q)
        val forget = Regex("(forget( this| that)?|bhool jao|bhul jao)[: ]*").find(q)
        when {
            rem != null -> { val f = q.substring(rem.range.last + 1).trim(); addMem(c, f); hist(c, "Memory saved: $f"); say("Got it, $t. I'll remember that.") }
            forget != null -> {
                val k = q.substring(forget.range.last + 1).trim(); val a = mem(c); var n = 0; val b = JSONArray()
                for (i in 0 until a.length()) { if (k.isNotEmpty() && a.getString(i).lowercase().contains(k)) n++ else b.put(a.get(i)) }
                p.edit().putString("mem", b.toString()).apply(); say(if (n > 0) "Forgotten, $t." else "I couldn't find that in memory.")
            }
            q.contains("mode") && modes.containsMatchIn(q) -> {
                val x = modes.find(q)!!.value; val mm = if (x == "dnd" || x == "sleep") "silent" else x
                p.edit().putString("mode", mm).apply(); hist(c, "Mode: $mm"); say("Okay ${title(c)}, $mm mode is on.")
            }
            q.contains("only english") || q.contains("speak english") || q.contains("english mein") -> { p.edit().putString("lang", "english").apply(); say("Understood. I'll speak only English.") }
            q.contains("roman urdu") -> { p.edit().putString("lang", "roman").apply(); say("Theek hai $t, ab Roman Urdu mein baat karte hain.") }
            q.contains("hindi") && Regex("baat|bolo|mein|speak").containsMatchIn(q) -> { p.edit().putString("lang", "hindi").apply(); say("Theek hai $t, ab Hindi mein baat karenge.") }
            q.contains("what did i do") || q.contains("kya kya karwaya") || q.contains("history") -> { val l = histList(c, true); say(if (l.isEmpty()) "Nothing yet today, $t." else "Today I did ${l.size} things. Latest: " + l.takeLast(3).joinToString(". ") { it.substring(12) }) }
            (q.contains("water") || q.contains("paani")) && Regex("drank|drink|had|\\bpi\\b|piya|pee|liya").containsMatchIn(q) -> {
                val n = if (p.getString("wd", "") == today()) p.getInt("w", 0) + 1 else 1
                p.edit().putString("wd", today()).putInt("w", n).apply(); hist(c, "Water glass #$n"); say("Nice, $t. That's $n glasses today.")
            }
            q.contains("reminder") || q.contains("alarm") || q.contains("remind me") || (q.contains("yaad") && m != null) -> {
                if (m == null) { say("What time, $t?"); return }
                var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (Regex("pm|shaam|raat|dopahar|evening|night").containsMatchIn(q) && h < 12) h += 12
                val txt = q.replace(Regex("\\b(reminder|alarm|remind|me|to|at|yaad|dilao|dilana|laga|do|lagao|baje|am|pm|roz|daily|every|day|subah|shaam|raat|dopahar|ka|ki|ke|ko|mujhe|set|kar|karo)\\b|\\d{1,2}(:\\d{2})?"), " ").replace(Regex("\\s+"), " ").trim().ifEmpty { "reminder" }
                addRem(c, h, mi, txt, Regex("roz|daily|har din|every day").containsMatchIn(q))
                hist(c, "Reminder: $txt at $h:%02d".format(mi)); say("Done, $t. I'll remind you at $h:%02d: $txt.".format(mi))
            }
            q.contains("youtube") && Regex("search|chalao|play|dhundo|lagao").containsMatchIn(q) -> {
                val k = q.replace(Regex("\\b(youtube|pe|par|on|search|chalao|play|dhundo|lagao|karo|video|ka|ki|ke|ko|mujhe|for)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                confirm("$t, should I search YouTube for $k?", say) { web(c, "https://www.youtube.com/results?search_query=" + URLEncoder.encode(k, "UTF-8")); hist(c, "YouTube search: $k"); say("Opened YouTube results for $k.") }
            }
            q.contains("search") || q.contains("dhundo") -> {
                val k = q.replace(Regex("\\b(search|dhundo|google|pe|par|karo|for|on)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                confirm("$t, should I search Google for $k?", say) { web(c, "https://www.google.com/search?q=" + URLEncoder.encode(k, "UTF-8")); hist(c, "Google search: $k"); say("Search opened.") }
            }
            Regex("\\b(kholo|khol|open|launch)\\b").containsMatchIn(q) -> {
                val n = q.replace(Regex("\\b(kholo|khol|open|launch|do|na|please|the|app)\\b"), "").replace(Regex("\\s+"), " ").trim()
                confirm("$t, should I open $n?", say) { val ok = openApp(c, n); hist(c, if (ok) "Opened $n" else "Failed to open $n"); say(if (ok) "Opened $n." else "I couldn't find $n.") }
            }
            q.contains("call") -> {
                val who = q.replace(Regex("\\b(call|karo|lagao|laga|ko|do|please|to)\\b"), "").replace(Regex("\\s+"), " ").trim()
                var num: String? = if (who.matches(Regex("[\\d +]+"))) who.replace(" ", "") else null
                if (num == null) c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                val nn = num
                if (nn == null) say("I couldn't find that contact, $t.")
                else confirm("$t, should I call $who?", say) { c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$nn")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); hist(c, "Call: $who"); say("Calling now.") }
            }
            q.startsWith("kaam kiya") || q.startsWith("task done") || q.startsWith("kaam nahi") || q.startsWith("task missed") -> {
                val ok = q.startsWith("kaam kiya") || q.startsWith("task done")
                val a = JSONArray(p.getString("log", "[]")); a.put(JSONObject().put("t", System.currentTimeMillis()).put("ok", ok).put("x", q))
                p.edit().putString("log", a.toString()).apply(); hist(c, q); say("Noted, $t.")
            }
            q.contains("report") -> { val (ok, no) = week(c); say("$t, this week: $ok tasks done and $no missed. Water today: ${water(c)} glasses.") }
            q.contains("time") && q.length < 25 -> say("It's " + SimpleDateFormat("h:mm a", Locale.US).format(Date()) + ", $t.")
            q.contains("instagram") && Regex("ready|caption|post|hashtag|draft").containsMatchIn(q) -> {
                ask(c, raw, say, 500, "Prepare an Instagram post for this request: $raw. Give: 1) Caption (English motivational quote + Roman Urdu meaning) 2) Cover text (max 6 words) 3) 8 hashtags. Compact.") { r ->
                    chat.add("JARVIS" to r); addCreator(c, r)
                    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", r))
                    hist(c, "Instagram draft prepared"); lastReply = "Draft ready"
                    pending = { val ok = openApp(c, "instagram"); hist(c, if (ok) "Opened Instagram" else "Instagram open failed"); say(if (ok) "Opened Instagram. Paste the caption." else "Instagram isn't installed.") }
                    pendingAt = System.currentTimeMillis()
                    say0("$t, the caption, cover text and hashtags are ready and copied. Want me to open Instagram?")
                }
            }
            else -> ask(c, raw, say)
        }
    }
    fun week(c: Context): Pair<Int, Int> {
        val a = arr(c, "log"); var ok = 0; var no = 0; val wk = System.currentTimeMillis() - 7 * 86400000L
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (o.getLong("t") > wk) { if (o.getBoolean("ok")) ok++ else no++ } }
        return ok to no
    }
    fun water(c: Context) = if (prefs(c).getString("wd", "") == today()) prefs(c).getInt("w", 0) else 0

    fun ask(c: Context, q: String, say: (String) -> Unit, max: Int = 200, prompt: String = q, onText: ((String) -> Unit)? = null) {
        val p = prefs(c); val prov = p.getString("provider", "gemini")!!
        val key = (if (prov == "gemini") p.getString("gkey", "") else p.getString("key", ""))!!
        if (key.isEmpty()) { say("Please add your AI key in Setup, ${title(c)}."); return }
        state = "thinking"
        thread {
            try {
                val msgs = JSONArray(); var last = ""
                for ((who, txt) in chat.takeLast(7)) {
                    val role = if (who == "YOU") "user" else "assistant"
                    if (role == last) { val o = msgs.getJSONObject(msgs.length() - 1); o.put("content", o.getString("content") + "\n" + txt) }
                    else if (msgs.length() > 0 || role == "user") { msgs.put(JSONObject().put("role", role).put("content", txt)); last = role }
                }
                if (msgs.length() == 0 || last != "user") msgs.put(JSONObject().put("role", "user").put("content", q))
                msgs.getJSONObject(msgs.length() - 1).put("content", prompt)
                val tone = when (mode(c)) {
                    "work" -> "Work mode: serious, concise, professional. Address the user as Sir or Boss. No jokes, no personal check-ins."
                    "creator" -> "Creator mode: focused, practical, creative. Help with video ideas, hooks, scripts, English motivational quotes with Roman Urdu meaning, captions, cover text, hashtags."
                    "friend" -> "Friend mode: casual and playful, light humour when suitable. Call the user ${title(c)}."
                    else -> "Normal mode: friendly and relaxed. Call the user ${title(c)}."
                }
                val lang = when (p.getString("lang", "english")) {
                    "roman" -> "Reply in Roman Urdu (Urdu written in English letters)."
                    "hindi" -> "Reply in Hinglish (Hindi in English letters)."
                    "mix" -> "Reply in a natural mix of English and Roman Urdu."
                    else -> "Reply only in English."
                }
                val sys = "You are JARVIS, a calm, confident, mature male AI assistant inspired by Iron Man's JARVIS, living on the user's Android phone. $tone $lang Keep replies short (max 2 sentences) unless asked for detail. If the user seems sad, stressed or upset: be soft and patient, listen first, ask what happened, no jokes, no lectures, no generic motivation, and never encourage dependence on you. Never claim you did an action you did not do. Saved memories about the user: ${mem(c)}. If the user's message reveals something important and lasting (goal, routine, preference, important person or project), end your reply with [[SAVE: short fact]] and nothing after it."
                val txt: String
                if (prov == "gemini") {
                    val contents = JSONArray()
                    for (k in 0 until msgs.length()) { val o = msgs.getJSONObject(k)
                        contents.put(JSONObject().put("role", if (o.getString("role") == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", o.getString("content"))))) }
                    val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                        .put("contents", contents).put("generationConfig", JSONObject().put("maxOutputTokens", max + 1500))
                    val model = p.getString("gmodel", "gemini-flash-latest")!!
                    val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"; con.doOutput = true
                    con.setRequestProperty("x-goog-api-key", key); con.setRequestProperty("Content-Type", "application/json")
                    con.outputStream.write(body.toString().toByteArray())
                    val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                    txt = JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                } else {
                    val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", max).put("system", sys).put("messages", msgs)
                    val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"; con.doOutput = true
                    con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01"); con.setRequestProperty("content-type", "application/json")
                    con.outputStream.write(body.toString().toByteArray())
                    val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                    txt = JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
                }
                val fact = Regex("\\[\\[SAVE:(.*?)\\]\\]").find(txt)?.groupValues?.get(1)?.trim() ?: ""
                val clean = txt.replace(Regex("\\[\\[SAVE:.*?\\]\\]"), "").trim()
                state = "idle"
                if (onText != null) onText(clean)
                else if (fact.isNotEmpty()) {
                    pending = { addMem(c, fact); hist(c, "Memory saved: $fact"); say("Saved to memory.") }; pendingAt = System.currentTimeMillis()
                    say("$clean Also, ${title(c)}, this seems important: $fact. Should I save it to memory?")
                } else say(clean)
            } catch (e: Exception) { state = "idle"; say("I couldn't reach the AI. Please check your key and model in Setup, ${title(c)}.") }
        }
    }
}
