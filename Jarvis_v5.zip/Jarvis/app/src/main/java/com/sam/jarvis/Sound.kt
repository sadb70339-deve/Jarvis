package com.sam.jarvis
import android.media.*
object Sound {
    @Volatile var on = true
    // Only one sound exists: the machine start-up sound. Every other call is ignored.
    fun play(kind: String) {
        if (!on || kind != "start") return
        Thread {
            try {
                val sr = 22050; val n = sr * 3
                val b = ShortArray(n); val rnd = java.util.Random(7); var ph = 0.0; var ph2 = 0.0
                val clicks = doubleArrayOf(0.8, 1.3, 1.7, 2.1)
                for (i in 0 until n) {
                    val t = i / sr.toDouble()
                    val ramp = minOf(1.0, t / 1.2) * (if (t > 2.7) maxOf(0.0, (3.0 - t) / 0.3) else 1.0)
                    ph += 2 * Math.PI * (60 + 120 * minOf(1.0, t / 2.4)) / sr
                    ph2 += 2 * Math.PI * (400 + 500 * minOf(1.0, t / 2.4)) / sr
                    var s = Math.sin(ph) * 0.5 * ramp + Math.sin(ph2) * 0.1 * ramp + (rnd.nextDouble() - 0.5) * 0.05 * ramp
                    for (ct in clicks) { val d = t - ct; if (d >= 0 && d < 0.03) s += (rnd.nextDouble() - 0.5) * 1.2 * (1 - d / 0.03) }
                    val d2 = t - 2.55
                    if (d2 >= 0 && d2 < 0.35) s += Math.sin(2 * Math.PI * 85 * d2) * 0.9 * Math.exp(-d2 * 14)
                    b[i] = (s.coerceIn(-1.0, 1.0) * 9000).toInt().toShort()
                }
                val tr = AudioTrack(AudioManager.STREAM_MUSIC, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC)
                tr.write(b, 0, n); tr.play(); Thread.sleep(3100); tr.release()
            } catch (e: Exception) {}
        }.start()
    }
}
