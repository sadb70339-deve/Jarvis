package com.sam.jarvis
import android.Manifest
import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : Activity() {
    private val LAV = Color.rgb(176, 170, 240)
    private val GRAY = Color.rgb(150, 150, 165)
    private val h = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleV: TextView
    private lateinit var drawerLayer: FrameLayout
    private var drawerOpen = false
    private var page = "home"
    private var searchQ = ""
    private var statusV: TextView? = null
    private var replyV: TextView? = null
    private var typed = 0
    private var typedFor = ""
    private var tts0: TextToSpeech? = null
    private var dx0 = 0f
    private var tracking = false

    // ---------- helpers ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun glass(a: Int = 22, s: Int = 55, r: Int = 16) = GradientDrawable().apply { setColor(Color.argb(a, 255, 255, 255)); setStroke(dp(1), Color.argb(s, 200, 195, 255)); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun serif(t: String, size: Float) = tv(t, size).apply { typeface = Typeface.SERIF; gravity = Gravity.CENTER }
    private fun sec(t: String) = tv(t, 11f, LAV, true).apply { letterSpacing = 0.15f; setPadding(0, dp(16), 0, dp(6)) }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun lp(w: Int = -1, ht: Int = -2, m: Int = 8) = LinearLayout.LayoutParams(w, ht).apply { setMargins(0, dp(m), 0, 0) }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun pf() = Brain.prefs(this)
    private fun speak(r: String) { JarvisService.inst?.say(r) }
    private fun scroll(v: View) = ScrollView(this).apply { addView(v); isVerticalScrollBarEnabled = false }
    private fun btn(t: String, filled: Boolean = true, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(if (filled) Color.rgb(20, 18, 40) else LAV)
        background = if (filled) GradientDrawable().apply { setColor(Color.rgb(170, 165, 225)); cornerRadius = dp(14).toFloat() } else glass()
        setOnClickListener { f() }
    }
    private fun field(hint: String, text: String = "") = EditText(this).apply { setHint(hint); setHintTextColor(GRAY); setTextColor(Color.WHITE); background = glass(18, 50, 14); setPadding(dp(14), dp(12), dp(14), dp(12)); setText(text); textSize = 15f }
    private fun rowCard(text: String, right: String = "", click: (() -> Unit)? = null, onLong: (() -> Unit)? = null): View {
        val r = LinearLayout(this).apply { background = glass(); setPadding(dp(14), dp(14), dp(14), dp(14)); gravity = Gravity.CENTER_VERTICAL }
        r.addView(tv(text, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (right.isNotEmpty()) r.addView(tv(right, 13f, LAV))
        if (click != null) r.setOnClickListener { click() }
        if (onLong != null) r.setOnLongClickListener { onLong(); true }
        return r
    }
    private fun editDialog(title: String, key: String) {
        val e = field(title, pf().getString(key, "") ?: "")
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("Save") { _, _ -> pf().edit().putString(key, e.text.toString().trim()).apply(); go(page) }.setNegativeButton("Cancel", null).show()
    }
    private fun listDialog(title: String, items: List<String>, pick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, i -> pick(i) }.show()
    }
    private fun mask(k: String) = if ((pf().getString(k, "") ?: "").isEmpty()) "Not set" else "••••••"

    // ---------- lifecycle ----------
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        Sound.on = pf().getBoolean("snd", true)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val shell = col()
        topBar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(36), dp(14), dp(6)) }
        topBar.addView(tv("≡", 28f, LAV).apply { gravity = Gravity.CENTER; setOnClickListener { openDrawer() } }, LinearLayout.LayoutParams(dp(44), -2))
        titleV = tv("Jarvis", 20f).apply { typeface = Typeface.SERIF; gravity = Gravity.CENTER }
        topBar.addView(titleV, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(tv("⚙", 22f, LAV).apply { gravity = Gravity.CENTER; setOnClickListener { go("setup") } }, LinearLayout.LayoutParams(dp(44), -2))
        shell.addView(topBar)
        content = FrameLayout(this)
        shell.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        drawerLayer = FrameLayout(this).apply { visibility = View.GONE }
        val boot = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isClickable = true }
        boot.addView(CoreView(this, true), FrameLayout.LayoutParams(-1, -1))
        val bs = tv("INITIALIZING...", 14f, LAV).apply { gravity = Gravity.CENTER; letterSpacing = 0.25f }
        val bc = col().apply {
            gravity = Gravity.CENTER
            addView(tv("J.A.R.V.I.S.", 28f, Color.WHITE, true).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); gravity = Gravity.CENTER; letterSpacing = 0.2f })
            addView(bs)
        }
        boot.addView(bc, FrameLayout.LayoutParams(-1, -1))
        root.addView(shell); root.addView(drawerLayer); root.addView(boot)
        setContentView(root)
        if (pf().getBoolean("onboarded", false)) go("home") else onboard(0)
        Sound.play("start")
        h.postDelayed({ bs.text = "SYSTEMS ONLINE" }, 2200)
        h.postDelayed({ boot.animate().alpha(0f).setDuration(700).withEndAction { boot.visibility = View.GONE }.start() }, 3400)
        h.post(object : Runnable {
            override fun run() {
                statusV?.text = when (Brain.state) { "listening" -> "Listening..."; "thinking" -> "Thinking..."; "speaking" -> "Speaking"; else -> if (Brain.waiting()) "Waiting for your yes / no" else "Say \"Hey Jarvis\"" }
                replyV?.let { r ->
                    val t = Brain.lastReply
                    if (t != typedFor) { typedFor = t; typed = 0 }
                    if (typed < t.length) { typed = minOf(t.length, typed + 2); r.text = t.substring(0, typed) }
                }
                h.postDelayed(this, 60)
            }
        })
    }
    override fun onDestroy() { tts0?.shutdown(); super.onDestroy() }
    override fun onBackPressed() { if (drawerOpen) closeDrawer() else if (topBar.visibility == View.VISIBLE && page != "home") go("home") else super.onBackPressed() }
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (topBar.visibility == View.VISIBLE) when (e.action) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.x; tracking = drawerOpen || e.x < dp(28) }
            MotionEvent.ACTION_UP -> { if (tracking) { val d = e.x - dx0; if (!drawerOpen && d > dp(70)) openDrawer() else if (drawerOpen && d < -dp(70)) closeDrawer() }; tracking = false }
        }
        return super.dispatchTouchEvent(e)
    }

    // ---------- navigation ----------
    private fun go(name: String) {
        page = name; statusV = null; replyV = null; topBar.visibility = View.VISIBLE
        titleV.text = when (name) { "home" -> "Jarvis"; "today" -> "Today"; "reminders" -> "Reminders"; "memory" -> "Memory"; "history" -> "Action history"; "creator" -> "Creator"; "report" -> "Weekly report"; "search" -> "Search"; "voice" -> "Voice lock"; else -> "Setup" }
        content.removeAllViews()
        content.addView(when (name) { "home" -> home(); "today" -> today(); "reminders" -> reminders(); "memory" -> memory(); "history" -> history(); "creator" -> creator(); "report" -> report(); "search" -> search(); "voice" -> voice(); else -> setup() }, FrameLayout.LayoutParams(-1, -1))
    }
    private fun openDrawer() {
        drawerOpen = true; drawerLayer.removeAllViews(); drawerLayer.visibility = View.VISIBLE
        val w = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val scrim = View(this).apply { setBackgroundColor(Color.argb(150, 0, 0, 0)); setOnClickListener { closeDrawer() } }
        drawerLayer.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        val panel = col().apply { setBackgroundColor(Color.argb(247, 10, 10, 14)); setPadding(dp(16), dp(44), dp(16), dp(16)); isClickable = true }
        panel.addView(tv("Jarvis", 24f).apply { typeface = Typeface.SERIF })
        val sf = field("Search memory & history").apply { imeOptions = EditorInfo.IME_ACTION_SEARCH; setSingleLine(true) }
        sf.setOnEditorActionListener { _, _, _ -> searchQ = sf.text.toString().trim(); closeDrawer(); go("search"); true }
        panel.addView(sf, lp(-1, -2, 14))
        listOf("Today" to "today", "Reminders" to "reminders", "Memory" to "memory", "Action history" to "history", "Creator" to "creator", "Weekly report" to "report", "Setup" to "setup").forEach { (l, pg) ->
            panel.addView(tv(l, 16f, if (page == pg) Color.WHITE else GRAY, page == pg).apply {
                setPadding(dp(14), dp(14), dp(14), dp(14)); if (page == pg) background = glass(30, 70, 12)
                setOnClickListener { closeDrawer(); go(pg) }
            }, lp(-1, -2, 4))
        }
        panel.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        val me = (pf().getString("uname", "") ?: "").ifEmpty { "You" }
        val prof = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = glass(); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        prof.addView(tv(me.take(1).uppercase(), 16f, Color.rgb(20, 18, 40), true).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(170, 165, 225)) } }, LinearLayout.LayoutParams(dp(38), dp(38)))
        prof.addView(tv(me, 15f).apply { setPadding(dp(12), 0, 0, 0) })
        panel.addView(prof)
        drawerLayer.addView(panel, FrameLayout.LayoutParams(w, -1))
        panel.translationX = -w.toFloat(); panel.animate().translationX(0f).setDuration(200).start()
    }
    private fun closeDrawer() {
        drawerOpen = false
        if (drawerLayer.childCount > 1) drawerLayer.getChildAt(1).animate().translationX(-drawerLayer.getChildAt(1).width.toFloat()).setDuration(170).withEndAction { drawerLayer.visibility = View.GONE }.start() else drawerLayer.visibility = View.GONE
    }

    // ---------- pages ----------
    private fun circ(t: String, size: Int, filled: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; gravity = Gravity.CENTER; setTextColor(if (filled) Color.rgb(20, 18, 40) else LAV)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; if (filled) setColor(Color.rgb(170, 165, 225)) else { setColor(Color.argb(22, 255, 255, 255)); setStroke(dp(1), Color.argb(70, 200, 195, 255)) } }
        setOnClickListener { f() }
    }.also { it.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { setMargins(dp(14), 0, dp(14), 0) } }

    private fun home(): View = col().apply {
        setPadding(dp(18), 0, dp(18), dp(16))
        val sv0 = tv("", 12f, GRAY).apply { gravity = Gravity.CENTER; letterSpacing = 0.1f }
        statusV = sv0; addView(sv0)
        addView(CoreView(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
        val rv0 = tv("", 16f).apply { gravity = Gravity.CENTER; minHeight = dp(90); setPadding(dp(8), dp(4), dp(8), dp(4)) }
        replyV = rv0; addView(rv0)
        val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER }
        row.addView(circ("✕", 52, false) { JarvisService.inst?.stopSpeak(); Brain.pending = null; toast("Stopped") })
        row.addView(circ("🎤", 76, true) {
            val sv = JarvisService.inst
            if (sv == null) toast("Finish setup / Activate Jarvis first") else if (Brain.state == "speaking") sv.stopSpeak() else sv.wakeNow()
        })
        row.addView(circ("+", 52, false) {
            val e = field("Type to Jarvis")
            AlertDialog.Builder(this@MainActivity).setTitle("Type to Jarvis").setView(e).setPositiveButton("Send") { _, _ ->
                val q = e.text.toString().trim(); if (q.isNotEmpty()) Brain.handle(this@MainActivity, q) { r -> speak(r) }
            }.show()
        })
        addView(row)
    }

    private fun today(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(sec("WATER"))
        c.addView(rowCard("${Brain.water(this)} glasses today", "+ 1 glass", { pf().edit().putString("wd", Brain.today()).putInt("w", Brain.water(this) + 1).apply(); Brain.hist(this, "Water glass"); go("today") }), lp())
        c.addView(sec("DONE TODAY"))
        val l = Brain.histList(this, true).reversed()
        if (l.isEmpty()) c.addView(tv("Nothing yet.", 14f, GRAY))
        l.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }
    private fun reminders(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(btn("+ Add reminder") {
            val e = field("What should I remind you about?")
            AlertDialog.Builder(this).setView(e).setPositiveButton("Pick time") { _, _ ->
                TimePickerDialog(this, { _, hh, mm -> Brain.addRem(this, hh, mm, e.text.toString().ifEmpty { "reminder" }, true); go("reminders") }, 8, 0, false).show()
            }.show()
        }, lp())
        c.addView(tv("Tap = change time   ·   Long-press = delete", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val a = Brain.rems(this)
        for (i in 0 until a.length()) { val o = a.getJSONObject(i)
            c.addView(rowCard(o.getString("text"), "%02d:%02d".format(o.getInt("h"), o.getInt("m")),
                { TimePickerDialog(this, { _, hh, mm -> Brain.editRem(this, i, hh, mm); go("reminders") }, o.getInt("h"), o.getInt("m"), false).show() },
                { Brain.delRem(this, i); go("reminders") }), lp(-1, -2, 6)) }
        if (a.length() == 0) c.addView(tv("No reminders yet. Say: \"Remind me at 8:30 to drink water\".", 14f, GRAY))
        return scroll(c)
    }
    private fun memory(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(btn("+ Add memory") {
            val e = field("What should Jarvis remember?")
            AlertDialog.Builder(this).setView(e).setPositiveButton("Save") { _, _ -> if (e.text.isNotBlank()) { Brain.addMem(this, e.text.toString().trim()); go("memory") } }.show()
        }, lp())
        c.addView(tv("Long-press to delete. Jarvis asks before saving anything on its own.", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val m = Brain.mem(this)
        for (i in 0 until m.length()) c.addView(rowCard(m.getString(i), "", null, { Brain.delMem(this, i); go("memory") }), lp(-1, -2, 6))
        if (m.length() == 0) c.addView(tv("Nothing saved yet.", 14f, GRAY))
        return scroll(c)
    }
    private fun history(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val l = Brain.histList(this, false).takeLast(60).reversed()
        if (l.isEmpty()) c.addView(tv("Nothing yet.", 14f, GRAY))
        l.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }
    private fun creator(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(tv("Say: \"Get this motivational video ready for Instagram\". Tap a draft to copy it.", 12f, GRAY).apply { setPadding(0, dp(8), 0, dp(4)) })
        val l = Brain.creator(this)
        if (l.isEmpty()) c.addView(tv("No drafts yet.", 14f, GRAY))
        l.forEach { d -> c.addView(rowCard(d, "", { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", d)); toast("Copied") }), lp(-1, -2, 8)) }
        return scroll(c)
    }
    private fun report(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val (ok, no) = Brain.week(this)
        c.addView(sec("LAST 7 DAYS"))
        c.addView(rowCard("Tasks done", "$ok"), lp()); c.addView(rowCard("Tasks missed", "$no"), lp(-1, -2, 6)); c.addView(rowCard("Water today", "${Brain.water(this)} glasses"), lp(-1, -2, 6))
        c.addView(tv("Tell Jarvis at night: \"Task done: edited video\" or \"Task missed: gym\".", 12f, GRAY).apply { setPadding(0, dp(12), 0, 0) })
        return scroll(c)
    }
    private fun search(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        val q = searchQ.lowercase()
        val res = ArrayList<String>()
        val m = Brain.mem(this); for (i in 0 until m.length()) if (m.getString(i).lowercase().contains(q)) res.add("Memory: " + m.getString(i))
        Brain.histList(this, false).reversed().forEach { if (it.lowercase().contains(q)) res.add(it) }
        c.addView(tv("Results for \"$searchQ\"", 13f, GRAY))
        if (res.isEmpty()) c.addView(tv("Nothing found.", 14f, GRAY).apply { setPadding(0, dp(10), 0, 0) })
        res.forEach { c.addView(rowCard(it), lp(-1, -2, 6)) }
        return scroll(c)
    }

    private fun seek(parent: LinearLayout, label: String, key: String, def: Float) {
        val s = SeekBar(this).apply { max = 100; progress = (pf().getFloat(key, def) * 100 - 50).toInt() }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, v: Int, u: Boolean) { pf().edit().putFloat(key, (v + 50) / 100f).apply(); JarvisService.inst?.applyVoice() }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        parent.addView(card(tv(label, 13f, GRAY), s), lp(-1, -2, 6))
    }
    private fun card(vararg v: View) = col().apply { background = glass(); setPadding(dp(14), dp(12), dp(14), dp(12)); v.forEach { addView(it) } }

    private fun setup(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        fun r(t: String, v: String, f: () -> Unit) = c.addView(rowCard(t, v, f), lp(-1, -2, 6))
        val prov = pf().getString("provider", "gemini")
        c.addView(sec("YOUR JARVIS"))
        r("Your name", (pf().getString("uname", "") ?: "").ifEmpty { "Not set" }) { editDialog("Your name", "uname") }
        r("Address me as", pf().getString("title", "Sir") ?: "Sir") { editDialog("Address me as", "title") }
        r("Mode", Brain.mode(this)) { listDialog("Mode", listOf("work", "normal", "friend", "creator", "silent")) { i -> pf().edit().putString("mode", listOf("work", "normal", "friend", "creator", "silent")[i]).apply(); go("setup") } }
        c.addView(sec("AI BRAIN"))
        r("Provider", if (prov == "gemini") "Gemini (free)" else "Claude") { pf().edit().putString("provider", if (prov == "gemini") "claude" else "gemini").apply(); go("setup") }
        r("Gemini key", mask("gkey")) { editDialog("Gemini key", "gkey") }
        r("Gemini model", pf().getString("gmodel", "gemini-flash-latest") ?: "") { editDialog("Gemini model", "gmodel") }
        r("Claude key", mask("key")) { editDialog("Claude key", "key") }
        c.addView(sec("VOICE"))
        r("Phone voice", "Choose") {
            val vs = JarvisService.inst?.voiceList() ?: emptyList()
            if (vs.isEmpty()) toast("Activate Jarvis first") else listDialog("Voice", vs.map { "${it.locale.displayName} - ${it.name}" }) { i -> pf().edit().putString("voice", vs[i].name).apply(); JarvisService.inst?.applyVoice(); speak("This is my new voice.") }
        }
        seek(c, "Pitch (lower = deeper)", "pitch", 0.85f)
        seek(c, "Speed", "rate", 0.95f)
        r("Test voice", "▶") { speak("Systems online. How can I help you?") }
        r("ElevenLabs key", mask("elkey")) { editDialog("ElevenLabs key", "elkey") }
        val ids = listOf("onwK4e9ZLuTAKqWW03F9", "JBFqnCBsd6RMkjVDRZzb", "pNInz6obpgDQGcFmaJgB", "IKne3meq5aSn9XLyUdCD")
        r("ElevenLabs voice", (pf().getString("elvoice", "") ?: "").let { if (it.isEmpty()) "Off" else "On" }) {
            listDialog("ElevenLabs voice", listOf("Daniel (British)", "George (British, warm)", "Adam (American)", "Charlie (British)", "My own voice ID", "Turn off")) { i ->
                if (i < 4) { pf().edit().putString("elvoice", ids[i]).apply(); go("setup") } else if (i == 4) editDialog("ElevenLabs voice ID", "elvoice") else { pf().edit().remove("elvoice").apply(); go("setup") }
            }
        }
        c.addView(sec("APP"))
        r("Language", when (pf().getString("lang", "english")) { "roman" -> "Roman Urdu"; "hindi" -> "Hindi"; "mix" -> "English + Urdu"; else -> "English" }) {
            listDialog("Jarvis speaks", listOf("English", "Roman Urdu", "Hindi", "English + Urdu")) { i -> pf().edit().putString("lang", listOf("english", "roman", "hindi", "mix")[i]).apply(); go("setup") }
        }
        r("Startup sound", if (Sound.on) "On" else "Off") { Sound.on = !Sound.on; pf().edit().putBoolean("snd", Sound.on).apply(); go("setup") }
        c.addView(sec("VOICE LOCK (ONLY MY VOICE)"))
        r("Voice lock", if (VoiceLock.enabled(this)) "On" else "Off") {
            if (VoiceLock.load(this) == null) { toast("Set up your voice first"); samples.clear(); go("voice") }
            else { pf().edit().putBoolean("vlock", !pf().getBoolean("vlock", false)).apply(); JarvisService.inst?.applyLock(); go("setup") }
        }
        r("Set up / redo my voice", "") { samples.clear(); go("voice") }
        r("Strictness", pf().getString("vstrict", "normal") ?: "normal") { listDialog("Strictness", listOf("loose", "normal", "strict")) { i -> pf().edit().putString("vstrict", listOf("loose", "normal", "strict")[i]).apply(); go("setup") } }
        r("Test my voice", "3 sec") { runTest() }
        r("Last live check", VoiceLock.status.take(26)) { AlertDialog.Builder(this).setTitle("Last live check").setMessage(VoiceLock.status).setPositiveButton("OK", null).show() }
        r("Delete my voice", "") { VoiceLock.delete(this); pf().edit().putBoolean("vlock", false).apply(); JarvisService.inst?.applyLock(); go("setup") }
        r("Smart Lock / security settings", "") { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        c.addView(sec("ADVANCED"))
        r("Activate Jarvis (permissions)", "") { start() }
        r("Battery: set to Unrestricted", "") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        c.addView(sec("ABOUT"))
        r("Restart setup", "") { pf().edit().putBoolean("onboarded", false).apply(); onboard(0) }
        return scroll(c)
    }

    // ---------- voice lock ----------
    private val samples = ArrayList<DoubleArray>()
    private val phrases = listOf("Hey Jarvis, it's me. Good to see you.", "The quick brown fox jumps over the lazy dog.", "Open YouTube and play something relaxing.", "Remind me to drink water every two hours.", "Jarvis, what is on my schedule for tomorrow?")
    private fun withMic(sec: Int, done: (ShortArray?) -> Unit) {
        JarvisService.inst?.pauseListening(true); VoiceLock.stopCapture()
        Thread {
            val x: ShortArray? = try { VoiceLock.record(sec) } catch (e: Exception) { null }
            runOnUiThread { JarvisService.inst?.pauseListening(false); JarvisService.inst?.applyLock(); done(x) }
        }.start()
    }
    private fun runTest() {
        toast("Speak for 3 seconds...")
        withMic(3) { x ->
            val msg = if (x == null) "Mic is busy. Try again." else VoiceLock.evaluate(this, x)
            AlertDialog.Builder(this).setTitle("Voice test").setMessage(msg).setPositiveButton("OK", null).show()
        }
    }
    private fun voice(): View {
        val c = col().apply { setPadding(dp(18), dp(4), dp(18), dp(24)) }
        c.addView(tv("Jarvis will answer only your voice. Record 5 short phrases in a quiet place. This is best-effort matching, not a security lock.", 13f, GRAY))
        val n = samples.size
        c.addView(tv(if (n < 5) "Say:\n\"${phrases[n]}\"" else "All 5 phrases recorded.", 18f).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(28), dp(8), dp(28)) })
        c.addView(btn(if (n < 5) "Record phrase ${n + 1} of 5 (5 sec)" else "Save my voice") {
            if (n >= 5) {
                VoiceLock.save(this, VoiceLock.build(samples)); samples.clear()
                pf().edit().putBoolean("vlock", true).apply(); JarvisService.inst?.applyLock(); toast("Voice saved. Voice lock is on."); go("setup")
            } else {
                toast("Recording... speak now")
                withMic(5) { x ->
                    val v = if (x == null) null else VoiceLock.features(x)
                    if (v == null) toast("Too quiet or too short, try again") else samples.add(v)
                    if (page == "voice") go("voice")
                }
            }
        }, lp(-1, dp(52), 8))
        if (n > 0) c.addView(btn("Start over", false) { samples.clear(); go("voice") }, lp(-1, -2, 8))
        return scroll(c)
    }

    // ---------- onboarding ----------
    private fun obCol(step: Int, title: String, body: String) = col().apply {
        gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(26), dp(50), dp(26), dp(26))
        if (step > 0) addView(tv("STEP $step OF 5", 11f, GRAY).apply { letterSpacing = 0.2f; gravity = Gravity.CENTER })
        addView(serif(title, 26f), lp(-1, -2, 12))
        if (body.isNotEmpty()) addView(tv(body, 14f, GRAY).apply { gravity = Gravity.CENTER }, lp(-1, -2, 12))
    }
    private fun onboard(step: Int) {
        page = "onboard"; topBar.visibility = View.GONE; statusV = null; replyV = null; content.removeAllViews()
        val v: View = when (step) {
            0 -> col().apply {
                gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(26), dp(40), dp(26), dp(30))
                addView(CoreView(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(serif("Hi. I'm Jarvis.", 32f))
                addView(tv("Your AI that talks, listens, and remembers you, right from your pocket.", 14f, GRAY).apply { gravity = Gravity.CENTER }, lp(-1, -2, 12))
                addView(btn("Meet Jarvis →") { onboard(1) }, lp(-1, dp(52), 24))
            }
            1 -> obCol(1, "What should Jarvis call you?", "So every hello is yours.").apply {
                val e = field("Your name"); e.gravity = Gravity.CENTER; addView(e, lp(-1, -2, 20))
                addView(btn("Continue →") { val n = e.text.toString().trim(); if (n.isNotEmpty()) { pf().edit().putString("uname", n).putString("title", n).apply(); onboard(2) } else toast("Please type a name") }, lp(-1, dp(52), 20))
            }
            2 -> obCol(2, "Bring your own key.", "Your key stays on this phone. Gemini has a free key: open aistudio.google.com, tap Get API key, and paste it here.").apply {
                val prov = pf().getString("provider", "gemini")
                val ch = LinearLayout(this@MainActivity)
                listOf("gemini" to "Gemini (free)", "claude" to "Claude").forEach { (k, n) ->
                    ch.addView(tv(n, 14f, if (prov == k) Color.rgb(20, 18, 40) else LAV).apply {
                        gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12))
                        background = if (prov == k) GradientDrawable().apply { setColor(Color.rgb(170, 165, 225)); cornerRadius = dp(12).toFloat() } else glass()
                        setOnClickListener { pf().edit().putString("provider", k).apply(); onboard(2) }
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
                }
                addView(ch, lp(-1, -2, 18))
                val kk = if (prov == "gemini") "gkey" else "key"
                val e = field(if (prov == "gemini") "Paste Gemini key" else "Paste Claude key", pf().getString(kk, "") ?: "")
                addView(e, lp(-1, -2, 14))
                addView(btn("Continue →") { pf().edit().putString(kk, e.text.toString().trim()).apply(); onboard(3) }, lp(-1, dp(52), 18))
                addView(btn("Skip for now", false) { onboard(3) }, lp(-1, -2, 6))
            }
            3 -> obCol(3, "Find Jarvis's voice.", "Tap to listen. You can change this later.").apply {
                val list = col()
                addView(scroll(list), LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(14), 0, 0) })
                addView(btn("Sounds right →") { tts0?.shutdown(); tts0 = null; onboard(4) }, lp(-1, dp(52), 12))
                tts0 = TextToSpeech(this@MainActivity) { _ ->
                    runOnUiThread {
                        val vs: List<Voice> = try { tts0!!.voices.filter { it.locale.language in listOf("en", "hi", "ur") }.sortedBy { it.name } } catch (e: Exception) { emptyList() }
                        if (vs.isEmpty()) list.addView(tv("No voices found. You can pick one later in Setup.", 14f, GRAY))
                        val rows = ArrayList<TextView>()
                        vs.forEach { vo ->
                            val row = tv("${vo.locale.displayName}\n${vo.name}", 14f).apply { setPadding(dp(14), dp(12), dp(14), dp(12)); background = glass() }
                            rows.add(row)
                            row.setOnClickListener {
                                rows.forEach { it.background = glass(); it.setTextColor(Color.WHITE) }
                                row.background = GradientDrawable().apply { setColor(Color.rgb(170, 165, 225)); cornerRadius = dp(16).toFloat() }; row.setTextColor(Color.rgb(20, 18, 40))
                                pf().edit().putString("voice", vo.name).apply()
                                try { tts0?.setVoice(vo); tts0?.setPitch(0.85f); tts0?.speak("Hi, I'm Jarvis.", TextToSpeech.QUEUE_FLUSH, null, "s") } catch (e: Exception) {}
                            }
                            list.addView(row, lp(-1, -2, 6))
                        }
                    }
                }
            }
            4 -> obCol(4, "Jarvis works while you're away.", "Reminders and check-ins reach you at the right moment. One nudge when it matters, never spam. You can change this anytime in Setup.").apply {
                addView(View(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(btn("Continue →") { if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2) else onboard(5) }, lp(-1, dp(52), 12))
                addView(btn("Not now", false) { onboard(5) }, lp(-1, -2, 6))
            }
            else -> obCol(5, "Jarvis needs to hear you.", "The mic is used only while Jarvis is listening for \"Hey Jarvis\" or a command. Calls and contacts are used only when you ask Jarvis to call someone.").apply {
                addView(View(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
                addView(btn("Continue →") { start() }, lp(-1, dp(52), 12))
                addView(btn("I'll type instead", false) { finishOnboarding() }, lp(-1, -2, 6))
            }
        }
        content.addView(v, FrameLayout.LayoutParams(-1, -1))
    }
    private fun finishOnboarding() { pf().edit().putBoolean("onboarded", true).apply(); tts0?.shutdown(); tts0 = null; go("home") }

    // ---------- permissions ----------
    private fun start() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (c == 2) { onboard(5); return }
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) {
            tts0?.shutdown(); tts0 = null
            startForegroundService(Intent(this, JarvisService::class.java)); toast("Jarvis is on")
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else toast("Microphone permission is needed for voice")
        if (!pf().getBoolean("onboarded", false)) finishOnboarding()
    }
}
