package com.sam.jarvis
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.util.Base64
import android.view.Display
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Lets Jarvis see and operate other apps when the user asks. Password fields are never read or typed into.
class JarvisAccess : AccessibilityService() {
    companion object { var inst: JarvisAccess? = null }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "I can't see any screen content right now."
        val out = StringBuilder(); var n = 0
        fun walk(nd: AccessibilityNodeInfo?) {
            if (nd == null || n > 160) return
            if (nd.isPassword) { out.append("[password field hidden]\n"); n++; return }
            val t = (nd.text ?: nd.contentDescription)?.toString()
            if (!t.isNullOrBlank()) { out.append(if (nd.isEditable) "[input] " else if (nd.isClickable) "[button] " else "").append(t.take(90)).append('\n'); n++ }
            else if (nd.isEditable) { out.append("[empty input]\n"); n++ }
            for (i in 0 until nd.childCount) walk(nd.getChild(i))
        }
        walk(root)
        return "App: " + (root.packageName?.toString() ?: "?") + "\n" + out.toString().ifBlank { "No readable text on this screen." }
    }
    fun tapText(t: String): String {
        val root = rootInActiveWindow ?: return "I can't see the screen."
        val nodes = root.findAccessibilityNodeInfosByText(t)
        if (nodes.isNullOrEmpty()) return "I could not find \"$t\" on the screen."
        var nd: AccessibilityNodeInfo? = nodes.firstOrNull { it.isVisibleToUser } ?: nodes[0]
        if (nd?.isPassword == true) return "That is a password field. I will not touch it."
        while (nd != null && !nd.isClickable) nd = nd.parent
        if (nd == null) {
            val r = Rect(); nodes[0].getBoundsInScreen(r)
            return if (tapXY(r.centerX().toFloat(), r.centerY().toFloat())) "Tapped \"$t\"." else "I could not tap \"$t\"."
        }
        return if (nd.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "Tapped \"$t\"." else "I could not tap \"$t\"."
    }
    fun tapXY(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build(), null, null)
    }
    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
    }
    fun scroll(dir: String): Boolean {
        val dm = resources.displayMetrics; val w = dm.widthPixels.toFloat(); val hh = dm.heightPixels.toFloat()
        return when (dir.lowercase()) {
            "down" -> swipe(w / 2, hh * 0.7f, w / 2, hh * 0.3f)
            "up" -> swipe(w / 2, hh * 0.3f, w / 2, hh * 0.7f)
            "left" -> swipe(w * 0.2f, hh / 2, w * 0.8f, hh / 2)
            "right" -> swipe(w * 0.8f, hh / 2, w * 0.2f, hh / 2)
            else -> false
        }
    }
    private fun findEditable(nd: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (nd == null) return null
        if (nd.isEditable) return nd
        for (i in 0 until nd.childCount) { val r = findEditable(nd.getChild(i)); if (r != null) return r }
        return null
    }
    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "I can't see the screen."
        var f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null) f = findEditable(root)
        if (f == null) return "I could not find a text box."
        if (f.isPassword) return "That is a password field. I will not type there."
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Typed the text." else "I could not type the text."
    }
    fun press(b: String): Boolean = when (b.lowercase()) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        else -> false
    }

    class Elem(val id: Int, val kind: String, val text: String, val x: Int, val y: Int, val node: AccessibilityNodeInfo?)
    @Volatile var elems: List<Elem> = emptyList()

    // numbered list of what is on the screen, with positions; password fields are never described
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "No screen content."
        val out = ArrayList<Elem>()
        fun walk(nd: AccessibilityNodeInfo?) {
            if (nd == null || out.size >= 90) return
            if (nd.isPassword) { out.add(Elem(out.size, "password", "[password field]", 0, 0, null)); return }
            val t = (nd.text ?: nd.contentDescription)?.toString()?.trim().orEmpty()
            val hasAct = nd.isClickable || nd.isEditable || nd.isCheckable
            if ((t.isNotEmpty() || hasAct) && nd.isVisibleToUser) {
                val r = Rect(); nd.getBoundsInScreen(r)
                if (r.width() > 0 && r.height() > 0) out.add(Elem(out.size, if (nd.isEditable) "input" else if (nd.isClickable) "button" else "text", t.take(60).ifEmpty { nd.viewIdResourceName?.substringAfter('/') ?: "?" }, r.centerX(), r.centerY(), nd))
            }
            for (i in 0 until nd.childCount) walk(nd.getChild(i))
        }
        walk(root); elems = out
        val dm = resources.displayMetrics
        return "App: ${root.packageName}; screen ${dm.widthPixels}x${dm.heightPixels}\n" + out.joinToString("\n") { "[${it.id}] ${it.kind} \"${it.text}\" @${it.x},${it.y}" }
    }
    fun tapId(id: Int): String {
        val e = elems.getOrNull(id) ?: return "There is no element $id."
        if (e.kind == "password") return "That is a password field. I will not touch it."
        var nd = e.node
        while (nd != null && !nd.isClickable) nd = nd.parent
        if (nd != null && nd.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "Tapped [$id] \"${e.text}\"."
        return if (tapXY(e.x.toFloat(), e.y.toFloat())) "Tapped [$id] \"${e.text}\" by position." else "Could not tap [$id]."
    }
    fun tapNorm(nx: Float, ny: Float): String {
        val dm = resources.displayMetrics
        return if (tapXY(nx / 1000f * dm.widthPixels, ny / 1000f * dm.heightPixels)) "Tapped at ($nx, $ny)." else "Could not tap there."
    }
    // small JPEG of the screen for the vision model (Android 11+)
    fun screenshotB64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1); var out: String? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = r.hardwareBuffer; val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        if (bmp != null) {
                            val sw = bmp.copy(Bitmap.Config.ARGB_8888, false)
                            val sc = Bitmap.createScaledBitmap(sw, 540, (540f * sw.height / sw.width).toInt(), true)
                            val bo = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 65, bo)
                            out = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                        }
                        hb.close()
                    } catch (e: Exception) {}
                    latch.countDown()
                }
                override fun onFailure(code: Int) { latch.countDown() }
            })
        } catch (e: Exception) { return null }
        latch.await(4, TimeUnit.SECONDS)
        return out
    }
}
