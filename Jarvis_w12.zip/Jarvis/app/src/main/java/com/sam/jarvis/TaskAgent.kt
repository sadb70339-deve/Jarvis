package com.sam.jarvis
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

// Runs an instruction in the background with the phone tools and web research (routines, research, planning).
object TaskAgent {
    private val skip = setOf("read_screen", "tap_text", "scroll", "type_text", "press", "run_in_background")
    private fun decls(): JSONArray { val out = JSONArray(); for (i in 0 until Tools.decl.length()) { val d = Tools.decl.getJSONObject(i); if (d.getString("name") !in skip) out.put(d) }; return out }
    fun start(c: Context, instruction: String, label: String) {
        thread { try { run(c, instruction, label) } catch (e: Exception) { Tools.card(c, "Background task failed", e.message ?: "") } }
    }
    private fun run(c: Context, instruction: String, label: String) {
        val p = Brain.prefs(c); val key = p.getString("gkey", "") ?: ""; val model = p.getString("tmodel", "gemini-flash-latest") ?: "gemini-flash-latest"
        if (key.isEmpty()) { Tools.card(c, "Background task skipped", "No Gemini key"); return }
        val sys = "You are JARVIS working silently in the background for the user. Use the tools to complete the instruction; use research for facts from the web. Be efficient. At the end write a short plain summary of what you did and found (under 600 characters), in simple Roman Urdu mixed with English."
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "INSTRUCTION: $instruction\nCONTEXT: " + Brain.overview(c)))))
        for (step in 1..12) {
            val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents).put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls())))
            val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            con.connectTimeout = 10000; con.readTimeout = 60000; con.requestMethod = "POST"; con.doOutput = true
            con.setRequestProperty("x-goog-api-key", key); con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.write(body.toString().toByteArray())
            if (con.responseCode >= 300) { finish(c, label, "The model did not answer (HTTP " + con.responseCode + ")."); return }
            val content = JSONObject(con.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            contents.put(content)
            val resp = JSONArray(); var text = ""
            for (i in 0 until parts.length()) {
                val pt = parts.getJSONObject(i); val fc = pt.optJSONObject("functionCall")
                if (fc != null) {
                    val r = try { Tools.run(c, fc.getString("name"), fc.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "Failed: " + e.message }
                    resp.put(JSONObject().put("functionResponse", JSONObject().put("name", fc.getString("name")).put("response", JSONObject().put("result", r))))
                } else text += pt.optString("text")
            }
            if (resp.length() == 0) { finish(c, label, text); return }
            contents.put(JSONObject().put("role", "user").put("parts", resp))
        }
        finish(c, label, "I reached the step limit.")
    }
    private fun finish(c: Context, label: String, text: String) {
        val t = text.trim().ifEmpty { "Done." }
        Brain.addNote(c, "[" + label + "] " + t.take(700)); Tools.card(c, "Finished: $label", t.take(200))
        JarvisService.inst?.announce("The background task \"$label\" finished: " + t.take(300))
    }
}
