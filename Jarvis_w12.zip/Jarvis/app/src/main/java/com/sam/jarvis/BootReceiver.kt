package com.sam.jarvis
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { try { Brain.rescheduleAll(c) } catch (e: Exception) {} }
}
