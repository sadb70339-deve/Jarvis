package com.sam.jarvis
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

// Gemini Live: one WebSocket that hears, thinks and speaks.
class LiveClient(private val svc: JarvisService) {
    private val h = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val player = Executors.newSingleThreadExecutor()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile var active = false
    @Volatile private var ready = false
    @Volatile private var gen = 0
    @Volatile private var pgen = 0
    @Volatile private var endAt = 0L
    private var noSearch = false
    private val stopRe = Regex("\\b(chup|ruko|ruk jao|stop|suno|quiet|bas karo|wait|hold on)\\b")
    @Volatile private var written = 0
    @Volatile private var turnChecked = false
    @Volatile private var blockTurn = false
    @Volatile private var headsetOn = false
    private val startPlay = Runnable { try { track?.let { if (it.playState != AudioTrack.PLAYSTATE_PLAYING) it.play() } } catch (e: Exception) {} }
    private var usedSearch = false
    private var first: String? = null
    private val uT = StringBuilder(); private val oT = StringBuilder(); private var newTurn = true
    private var oldMode = AudioManager.MODE_NORMAL
    private var idle: Runnable? = null

    private fun speed() = Brain.prefs(svc).getFloat("lspeed", 1.15f)
    private fun headset(am: AudioManager) = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
        it.type in listOf(AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_HEARING_AID, 26)
    }
    private fun toolsJson(p: android.content.SharedPreferences): JSONArray {
        val t = JSONArray().put(JSONObject().put("functionDeclarations", Tools.decl))
        usedSearch = p.getBoolean("lsearch", true) && !noSearch
        if (usedSearch) t.put(JSONObject().put("googleSearch", JSONObject()))
        return t
    }
    // when Voice lock is on, a turn is only acted on if the voice sounded like the owner
    private fun allowTurn(): Boolean {
        if (turnChecked) return !blockTurn
        turnChecked = true
        if (VoiceLock.enabled(svc) && !VoiceLock.accept(svc)) { blockTurn = true; h.post { interrupt() } }
        return !blockTurn
    }
    private fun retryNoSearch(g: Int): Boolean {
        if (g != gen || ready || !usedSearch || noSearch) return false
        h.post { val f = first; close(); noSearch = true; open(f) }
        return true
    }
    private fun setup(c: Context): JSONObject {
        val p = Brain.prefs(c)
        val voice = p.getString("lvoice", "Charon") ?: "Charon"; val model = p.getString("lmodel", "gemini-3.1-flash-live-preview") ?: ""
        return JSONObject().put("setup", JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Brain.liveSystem(c)))))
            .put("tools", toolsJson(p))
            .put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject()))
    }
    fun open(firstText: String?) {
        if (active) { if (firstText != null) sendText(firstText); return }
        val c: Context = svc; val key = Brain.prefs(c).getString("gkey", "") ?: ""
        if (key.isEmpty()) { svc.say(Brain.L(c, "Please add your Gemini key in Settings.", "Settings mein Gemini key daal do."), true); return }
        active = true; ready = false; first = firstText; Brain.state = "thinking"
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        oldMode = am.mode; headsetOn = headset(am)
        // with earbuds (wired or bluetooth) keep normal audio so the sound goes to them; on the phone speaker use call mode for echo control
        if (headsetOn) am.isSpeakerphoneOn = false else { am.mode = AudioManager.MODE_IN_COMMUNICATION; am.isSpeakerphoneOn = true }
        val g = ++gen
        val req = Request.Builder().url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key").build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setup(c).toString()) }
            override fun onMessage(webSocket: WebSocket, text: String) { handle(g, text) }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) { handle(g, bytes.utf8()) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { if (retryNoSearch(g)) return; Brain.lastError = "Live connection: " + (t.message ?: "failed"); fail(g, Brain.L(c, "Live connection failed. Check your key and model in Settings.", "Live connection nahi bani. Settings mein key aur model check karo.")) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (retryNoSearch(g)) return; if (g == gen) h.post { if (!ready && reason.isNotEmpty()) { Brain.lastError = "Live closed: $reason"; svc.say(reason.take(100), true) }; close() } }
        })
    }
    private fun fail(g: Int, msg: String) { if (g != gen) return; h.post { close(); svc.say(msg, true) } }
    fun sendText(t: String) { ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString()); h.post { resetIdle() } }
    private fun resetIdle() { idle?.let { h.removeCallbacks(it) }; val r = Runnable { close() }; idle = r; h.postDelayed(r, 60000) }

    private fun sendAudio(b: ByteArray) { ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject().put("data", Base64.encodeToString(b, Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000"))).toString()) }
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(if (headsetOn) MediaRecorder.AudioSource.MIC else MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400)); rec = r
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true; if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true } catch (e: Exception) {}
        r.startRecording(); val g = gen
        Thread {
            val buf = ByteArray(3200); var prev: ByteArray? = null; var openUntil = 0L; var wasOpen = false; var lastBarge = 0L
            while (active && g == gen) {
                val n = r.read(buf, 0, buf.size)
                if (n <= 0) continue
                val now = System.currentTimeMillis()
                var sum = 0.0; var i = 0
                while (i + 1 < n) { val v = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xff)).toShort().toInt(); sum += v.toDouble() * v; i += 2 }
                val rms = Math.sqrt(sum / maxOf(1, n / 2))
                val thr = Brain.prefs(svc).getInt("gate", 500)
                if (thr > 0 && rms > thr) openUntil = now + 500
                val open = thr == 0 || now < openUntil
                val talking = Brain.state == "speaking" || now < endAt + 350
                val data = buf.copyOf(n)
                val loud = rms > 1800 && Brain.prefs(svc).getBoolean("barge", true)
                if (loud && talking && now - lastBarge > 1500) { lastBarge = now; h.post { interrupt() } }
                if (ready) {
                    // quiet or far-away voices and Jarvis's own voice are replaced by silence, so the server still hears a steady stream
                    if ((talking && !headsetOn && !loud) || !open) { sendAudio(ByteArray(n)); wasOpen = false }
                    else { if (!wasOpen && prev != null) sendAudio(prev); sendAudio(data); wasOpen = true }
                }
                prev = data
            }
        }.start()
    }
    private fun ensureTrack(): AudioTrack {
        track?.let { return it }
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(if (headsetOn) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min * 8, 96000))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track = t; written = 0; return t
    }
    // collect a little audio first, then play, so speech does not stutter
    private fun enqueue(b64: String) {
        if (!allowTurn()) return
        val bytes = Base64.decode(b64, Base64.DEFAULT); val g = gen; val pg = pgen
        Brain.state = "speaking"
        val now = System.currentTimeMillis(); val ms = bytes.size / 2 * 1000L / 24000
        endAt = maxOf(endAt, now) + ms + (if (written == 0) 250 else 0)
        player.execute {
            if (g == gen && pg == pgen && active) try {
                val t = ensureTrack(); t.write(bytes, 0, bytes.size); written += bytes.size
                if (written >= 16800) { h.post(startPlay) } else { h.removeCallbacks(startPlay); h.postDelayed(startPlay, 140) }
            } catch (e: Exception) {}
        }
        h.postDelayed({ if (g == gen && System.currentTimeMillis() >= endAt - 50 && Brain.state == "speaking") { Brain.state = "listening"; VoiceLock.speakEnd = System.currentTimeMillis() } }, endAt - now + 250)
    }
    fun interrupt() { pgen++; endAt = 0; written = 0; try { track?.pause(); track?.flush() } catch (e: Exception) {}; if (active) Brain.state = "listening" }

    private fun handle(g: Int, text: String) {
        if (g != gen) return
        val m = try { JSONObject(text) } catch (e: Exception) { return }
        if (m.has("setupComplete")) {
            h.post { if (g == gen && active) { ready = true; if (noSearch) { Brain.prefs(svc).edit().putBoolean("lsearch", false).apply(); noSearch = false }; startMic(); Brain.state = "listening"; first?.let { sendText(it) }; first = null; resetIdle() } }
            return
        }
        val c = m.optJSONObject("serverContent")
        if (c != null) {
            if (c.optBoolean("interrupted")) h.post { interrupt() }
            c.optJSONObject("inputTranscription")?.let { uT.append(it.optString("text")); Brain.heard = uT.toString(); svc.touch(); if (Brain.state == "speaking" && stopRe.containsMatchIn(uT.toString().takeLast(40).lowercase())) h.post { interrupt() }; h.post { resetIdle() } }
            c.optJSONObject("outputTranscription")?.let { if (blockTurn) return@let; if (newTurn) { oT.setLength(0); newTurn = false }; oT.append(it.optString("text")); Brain.lastReply = oT.toString() }
            val parts = c.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) for (i in 0 until parts.length()) { val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data"); if (!d.isNullOrEmpty()) enqueue(d) }
            if (c.optBoolean("turnComplete")) {
                val u = uT.toString().trim(); val o = oT.toString().trim()
                if (u.isNotEmpty() && !blockTurn) { Brain.chat.add("YOU" to u); Brain.logChat(svc, "YOU", u); Brain.hist(svc, "You: $u") }
                if (o.isNotEmpty() && !blockTurn) { Brain.chat.add("JARVIS" to o); Brain.logChat(svc, "JARVIS", o); Brain.hist(svc, "Jarvis: $o") }
                uT.setLength(0); oT.setLength(0); Brain.heard = ""; newTurn = true; turnChecked = false; blockTurn = false; h.post { h.removeCallbacks(startPlay); h.post(startPlay); h.postDelayed({ if (System.currentTimeMillis() >= endAt) { try { track?.stop() } catch (e: Exception) {}; written = 0 } }, maxOf(0L, endAt - System.currentTimeMillis()) + 400) }; svc.touch(); h.post { resetIdle() }
            }
        }
        val calls = m.optJSONObject("toolCall")?.optJSONArray("functionCalls")
        if (calls != null) Thread {
            val out = JSONArray()
            for (i in 0 until calls.length()) {
                val f = calls.getJSONObject(i)
                val r = if (!allowTurn()) "Blocked: this voice did not match the owner. Do nothing." else try { Tools.run(svc, f.getString("name"), f.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "Failed: " + e.message }
                out.put(JSONObject().put("id", f.getString("id")).put("name", f.getString("name")).put("response", JSONObject().put("result", r)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
        }.start()
    }
    fun close() {
        if (!active && ws == null) return
        val wasReady = ready
        active = false; ready = false; gen++; pgen++
        if (wasReady) try { Brain.summarize(svc) } catch (e: Exception) {}
        idle?.let { h.removeCallbacks(it) }
        try { ws?.close(1000, "bye") } catch (e: Exception) {}; ws = null
        try { rec?.stop(); rec?.release() } catch (e: Exception) {}; rec = null
        try { track?.release() } catch (e: Exception) {}; track = null
        try { val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager; am.mode = oldMode; am.isSpeakerphoneOn = false } catch (e: Exception) {}
        Brain.state = "idle"; svc.onLiveClosed()
    }
}
