package com.sam.jarvis
import android.content.Context
import android.os.PowerManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

// Looks at the screen (element list + screenshot), picks one action, does it, checks the result, repeats.
object GuiAgent {
    @Volatile var running = false
    @Volatile private var cancelled = false
    class Act(val name: String, val args: JSONObject)
    private val risky = Regex("(?i)\\b(send|post|share|pay|buy|order|confirm|transfer|delete|remove|uninstall|purchase|checkout|publish|submit|bhejo)\\b")
    private fun s(d: String = "") = JSONObject().put("type", "STRING").put("description", d)
    private fun n(d: String = "") = JSONObject().put("type", "INTEGER").put("description", d)
    private fun fn(name: String, desc: String, props: JSONObject, req: List<String>) = JSONObject().put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", JSONArray(req)))
    private val decl = JSONArray()
        .put(fn("tap_id", "Tap a numbered element from the screen list.", JSONObject().put("id", n("Element number")), listOf("id")))
        .put(fn("tap_xy", "Tap a point seen in the screenshot. x and y run 0-1000 across the screen.", JSONObject().put("x", n("0-1000")).put("y", n("0-1000")).put("what", s("What you are tapping")), listOf("x", "y", "what")))
        .put(fn("type_text", "Type text into the focused text box.", JSONObject().put("text", s("Text")), listOf("text")))
        .put(fn("scroll", "Scroll the screen.", JSONObject().put("direction", s("up, down, left or right")), listOf("direction")))
        .put(fn("press", "Press a system button.", JSONObject().put("button", s("back, home, recents or notifications")), listOf("button")))
        .put(fn("open_app", "Open an app by name.", JSONObject().put("name", s("App name")), listOf("name")))
        .put(fn("wait", "Wait for the screen to load.", JSONObject().put("seconds", n("1 to 5")), listOf("seconds")))
        .put(fn("ask_user", "Stop and ask the user a question.", JSONObject().put("question", s("The question")), listOf("question")))
        .put(fn("done", "The goal is finished, or cannot be finished.", JSONObject().put("summary", s("What happened, honestly")), listOf("summary")))

    fun cancel() { cancelled = true }
    fun start(c: Context, goal: String, confirmed: Boolean): String {
        if (!Brain.prefs(c).getBoolean("agent", true)) return "Agent mode is turned off in Settings."
        if (running) return "The phone agent is already working on something."
        if (JarvisAccess.inst == null) return "Accessibility is off. Ask the user to turn Jarvis on in the Accessibility settings."
        if (!(c.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) return "The screen is off. The agent needs the phone unlocked with the screen on."
        running = true; cancelled = false
        Tools.card(c, "Agent started", goal.take(80))
        thread { try { loop(c, goal, confirmed) } catch (e: Exception) { finish(c, "The agent hit an error: " + e.message) } }
        return "Started. I will report when it is done."
    }
    private fun finish(c: Context, msg: String) {
        running = false; Tools.card(c, "Agent finished", msg)
        JarvisService.inst?.announce("The phone agent reports: $msg")
    }
    private fun callModel(c: Context, body: JSONObject): Act? {
        val p = Brain.prefs(c); val key = p.getString("gkey", "") ?: ""; val model = p.getString("amodel", "gemini-flash-latest") ?: "gemini-flash-latest"
        return try {
            val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            con.connectTimeout = 10000; con.readTimeout = 60000; con.requestMethod = "POST"; con.doOutput = true
            con.setRequestProperty("x-goog-api-key", key); con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.write(body.toString().toByteArray())
            if (con.responseCode >= 300) { Brain.lastError = "Agent model HTTP " + con.responseCode; return null }
            val parts = JSONObject(con.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            for (i in 0 until parts.length()) { val fc = parts.getJSONObject(i).optJSONObject("functionCall"); if (fc != null) return Act(fc.getString("name"), fc.optJSONObject("args") ?: JSONObject()) }
            null
        } catch (e: Exception) { Brain.lastError = "Agent model: " + e.message; null }
    }
    private fun loop(c: Context, goal: String, confirmed: Boolean) {
        val steps = ArrayList<String>(); var last = "none"; var allow = confirmed; var repeat = 0; var prevSig = ""
        val system = "You operate an Android phone for the user, like a careful human. Each turn you get the goal, the steps already done, the numbered list of elements on the screen and a screenshot. Choose exactly ONE function call. Prefer tap_id; use tap_xy only when the target is not in the list. After each action look at the new screen to check that it worked; if not, try another way. Never type or reveal passwords, OTPs or card details. Never tap send, post, share, pay, buy, delete or confirm unless the user already confirmed it; call ask_user instead. When finished or stuck, call done with an honest summary."
        for (step in 1..25) {
            if (cancelled) { finish(c, "Stopped by the user."); return }
            val a = JarvisAccess.inst ?: run { finish(c, "Accessibility was turned off."); return }
            val snap = a.snapshot(); val shot = a.screenshotB64()
            val parts = JSONArray().put(JSONObject().put("text", "GOAL: $goal\nSTEPS SO FAR:\n" + steps.takeLast(8).joinToString("\n").ifEmpty { "none" } + "\nLAST RESULT: $last\nSCREEN ELEMENTS:\n$snap"))
            if (shot != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", shot)))
            val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decl)))
                .put("toolConfig", JSONObject().put("functionCallingConfig", JSONObject().put("mode", "ANY")))
            val act = callModel(c, body) ?: run { finish(c, "I could not reach the agent model. Check the key and the agent model in Settings."); return }
            val args = act.args
            var result: String
            when (act.name) {
                "done" -> { finish(c, args.optString("summary", "Done")); return }
                "ask_user" -> { finish(c, "NEEDS_USER: " + args.optString("question")); return }
                "tap_id" -> {
                    val id = args.optInt("id", -1); val e = a.elems.getOrNull(id)
                    val hit = e != null && risky.containsMatchIn(e.text)
                    if (hit && !allow) { finish(c, "NEEDS_CONFIRM: I am about to tap \"${e!!.text}\" for this goal: $goal. Ask the user. If they agree, call run_agent_task again with the same goal and user_confirmed true."); return }
                    if (hit) allow = false
                    result = a.tapId(id)
                }
                "tap_xy" -> {
                    val what = args.optString("what"); val hit = risky.containsMatchIn(what)
                    if (hit && !allow) { finish(c, "NEEDS_CONFIRM: I am about to tap \"$what\" for this goal: $goal. Ask the user. If they agree, call run_agent_task again with the same goal and user_confirmed true."); return }
                    if (hit) allow = false
                    result = a.tapNorm(args.optDouble("x", 500.0).toFloat(), args.optDouble("y", 500.0).toFloat())
                }
                "type_text" -> result = a.typeText(args.optString("text"))
                "scroll" -> result = if (a.scroll(args.optString("direction"))) "Scrolled." else "Could not scroll."
                "press" -> result = if (a.press(args.optString("button"))) "Pressed." else "Could not press that."
                "open_app" -> result = if (Brain.openApp(c, args.optString("name").lowercase())) "Opened." else "App not found."
                "wait" -> { Thread.sleep(args.optInt("seconds", 2).coerceIn(1, 5) * 1000L); result = "Waited." }
                else -> result = "Unknown action."
            }
            last = result; val sig = act.name + args.toString()
            steps.add("$step. ${act.name} $args -> $result")
            Tools.card(c, "Agent step $step", act.name + ": " + result)
            if (sig == prevSig) repeat++ else repeat = 0
            prevSig = sig
            if (repeat >= 2) { finish(c, "I got stuck repeating the same action. Last result: $last"); return }
            Thread.sleep(1300)
        }
        finish(c, "I ran out of steps before finishing. Last result: $last")
    }
}
