package com.sam.jarvis
import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.app.TimePickerDialog
import android.widget.*

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var list: ListView

    override fun onCreate(s: android.os.Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { root.addView(it) }
        root.addView(TextView(this).apply { text = "J.A.R.V.I.S"; textSize = 24f })
        btn("Jarvis ON (permissions + start)") { start() }
        btn("Battery: Unrestricted karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        val key = EditText(this).apply { hint = "Claude API key"; setText(Brain.prefs(this@MainActivity).getString("key", "")) }
        root.addView(key)
        btn("Key save karo") { Brain.prefs(this).edit().putString("key", key.text.toString().trim()).apply(); toast("Saved") }
        btn("Bulana: Sir / Sam badlo") {
            val n = if (Brain.title(this) == "Sir") "Sam" else "Sir"
            Brain.prefs(this).edit().putString("title", n).apply(); toast("Ab: $n")
        }
        btn("+ Reminder (roz)") { addRem() }
        list = ListView(this); root.addView(list, LinearLayout.LayoutParams(-1, 450))
        list.setOnItemClickListener { _, _, i, _ ->
            TimePickerDialog(this, { _, h, m -> Brain.editRem(this, i, h, m); refresh() }, 8, 0, true).show()
        }
        list.setOnItemLongClickListener { _, _, i, _ -> Brain.delRem(this, i); refresh(); true }
        log = TextView(this)
        root.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(-1, 0, 1f))
        val inp = EditText(this).apply { hint = "Jarvis ko likho..." }; root.addView(inp)
        btn("Bhejo") {
            val q = inp.text.toString(); inp.setText(""); log.append("\nAap: $q")
            Brain.handle(this, q) { r -> runOnUiThread { log.append("\nJarvis: $r") } }
        }
        setContentView(root); refresh()
    }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun refresh() {
        val a = Brain.rems(this)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            (0 until a.length()).map { val o = a.getJSONObject(it); "%02d:%02d  %s".format(o.getInt("h"), o.getInt("m"), o.getString("text")) })
    }
    private fun addRem() {
        val e = EditText(this).apply { hint = "Kya yaad dilana hai? (jaise: paani pio)" }
        AlertDialog.Builder(this).setView(e).setPositiveButton("Time chuno") { _, _ ->
            TimePickerDialog(this, { _, h, m -> Brain.addRem(this, h, m, e.text.toString().ifEmpty { "reminder" }, true); refresh() }, 8, 0, true).show()
        }.show()
    }
    private fun start() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(Intent(this, JarvisService::class.java)); toast("Jarvis chalu")
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else toast("Mic permission zaroori hai")
    }
}
