package com.sam.jarvis
import android.app.*
import android.content.*
import android.net.Uri
import android.provider.ContactsContract
import org.json.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

object Brain {
    fun prefs(c: Context) = c.getSharedPreferences("j", 0)
    fun title(c: Context) = prefs(c).getString("title", "Sir")!!
    fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun rems(c: Context) = JSONArray(prefs(c).getString("rem", "[]"))
    fun saveRems(c: Context, a: JSONArray) = prefs(c).edit().putString("rem", a.toString()).apply()
    fun addRem(c: Context, h: Int, m: Int, text: String, daily: Boolean) {
        val id = (System.currentTimeMillis() % 100000000).toInt()
        val a = rems(c); a.put(JSONObject().put("id", id).put("h", h).put("m", m).put("text", text).put("daily", daily))
        saveRems(c, a); schedule(c, id, h, m, text, daily)
    }
    fun editRem(c: Context, i: Int, h: Int, m: Int) {
        val a = rems(c); val o = a.getJSONObject(i); o.put("h", h).put("m", m); saveRems(c, a)
        schedule(c, o.getInt("id"), h, m, o.getString("text"), o.getBoolean("daily"))
    }
    fun delRem(c: Context, i: Int) {
        val a = rems(c); val b = JSONArray()
        for (k in 0 until a.length()) if (k != i) b.put(a.get(k)) else cancel(c, a.getJSONObject(k).getInt("id"))
        saveRems(c, b)
    }
    private fun pi(c: Context, id: Int, i: Intent) = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context, id: Int) = (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id, Intent(c, ReminderReceiver::class.java)))
    fun schedule(c: Context, id: Int, h: Int, m: Int, text: String, daily: Boolean) {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text).putExtra("h", h).putExtra("m", m).putExtra("daily", daily)
        val p = pi(c, id, i)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, p), p)
    }

    fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        c.startActivity(pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }

    fun handle(c: Context, raw: String, say: (String) -> Unit) {
        val q = raw.lowercase().trim(); val t = title(c); val p = prefs(c)
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(q)
        when {
            q.contains("yaad rakho") -> { p.edit().putString("notes", p.getString("notes", "") + "; " + q.substringAfter("yaad rakho").trim()).apply(); say("Yaad rakh liya $t") }
            (q.contains("paani") || q.contains("water")) && q.contains("pi") -> {
                val n = if (p.getString("wd", "") == today()) p.getInt("w", 0) + 1 else 1
                p.edit().putString("wd", today()).putInt("w", n).apply(); say("Shabash $t, aaj $n glass ho gaye")
            }
            q.contains("reminder") || q.contains("alarm") || (q.contains("yaad") && m != null) -> {
                if (m == null) { say("Time bataiye $t"); return }
                var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (Regex("pm|shaam|raat|dopahar").containsMatchIn(q) && h < 12) h += 12
                val txt = q.replace(Regex("\\b(reminder|alarm|yaad|dilao|dilana|laga|do|lagao|baje|am|pm|roz|daily|subah|shaam|raat|dopahar|ka|ki|ke|ko|mujhe|set|kar|karo)\\b|\\d{1,2}(:\\d{2})?"), " ").replace(Regex("\\s+"), " ").trim().ifEmpty { "alarm" }
                addRem(c, h, mi, txt, q.contains("roz") || q.contains("daily") || q.contains("har din"))
                say("Theek hai $t, $h:%02d par $txt yaad dilaunga".format(mi))
            }
            Regex("\\b(kholo|khol|open)\\b").containsMatchIn(q) -> {
                val n = q.replace(Regex("\\b(kholo|khol|open|do|na|please)\\b"), "").trim()
                say(if (openApp(c, n)) "$n khol raha hoon" else "$n app nahi mila $t")
            }
            q.contains("call") -> {
                val who = q.replace(Regex("\\b(call|karo|lagao|laga|ko|do|please)\\b"), "").trim()
                var num: String? = if (who.matches(Regex("[\\d +]+"))) who.replace(" ", "") else null
                if (num == null) c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                if (num == null) say("Contact nahi mila $t") else { c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("$who ko call laga raha hoon") }
            }
            q.startsWith("kaam kiya") || q.startsWith("kaam nahi") -> {
                val a = JSONArray(p.getString("log", "[]")); a.put(JSONObject().put("t", System.currentTimeMillis()).put("ok", !q.startsWith("kaam nahi")).put("x", q))
                p.edit().putString("log", a.toString()).apply(); say("Note kar liya $t")
            }
            q.contains("report") -> {
                val a = JSONArray(p.getString("log", "[]")); var ok = 0; var no = 0; val wk = System.currentTimeMillis() - 7 * 86400000L
                for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (o.getLong("t") > wk) { if (o.getBoolean("ok")) ok++ else no++ } }
                say("$t, is hafte $ok kaam hue aur $no nahi hue. Aaj paani ${if (p.getString("wd", "") == today()) p.getInt("w", 0) else 0} glass.")
            }
            q.contains("time") && q.length < 25 -> say("Abhi " + SimpleDateFormat("h:mm a", Locale.US).format(Date()) + " ho rahe hain $t")
            else -> ask(c, q, say)
        }
    }

    fun ask(c: Context, q: String, say: (String) -> Unit) {
        val key = prefs(c).getString("key", "")!!
        if (key.isEmpty()) { say("Settings mein API key daaliye ${title(c)}"); return }
        thread {
            try {
                val sys = "You are JARVIS, Tony Stark's butler AI, now assisting a user from Pakistan/India. Address them as '${title(c)}'. Reply in short Hinglish (Roman script), max 2 sentences, witty and warm. Known notes about user: ${prefs(c).getString("notes", "")}"
                val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", 200).put("system", sys)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
                val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01"); con.setRequestProperty("content-type", "application/json")
                con.outputStream.write(body.toString().toByteArray())
                val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                say(JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text"))
            } catch (e: Exception) { say("Net ya API key mein masla hai ${title(c)}") }
        }
    }
}
