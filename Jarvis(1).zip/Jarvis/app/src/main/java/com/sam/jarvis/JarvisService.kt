package com.sam.jarvis
import android.app.*
import android.content.Intent
import android.os.*
import android.speech.*
import android.speech.tts.*
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private var awake = false
    @Volatile private var speaking = false
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "j").setContentTitle("Jarvis sun raha hai").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
    }
    override fun onInit(s: Int) {
        tts.language = Locale("en", "IN")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { speaking = false; listen() }
            override fun onDone(id: String?) { speaking = false; listen() }
        })
        say("Jarvis online hai ${Brain.title(this)}")
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "speak") say(i.getStringExtra("text") ?: "")
        return START_STICKY
    }
    fun say(t: String) {
        speaking = true; h.post { sr?.cancel() }
        tts.speak(t, TextToSpeech.QUEUE_ADD, null, "j")
    }
    private fun listen() {
        h.post {
            if (speaking) return@post
            sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    onHeard(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                    if (!speaking) h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"))
        }
    }
    private fun onHeard(t: String) {
        val l = t.lowercase()
        if (!awake && !l.contains("jarvis") && !l.contains("service")) return
        val cmd = l.replace(Regex("\\b(hey|hi|jarvis|service)\\b"), "").trim()
        if (cmd.isEmpty()) { awake = true; say("Ji ${Brain.title(this)}?") }
        else { awake = false; Brain.handle(this, cmd) { say(it) } }
    }
    override fun onDestroy() { sr?.destroy(); tts.shutdown() }
}
