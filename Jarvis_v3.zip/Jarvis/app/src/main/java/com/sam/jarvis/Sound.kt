package com.sam.jarvis
import android.media.*
object Sound {
    @Volatile var on = true
    fun play(kind: String) {
        if (!on) return
        val seq = when (kind) {
            "start" -> listOf(220 to 130, 330 to 130, 440 to 130, 660 to 300)
            "wake" -> listOf(880 to 90, 1320 to 120)
            "done" -> listOf(660 to 80, 990 to 140)
            "error" -> listOf(300 to 160, 200 to 240)
            "click" -> listOf(1200 to 30)
            "chime" -> listOf(784 to 150, 988 to 150, 1175 to 300)
            else -> return
        }
        Thread { try { for ((f, ms) in seq) tone(f, ms) } catch (e: Exception) {} }.start()
    }
    private fun tone(f: Int, ms: Int) {
        val sr = 22050; val n = sr * ms / 1000
        val b = ShortArray(n) { i -> val env = minOf(1f, minOf(i, n - i) / (sr * 0.01f)); (Math.sin(2 * Math.PI * f * i / sr) * 8000 * env).toInt().toShort() }
        val t = AudioTrack(AudioManager.STREAM_MUSIC, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC)
        t.write(b, 0, n); t.play(); Thread.sleep(ms + 20L); t.release()
    }
}
