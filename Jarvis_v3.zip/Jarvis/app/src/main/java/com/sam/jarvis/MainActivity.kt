package com.sam.jarvis
import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val cy = Color.rgb(0, 220, 255)
    private val h = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private lateinit var navBtns: List<TextView>
    private var page = 0
    private var statusV: TextView? = null
    private var replyV: TextView? = null
    private var typed = 0
    private var typedFor = ""

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun box(a: Int = 40) = GradientDrawable().apply { setColor(Color.argb(a, 0, 220, 255)); setStroke(dp(1), cy); cornerRadius = dp(12).toFloat() }
    private fun lbl(t: String, size: Float = 12f, color: Int = cy) = TextView(this).apply { text = t; textSize = size; setTextColor(color); typeface = Typeface.MONOSPACE; letterSpacing = 0.1f; setPadding(0, dp(10), 0, dp(4)) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setTextColor(cy); background = box(); isAllCaps = false; setOnClickListener { Sound.play("click"); f() } }
    private fun field(hintText: String) = EditText(this).apply { hint = hintText; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); background = box(20); setPadding(dp(12), dp(8), dp(12), dp(8)); textSize = 14f }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun pf() = Brain.prefs(this)
    private fun speak(r: String) { JarvisService.inst?.say(r) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
        Sound.on = pf().getBoolean("snd", true)
        val root = FrameLayout(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(3, 22, 34), Color.rgb(0, 6, 10))) }
        val main = col().apply { setPadding(dp(14), dp(34), dp(14), dp(8)) }
        content = FrameLayout(this)
        main.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { background = box(25); setPadding(dp(4), dp(2), dp(4), dp(2)) }
        navBtns = listOf("HOME", "ACTIVITY", "ROUTINE", "SETTINGS").mapIndexed { i, t ->
            TextView(this).apply { text = t; textSize = 11f; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)); typeface = Typeface.MONOSPACE; setOnClickListener { Sound.play("click"); show(i) } }.also { nav.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        }
        main.addView(nav, LinearLayout.LayoutParams(-1, -2))

        val boot = FrameLayout(this).apply { setBackgroundColor(Color.rgb(2, 12, 18)); isClickable = true }
        boot.addView(CoreView(this, true), FrameLayout.LayoutParams(-1, -1))
        val bs = TextView(this).apply { text = "INITIALIZING..."; textSize = 14f; setTextColor(cy); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; letterSpacing = 0.25f }
        val bc = col().apply {
            gravity = Gravity.CENTER
            addView(TextView(this@MainActivity).apply { text = "J.A.R.V.I.S."; textSize = 28f; setTextColor(Color.WHITE); typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); gravity = Gravity.CENTER; letterSpacing = 0.2f })
            addView(bs)
        }
        boot.addView(bc, FrameLayout.LayoutParams(-1, -1))
        root.addView(main); root.addView(boot)
        setContentView(root); show(0)
        Sound.play("start")
        h.postDelayed({ bs.text = "SYSTEMS ONLINE" }, 2200)
        h.postDelayed({ boot.animate().alpha(0f).setDuration(700).withEndAction { boot.visibility = View.GONE }.start() }, 3400)
        h.post(object : Runnable {
            override fun run() {
                statusV?.text = when (Brain.state) { "listening" -> "LISTENING..."; "thinking" -> "PROCESSING..."; "speaking" -> "SPEAKING"; else -> if (Brain.waiting()) "WAITING FOR YOUR YES / NO" else "STANDBY - SAY \"HEY JARVIS\"" }
                replyV?.let { r ->
                    val t = Brain.lastReply
                    if (t != typedFor) { typedFor = t; typed = 0 }
                    if (typed < t.length) { typed = minOf(t.length, typed + 2); r.text = t.substring(0, typed) }
                }
                h.postDelayed(this, 60)
            }
        })
    }

    private fun show(i: Int) {
        page = i; statusV = null; replyV = null
        navBtns.forEachIndexed { k, v -> v.setTextColor(if (k == i) Color.WHITE else Color.argb(150, 0, 220, 255)); v.background = if (k == i) box(60) else null }
        content.removeAllViews()
        content.addView(when (i) { 0 -> home(); 1 -> activity(); 2 -> routine(); else -> settings() }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun home(): View = col().apply {
        statusV = TextView(this@MainActivity).apply { textSize = 12f; setTextColor(Color.argb(200, 0, 220, 255)); typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; letterSpacing = 0.12f }
        addView(statusV)
        addView(CoreView(this@MainActivity), LinearLayout.LayoutParams(-1, 0, 1f))
        replyV = TextView(this@MainActivity).apply { textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; minHeight = dp(80); setPadding(dp(8), dp(4), dp(8), dp(4)) }
        addView(replyV)
        val mic = TextView(this@MainActivity).apply {
            text = "MIC"; textSize = 14f; setTextColor(cy); gravity = Gravity.CENTER; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(60, 0, 220, 255)); setStroke(dp(2), cy) }
            setOnClickListener {
                Sound.play("click")
                val sv = JarvisService.inst
                if (sv == null) toast("Pehle Settings mein ACTIVATE karo") else if (Brain.state == "speaking") sv.stopSpeak() else sv.wakeNow()
            }
        }
        addView(mic, LinearLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        addView(TextView(this@MainActivity).apply { text = "Tap to speak"; textSize = 11f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(8)) })
    }

    private fun activity(): View = col().apply {
        addView(lbl("CHAT"))
        val chatT = TextView(this@MainActivity).apply { setTextColor(Color.rgb(170, 240, 255)); textSize = 13f; text = Brain.chat.takeLast(14).joinToString("\n\n") { "${it.first}: ${it.second}" } }
        val sv = ScrollView(this@MainActivity).apply { addView(chatT); post { fullScroll(View.FOCUS_DOWN) } }
        addView(sv, LinearLayout.LayoutParams(-1, 0, 2f))
        val inp = field("Jarvis ko likho...")
        val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(inp, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("SEND") {
            val q = inp.text.toString().trim(); if (q.isEmpty()) return@btn
            inp.setText("")
            Brain.handle(this@MainActivity, q) { r -> speak(r); runOnUiThread { if (page == 1) show(1) } }
            show(1)
        })
        addView(row)
        addView(lbl("ACTION HISTORY"))
        val hl = Brain.histList(this@MainActivity, false).takeLast(8).reversed().joinToString("\n").ifEmpty { "Abhi kuch nahi" }
        addView(ScrollView(this@MainActivity).apply { addView(TextView(this@MainActivity).apply { text = hl; setTextColor(Color.GRAY); textSize = 12f; typeface = Typeface.MONOSPACE }) }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun routine(): View = col().apply {
        val (ok, no) = Brain.week(this@MainActivity)
        addView(lbl("TODAY"))
        val w = TextView(this@MainActivity).apply { text = "Paani: ${Brain.water(this@MainActivity)} glass"; textSize = 22f; setTextColor(Color.WHITE) }
        addView(w)
        addView(btn("+ 1 glass") { pf().edit().putString("wd", Brain.today()).putInt("w", Brain.water(this@MainActivity) + 1).apply(); Brain.hist(this@MainActivity, "Water glass"); show(2) })
        addView(lbl("THIS WEEK"))
        addView(TextView(this@MainActivity).apply { text = "Kaam hue: $ok    Nahi hue: $no"; textSize = 16f; setTextColor(Color.WHITE) })
        addView(lbl("REMINDERS  (tap = time badlo, long-press = delete)"))
        val list = ListView(this@MainActivity)
        val a = Brain.rems(this@MainActivity)
        list.adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_list_item_1, (0 until a.length()).map { val o = a.getJSONObject(it); "%02d:%02d  %s".format(o.getInt("h"), o.getInt("m"), o.getString("text")) }) {
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View = (super.getView(p, v, g) as TextView).apply { setTextColor(Color.WHITE) }
        }
        list.setOnItemClickListener { _, _, i, _ -> TimePickerDialog(this@MainActivity, { _, hh, mm -> Brain.editRem(this@MainActivity, i, hh, mm); show(2) }, 8, 0, true).show() }
        list.setOnItemLongClickListener { _, _, i, _ -> Brain.delRem(this@MainActivity, i); show(2); true }
        addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        addView(btn("+ Reminder (roz)") {
            val e = EditText(this@MainActivity).apply { hint = "Kya yaad dilana hai?" }
            AlertDialog.Builder(this@MainActivity).setView(e).setPositiveButton("Time chuno") { _, _ ->
                TimePickerDialog(this@MainActivity, { _, hh, mm -> Brain.addRem(this@MainActivity, hh, mm, e.text.toString().ifEmpty { "reminder" }, true); show(2) }, 8, 0, true).show()
            }.show()
        })
    }

    private fun seek(parent: LinearLayout, label: String, key: String, def: Float) {
        parent.addView(lbl(label, 11f))
        val s = SeekBar(this).apply { max = 100; progress = (pf().getFloat(key, def) * 100 - 50).toInt() }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(b: SeekBar?, v: Int, u: Boolean) { pf().edit().putFloat(key, (v + 50) / 100f).apply(); JarvisService.inst?.applyVoice() }
            override fun onStartTrackingTouch(b: SeekBar?) {}
            override fun onStopTrackingTouch(b: SeekBar?) {}
        })
        parent.addView(s)
    }
    private fun rowOf(items: List<Pair<String, () -> Unit>>) = LinearLayout(this).apply { items.forEach { (t, f) -> addView(btn(t, f).apply { textSize = 10f; setPadding(0, 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f)) } }

    private fun settings(): View = ScrollView(this).apply {
        val c = col(); addView(c)
        c.addView(btn("ACTIVATE JARVIS (permissions)") { start() })
        c.addView(btn("Battery: Unrestricted karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        c.addView(lbl("AI BRAIN"))
        val key = field("Claude API key"); key.setText(pf().getString("key", "")); c.addView(key)
        c.addView(btn("Key save karo") { pf().edit().putString("key", key.text.toString().trim()).apply(); toast("Saved") })
        c.addView(lbl("MODE"))
        c.addView(rowOf(listOf("work", "normal", "friend", "creator", "silent").map { m -> m to { pf().edit().putString("mode", m).apply(); toast("Mode: $m") } }))
        c.addView(lbl("LANGUAGE"))
        c.addView(rowOf(listOf("english" to "English", "roman" to "Roman Urdu", "hindi" to "Hindi", "mix" to "Mix").map { (k, n) -> n to { pf().edit().putString("lang", k).apply(); toast("Language: $n") } }))
        c.addView(lbl("BULANA"))
        c.addView(btn("Sir / Bhai / Sam badlo") { val n = when (pf().getString("title", "Bhai")) { "Sir" -> "Bhai"; "Bhai" -> "Sam"; else -> "Sir" }; pf().edit().putString("title", n).apply(); toast("Ab: $n") })
        c.addView(lbl("VOICE"))
        c.addView(btn("Phone ki awaaz chuno") {
            val vs = JarvisService.inst?.voiceList() ?: emptyList()
            if (vs.isEmpty()) toast("Pehle ACTIVATE karo") else AlertDialog.Builder(this@MainActivity).setItems(vs.map { "${it.locale.displayName} - ${it.name}" }.toTypedArray()) { _, i ->
                pf().edit().putString("voice", vs[i].name).apply(); JarvisService.inst?.applyVoice(); speak("Ye meri nayi awaaz hai")
            }.show()
        })
        seek(c, "Pitch (kam = gehri awaaz)", "pitch", 0.85f)
        seek(c, "Speed", "rate", 0.95f)
        c.addView(btn("Awaaz test karo") { speak("Systems online. How can I help you?") })
        c.addView(lbl("ELEVENLABS VOICE (optional, behtar awaaz)"))
        val ek = field("ElevenLabs API key"); ek.setText(pf().getString("elkey", "")); c.addView(ek)
        val ev = field("Voice ID (apni ya neeche se chuno)"); ev.setText(pf().getString("elvoice", "")); c.addView(ev)
        c.addView(rowOf(listOf("Daniel" to "onwK4e9ZLuTAKqWW03F9", "George" to "JBFqnCBsd6RMkjVDRZzb", "Adam" to "pNInz6obpgDQGcFmaJgB", "Charlie" to "IKne3meq5aSn9XLyUdCD").map { (n, id) -> n to { ev.setText(id) } }))
        c.addView(btn("ElevenLabs save karo") { pf().edit().putString("elkey", ek.text.toString().trim()).putString("elvoice", ev.text.toString().trim()).apply(); speak("Voice save ho gayi") })
        c.addView(btn("ElevenLabs band karo (phone ki awaaz)") { pf().edit().remove("elkey").remove("elvoice").apply(); ek.setText(""); ev.setText("") })
        c.addView(lbl("SOUND"))
        c.addView(btn("Sound ON / OFF") { Sound.on = !Sound.on; pf().edit().putBoolean("snd", Sound.on).apply(); toast("Sound: " + if (Sound.on) "ON" else "OFF") })
        c.addView(lbl("MEMORY  (long-press = delete)"))
        val ml = ListView(this@MainActivity); val mem = Brain.mem(this@MainActivity)
        ml.adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_list_item_1, (0 until mem.length()).map { mem.getString(it) }) {
            override fun getView(p: Int, v: View?, g: android.view.ViewGroup): View = (super.getView(p, v, g) as TextView).apply { setTextColor(Color.WHITE); textSize = 13f }
        }
        ml.setOnItemLongClickListener { _, _, i, _ -> Brain.delMem(this@MainActivity, i); show(3); true }
        c.addView(ml, LinearLayout.LayoutParams(-1, dp(160)))
    }

    private fun start() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) {
        if (g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(Intent(this, JarvisService::class.java)); toast("Jarvis chalu")
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else toast("Mic permission zaroori hai")
    }
}
