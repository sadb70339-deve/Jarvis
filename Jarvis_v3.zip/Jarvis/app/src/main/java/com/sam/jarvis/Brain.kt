package com.sam.jarvis
import android.app.*
import android.content.*
import android.net.Uri
import android.provider.ContactsContract
import org.json.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

object Brain {
    @Volatile var state = "idle"
    @Volatile var lastReply = ""
    @Volatile var pending: (() -> Unit)? = null
    @Volatile var pendingAt = 0L
    val chat = CopyOnWriteArrayList<Pair<String, String>>()

    fun prefs(c: Context) = c.getSharedPreferences("j", 0)
    fun mode(c: Context) = prefs(c).getString("mode", "normal")!!
    fun title(c: Context) = if (mode(c) == "work") "Sir" else prefs(c).getString("title", "Bhai")!!
    fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun mem(c: Context) = JSONArray(prefs(c).getString("mem", "[]"))
    fun addMem(c: Context, s: String) { val a = mem(c); a.put(s); prefs(c).edit().putString("mem", a.toString()).apply() }
    fun delMem(c: Context, i: Int) { val a = mem(c); val b = JSONArray(); for (k in 0 until a.length()) if (k != i) b.put(a.get(k)); prefs(c).edit().putString("mem", b.toString()).apply() }
    fun hist(c: Context, s: String) {
        val a = JSONArray(prefs(c).getString("hist", "[]")); a.put(JSONObject().put("t", System.currentTimeMillis()).put("x", s))
        val b = JSONArray(); for (k in maxOf(0, a.length() - 80) until a.length()) b.put(a.get(k))
        prefs(c).edit().putString("hist", b.toString()).apply()
    }
    fun histList(c: Context, onlyToday: Boolean): List<String> {
        val a = JSONArray(prefs(c).getString("hist", "[]")); val cal = Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        val out = ArrayList<String>(); val f = SimpleDateFormat("dd/MM HH:mm", Locale.US)
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (!onlyToday || o.getLong("t") >= cal.timeInMillis) out.add(f.format(Date(o.getLong("t"))) + "  " + o.getString("x")) }
        return out
    }

    fun rems(c: Context) = JSONArray(prefs(c).getString("rem", "[]"))
    fun saveRems(c: Context, a: JSONArray) = prefs(c).edit().putString("rem", a.toString()).apply()
    fun addRem(c: Context, h: Int, m: Int, text: String, daily: Boolean) {
        val id = (System.currentTimeMillis() % 100000000).toInt()
        val a = rems(c); a.put(JSONObject().put("id", id).put("h", h).put("m", m).put("text", text).put("daily", daily))
        saveRems(c, a); schedule(c, id, h, m, text, daily)
    }
    fun editRem(c: Context, i: Int, h: Int, m: Int) {
        val a = rems(c); val o = a.getJSONObject(i); o.put("h", h).put("m", m); saveRems(c, a)
        schedule(c, o.getInt("id"), h, m, o.getString("text"), o.getBoolean("daily"))
    }
    fun delRem(c: Context, i: Int) {
        val a = rems(c); val b = JSONArray()
        for (k in 0 until a.length()) if (k != i) b.put(a.get(k)) else cancel(c, a.getJSONObject(k).getInt("id"))
        saveRems(c, b)
    }
    private fun pi(c: Context, id: Int, i: Intent) = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context, id: Int) = (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id, Intent(c, ReminderReceiver::class.java)))
    fun schedule(c: Context, id: Int, h: Int, m: Int, text: String, daily: Boolean) {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text).putExtra("h", h).putExtra("m", m).putExtra("daily", daily)
        val p = pi(c, id, i)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, p), p)
    }

    fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        c.startActivity(pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
    private fun web(c: Context, url: String) = c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun confirm(q: String, say: (String) -> Unit, act: () -> Unit) { pending = act; pendingAt = System.currentTimeMillis(); say(q) }
    fun waiting() = pending != null && System.currentTimeMillis() - pendingAt < 60000

    fun handle(c: Context, raw: String, say0: (String) -> Unit) {
        val q = raw.lowercase().trim(); val p = prefs(c)
        chat.add("YOU" to raw); if (chat.size > 60) chat.removeAt(0)
        val say: (String) -> Unit = { lastReply = it; chat.add("JARVIS" to it); say0(it) }
        val t = title(c)
        val act = pending
        if (act != null) {
            pending = null
            if (System.currentTimeMillis() - pendingAt < 60000 && q.length < 25) {
                if (Regex("\\b(nahi|nahin|no|mat|cancel|rehne do)\\b").containsMatchIn(q)) { say("Theek hai $t, nahi kar raha"); return }
                if (Regex("\\b(haan|han|ha|yes|yeah|ok|okay|kar do|kardo|sure|theek hai|bilkul)\\b").containsMatchIn(q)) { act(); Sound.play("done"); return }
            }
        }
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(q)
        val modes = Regex("work|normal|friend|creator|silent|sleep|dnd")
        when {
            q.contains("yaad rakho") || q.contains("yaad rakhna") -> { val f = q.substringAfter("yaad rakh").substringAfter(" ").trim(); addMem(c, f); hist(c, "Memory saved: $f"); say("Yaad rakh liya $t") }
            q.contains("bhool jao") || q.contains("bhul jao") -> {
                val k = q.substringAfter("jao").trim(); val a = mem(c); var n = 0; val b = JSONArray()
                for (i in 0 until a.length()) { if (k.isNotEmpty() && a.getString(i).lowercase().contains(k)) n++ else b.put(a.get(i)) }
                p.edit().putString("mem", b.toString()).apply(); say(if (n > 0) "Bhula diya $t" else "Aisi koi memory nahi mili")
            }
            q.contains("mode") && modes.containsMatchIn(q) -> {
                val x = modes.find(q)!!.value; val mm = if (x == "dnd" || x == "sleep") "silent" else x
                p.edit().putString("mode", mm).apply(); hist(c, "Mode: $mm"); say("Theek hai ${title(c)}, ab $mm mode hai")
            }
            q.contains("only english") || q.contains("speak english") || q.contains("english mein") -> { p.edit().putString("lang", "english").apply(); say("Understood. I'll speak only English.") }
            q.contains("roman urdu") -> { p.edit().putString("lang", "roman").apply(); say("Theek hai $t, ab Roman Urdu mein baat karte hain") }
            q.contains("hindi") && Regex("baat|bolo|mein").containsMatchIn(q) -> { p.edit().putString("lang", "hindi").apply(); say("Theek hai $t, ab Hindi mein baat karenge") }
            q.contains("kya kya karwaya") || q.contains("history") -> { val l = histList(c, true); say(if (l.isEmpty()) "Aaj abhi tak kuch nahi hua $t" else "Aaj ${l.size} kaam hue. Aakhri: " + l.takeLast(3).joinToString(". ") { it.substring(12) }) }
            (q.contains("paani") || q.contains("water")) && q.contains("pi") -> {
                val n = if (p.getString("wd", "") == today()) p.getInt("w", 0) + 1 else 1
                p.edit().putString("wd", today()).putInt("w", n).apply(); hist(c, "Water glass #$n"); say("Shabash $t, aaj $n glass ho gaye")
            }
            q.contains("reminder") || q.contains("alarm") || (q.contains("yaad") && m != null) -> {
                if (m == null) { say("Time bataiye $t"); return }
                var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (Regex("pm|shaam|raat|dopahar").containsMatchIn(q) && h < 12) h += 12
                val txt = q.replace(Regex("\\b(reminder|alarm|yaad|dilao|dilana|laga|do|lagao|baje|am|pm|roz|daily|subah|shaam|raat|dopahar|ka|ki|ke|ko|mujhe|set|kar|karo)\\b|\\d{1,2}(:\\d{2})?"), " ").replace(Regex("\\s+"), " ").trim().ifEmpty { "alarm" }
                addRem(c, h, mi, txt, q.contains("roz") || q.contains("daily") || q.contains("har din"))
                hist(c, "Reminder: $txt at $h:%02d".format(mi)); say("Theek hai $t, $h:%02d par $txt yaad dilaunga".format(mi))
            }
            q.contains("youtube") && Regex("search|chalao|play|dhundo|lagao").containsMatchIn(q) -> {
                val k = q.replace(Regex("\\b(youtube|pe|par|on|search|chalao|play|dhundo|lagao|karo|video|ka|ki|ke|ko|mujhe)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                confirm("$t, YouTube par $k search kar doon?", say) { web(c, "https://www.youtube.com/results?search_query=" + URLEncoder.encode(k, "UTF-8")); hist(c, "YouTube search: $k"); say("YouTube khol diya, $k ke results hain") }
            }
            q.contains("search") || q.contains("dhundo") -> {
                val k = q.replace(Regex("\\b(search|dhundo|google|pe|par|karo|for)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                confirm("$t, Google par $k search kar doon?", say) { web(c, "https://www.google.com/search?q=" + URLEncoder.encode(k, "UTF-8")); hist(c, "Google search: $k"); say("Search khol diya") }
            }
            Regex("\\b(kholo|khol|open)\\b").containsMatchIn(q) -> {
                val n = q.replace(Regex("\\b(kholo|khol|open|do|na|please)\\b"), "").trim()
                confirm("$t, $n khol doon?", say) { val ok = openApp(c, n); hist(c, if (ok) "Opened $n" else "Failed to open $n"); if (!ok) Sound.play("error"); say(if (ok) "$n khol diya" else "$n app nahi mila") }
            }
            q.contains("call") -> {
                val who = q.replace(Regex("\\b(call|karo|lagao|laga|ko|do|please)\\b"), "").trim()
                var num: String? = if (who.matches(Regex("[\\d +]+"))) who.replace(" ", "") else null
                if (num == null) c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
                val nn = num
                if (nn == null) { Sound.play("error"); say("Contact nahi mila $t") }
                else confirm("$t, $who ko call laga doon?", say) { c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$nn")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); hist(c, "Call: $who"); say("Call laga raha hoon") }
            }
            q.startsWith("kaam kiya") || q.startsWith("kaam nahi") -> {
                val a = JSONArray(p.getString("log", "[]")); a.put(JSONObject().put("t", System.currentTimeMillis()).put("ok", !q.startsWith("kaam nahi")).put("x", q))
                p.edit().putString("log", a.toString()).apply(); hist(c, q); say("Note kar liya $t")
            }
            q.contains("report") -> { val (ok, no) = week(c); say("$t, is hafte $ok kaam hue aur $no nahi hue. Aaj paani ${water(c)} glass.") }
            q.contains("time") && q.length < 25 -> say("Abhi " + SimpleDateFormat("h:mm a", Locale.US).format(Date()) + " ho rahe hain $t")
            q.contains("instagram") && Regex("ready|caption|post|hashtag|draft").containsMatchIn(q) -> {
                ask(c, raw, say, 500, "Prepare an Instagram post for this request: $raw. Give: 1) Caption (English motivational quote + Roman Urdu meaning) 2) Cover text (max 6 words) 3) 8 hashtags. Compact.") { r ->
                    chat.add("JARVIS" to r)
                    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", r))
                    hist(c, "Instagram draft prepared"); lastReply = "Draft ready"
                    pending = { val ok = openApp(c, "instagram"); hist(c, if (ok) "Opened Instagram" else "Instagram open failed"); say(if (ok) "Instagram khol diya, caption paste kar do" else "Instagram nahi mila") }
                    pendingAt = System.currentTimeMillis()
                    say0("$t, caption, cover aur hashtags ready hain. Activity page par dekho, copy bhi ho gaya. Instagram khol doon?")
                }
            }
            else -> ask(c, raw, say)
        }
    }
    fun week(c: Context): Pair<Int, Int> {
        val a = JSONArray(prefs(c).getString("log", "[]")); var ok = 0; var no = 0; val wk = System.currentTimeMillis() - 7 * 86400000L
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (o.getLong("t") > wk) { if (o.getBoolean("ok")) ok++ else no++ } }
        return ok to no
    }
    fun water(c: Context) = if (prefs(c).getString("wd", "") == today()) prefs(c).getInt("w", 0) else 0

    fun ask(c: Context, q: String, say: (String) -> Unit, max: Int = 200, prompt: String = q, onText: ((String) -> Unit)? = null) {
        val p = prefs(c); val key = p.getString("key", "")!!
        if (key.isEmpty()) { say("Settings mein API key daaliye ${title(c)}"); return }
        state = "thinking"
        thread {
            try {
                val msgs = JSONArray(); var last = ""
                for ((who, txt) in chat.takeLast(7)) {
                    val role = if (who == "YOU") "user" else "assistant"
                    if (role == last) { val o = msgs.getJSONObject(msgs.length() - 1); o.put("content", o.getString("content") + "\n" + txt) }
                    else if (msgs.length() > 0 || role == "user") { msgs.put(JSONObject().put("role", role).put("content", txt)); last = role }
                }
                if (msgs.length() == 0 || last != "user") msgs.put(JSONObject().put("role", "user").put("content", q))
                msgs.getJSONObject(msgs.length() - 1).put("content", prompt)
                val tone = when (mode(c)) {
                    "work" -> "Work mode: serious, concise, professional. Address the user as Sir or Boss. No jokes, no personal check-ins."
                    "creator" -> "Creator mode: focused, practical, creative. Help with video ideas, hooks, scripts, English motivational quotes with Roman Urdu meaning, captions, cover text, hashtags."
                    "friend" -> "Friend mode: casual and playful, light humour when suitable. Call the user ${title(c)}."
                    else -> "Normal mode: friendly and relaxed. Call the user ${title(c)}."
                }
                val lang = when (p.getString("lang", "mix")) {
                    "english" -> "Reply only in English."
                    "roman" -> "Reply in Roman Urdu (Urdu written in English letters)."
                    "hindi" -> "Reply in Hinglish (Hindi in English letters)."
                    else -> "Reply in a natural mix of English and Roman Urdu."
                }
                val sys = "You are JARVIS, a calm, confident, mature male AI assistant inspired by Iron Man's JARVIS, living on the user's Android phone. $tone $lang Keep replies short (max 2 sentences) unless asked for detail. If the user seems sad, stressed or upset: be soft and patient, listen first, ask what happened, no jokes, no lectures, no generic motivation, and never encourage dependence on you. Never claim you did an action you did not do. Saved memories about the user: ${mem(c)}. If the user's message reveals something important and lasting (goal, routine, preference, important person or project), end your reply with [[SAVE: short fact]] and nothing after it."
                val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", max).put("system", sys).put("messages", msgs)
                val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01"); con.setRequestProperty("content-type", "application/json")
                con.outputStream.write(body.toString().toByteArray())
                val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                val txt = JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
                val fact = Regex("\\[\\[SAVE:(.*?)\\]\\]").find(txt)?.groupValues?.get(1)?.trim() ?: ""
                val clean = txt.replace(Regex("\\[\\[SAVE:.*?\\]\\]"), "").trim()
                state = "idle"
                if (onText != null) onText(clean)
                else if (fact.isNotEmpty()) {
                    pending = { addMem(c, fact); hist(c, "Memory saved: $fact"); say("Memory mein save kar liya") }; pendingAt = System.currentTimeMillis()
                    say("$clean Aur ${title(c)}, ye important lag raha hai: $fact. Memory mein save kar loon?")
                } else say(clean)
            } catch (e: Exception) { state = "idle"; Sound.play("error"); say("Net ya API key mein masla hai ${title(c)}") }
        }
    }
}
