package com.sam.jarvis
import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.*
import android.speech.*
import android.speech.tts.*
import org.json.JSONObject
import java.io.File
import java.net.*
import java.util.Locale
import kotlin.concurrent.thread

class JarvisService : Service(), TextToSpeech.OnInitListener {
    lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private var mp: MediaPlayer? = null
    private var awake = false
    @Volatile private var speaking = false
    private var lastTalk = System.currentTimeMillis()
    private var ignored = 0
    private val h = Handler(Looper.getMainLooper())
    companion object { var inst: JarvisService? = null }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        inst = this
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "j").setContentTitle("Jarvis sun raha hai").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        h.postDelayed(checkin, 60000)
    }
    private val checkin = object : Runnable {
        override fun run() {
            val mode = Brain.mode(this@JarvisService)
            val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            val inCall = (getSystemService(AUDIO_SERVICE) as AudioManager).mode != AudioManager.MODE_NORMAL
            val idle = System.currentTimeMillis() - lastTalk
            if (idle >= 15 * 60000L && !speaking && !inCall && ignored < 2 && hr in 7..22 && (mode == "normal" || mode == "friend" || mode == "creator")) {
                val t = Brain.title(this@JarvisService)
                say(listOf("$t, sab theek? Kaafi der se baat nahi hui.", "Aaj din kaisa raha, $t?", "Kuch dimagh mein chal raha hai, $t?").random())
                ignored++
            }
            h.postDelayed(this, 60000)
        }
    }
    override fun onInit(s: Int) {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { done() }
            override fun onDone(id: String?) { done() }
        })
        applyVoice()
        Sound.on = Brain.prefs(this).getBoolean("snd", true)
        val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        say((if (hr < 12) "Good morning" else if (hr < 17) "Good afternoon" else "Good evening") + ", ${Brain.title(this)}. Systems online, I'm ready.")
    }
    fun applyVoice() {
        try {
            val p = Brain.prefs(this)
            tts.setLanguage(Locale("en", "IN"))
            val n = p.getString("voice", "") ?: ""
            tts.voices?.firstOrNull { it.name == n }?.let { tts.setVoice(it) }
            tts.setPitch(p.getFloat("pitch", 0.85f)); tts.setSpeechRate(p.getFloat("rate", 0.95f))
        } catch (e: Exception) {}
    }
    fun voiceList(): List<Voice> = try { tts.voices.filter { it.locale.language in listOf("en", "hi", "ur") }.sortedBy { it.name } } catch (e: Exception) { emptyList() }
    private fun done() { speaking = false; Brain.state = "idle"; listen() }
    fun stopSpeak() { try { tts.stop(); mp?.stop() } catch (e: Exception) {}; done() }
    fun wakeNow() { if (speaking) stopSpeak(); awake = true; ignored = 0; Sound.play("wake"); listen() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "speak") { Sound.play("chime"); val t = i.getStringExtra("text") ?: ""; h.postDelayed({ say(t) }, 900) }
        return START_STICKY
    }
    fun say(t: String) {
        lastTalk = System.currentTimeMillis(); Brain.lastReply = t
        speaking = true; Brain.state = "speaking"; h.post { sr?.cancel() }
        val p = Brain.prefs(this); val k = p.getString("elkey", "") ?: ""; val v = p.getString("elvoice", "") ?: ""
        if (k.isNotEmpty() && v.isNotEmpty()) speakEleven(t, k, v) else speakTts(t)
    }
    private fun speakTts(t: String) { tts.speak(t, TextToSpeech.QUEUE_ADD, null, "j") }
    private fun speakEleven(t: String, key: String, vid: String) {
        thread {
            try {
                val con = URL("https://api.elevenlabs.io/v1/text-to-speech/$vid").openConnection() as HttpURLConnection
                con.requestMethod = "POST"; con.doOutput = true
                con.setRequestProperty("xi-api-key", key); con.setRequestProperty("Content-Type", "application/json")
                con.outputStream.write(JSONObject().put("text", t).put("model_id", "eleven_multilingual_v2").toString().toByteArray())
                if (con.responseCode >= 300) throw Exception("el")
                val f = File(cacheDir, "s.mp3"); f.outputStream().use { con.inputStream.copyTo(it) }
                h.post {
                    mp?.release()
                    mp = MediaPlayer().apply { setDataSource(f.path); setOnCompletionListener { done() }; setOnErrorListener { _, _, _ -> done(); true }; prepare(); start() }
                }
            } catch (e: Exception) { h.post { speakTts(t) } }
        }
    }
    private fun listen() {
        h.post {
            if (speaking) return@post
            Brain.state = if (awake || Brain.waiting()) "listening" else "idle"
            sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    onHeard(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
                    if (!speaking) h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"))
        }
    }
    private fun onHeard(t: String) {
        val l = t.lowercase()
        val wake = l.contains("jarvis") || l.contains("service")
        if (!awake && !wake && !Brain.waiting()) return
        ignored = 0
        val cmd = l.replace(Regex("\\b(hey|hi|jarvis|service)\\b"), "").trim()
        if (cmd == "stop" || cmd == "chup" || cmd == "chup karo") { awake = false; stopSpeak(); return }
        if (cmd.isEmpty()) { awake = true; Sound.play("wake"); say("Ji ${Brain.title(this)}?") }
        else { awake = false; Brain.handle(this, cmd) { say(it) } }
    }
    override fun onDestroy() { inst = null; sr?.destroy(); tts.shutdown() }
}
