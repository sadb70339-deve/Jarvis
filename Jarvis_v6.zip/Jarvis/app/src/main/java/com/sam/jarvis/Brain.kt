package com.sam.jarvis
import android.app.*
import android.content.*
import android.net.Uri
import android.provider.ContactsContract
import org.json.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

object Brain {
    @Volatile var state = "idle"
    @Volatile var lastReply = ""
    @Volatile var pending: (() -> Unit)? = null
    @Volatile var pendingAt = 0L
    @Volatile var convUntil = 0L
    val chat = CopyOnWriteArrayList<Pair<String, String>>()

    fun prefs(c: Context) = c.getSharedPreferences("j", 0)
    fun mode(c: Context) = prefs(c).getString("mode", "normal")!!
    fun title(c: Context) = if (mode(c) == "work") "Sir" else prefs(c).getString("title", "Sir")!!
    fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    fun L(c: Context, en: String, mix: String) = if (prefs(c).getString("lang", "mix") == "english") en else mix

    private fun arr(c: Context, k: String) = JSONArray(prefs(c).getString(k, "[]"))
    fun mem(c: Context) = arr(c, "mem")
    fun addMem(c: Context, s: String) { val a = mem(c); a.put(s); prefs(c).edit().putString("mem", a.toString()).apply() }
    fun delMem(c: Context, i: Int) { val a = mem(c); val b = JSONArray(); for (k in 0 until a.length()) if (k != i) b.put(a.get(k)); prefs(c).edit().putString("mem", b.toString()).apply() }
    fun creator(c: Context): List<String> { val a = arr(c, "cre"); return (0 until a.length()).map { a.getString(it) }.reversed() }
    fun addCreator(c: Context, s: String) {
        val a = arr(c, "cre"); a.put(s); val b = JSONArray(); for (k in maxOf(0, a.length() - 20) until a.length()) b.put(a.get(k))
        prefs(c).edit().putString("cre", b.toString()).apply()
    }
    fun hist(c: Context, s: String) {
        val a = arr(c, "hist"); a.put(JSONObject().put("t", System.currentTimeMillis()).put("x", s))
        val b = JSONArray(); for (k in maxOf(0, a.length() - 80) until a.length()) b.put(a.get(k))
        prefs(c).edit().putString("hist", b.toString()).apply()
    }
    fun histList(c: Context, onlyToday: Boolean): List<String> {
        val a = arr(c, "hist"); val cal = Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        val out = ArrayList<String>(); val f = SimpleDateFormat("dd/MM HH:mm", Locale.US)
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (!onlyToday || o.getLong("t") >= cal.timeInMillis) out.add(f.format(Date(o.getLong("t"))) + "  " + o.getString("x")) }
        return out
    }

    fun rems(c: Context) = arr(c, "rem")
    fun saveRems(c: Context, a: JSONArray) = prefs(c).edit().putString("rem", a.toString()).apply()
    fun addRem(c: Context, h: Int, m: Int, text: String, daily: Boolean) {
        val id = (System.currentTimeMillis() % 100000000).toInt()
        val a = rems(c); a.put(JSONObject().put("id", id).put("h", h).put("m", m).put("text", text).put("daily", daily))
        saveRems(c, a); schedule(c, id, h, m, text, daily)
    }
    fun editRem(c: Context, i: Int, h: Int, m: Int) {
        val a = rems(c); val o = a.getJSONObject(i); o.put("h", h).put("m", m); saveRems(c, a)
        schedule(c, o.getInt("id"), h, m, o.getString("text"), o.getBoolean("daily"))
    }
    fun delRem(c: Context, i: Int) {
        val a = rems(c); val b = JSONArray()
        for (k in 0 until a.length()) if (k != i) b.put(a.get(k)) else cancel(c, a.getJSONObject(k).getInt("id"))
        saveRems(c, b)
    }
    private fun pi(c: Context, id: Int, i: Intent) = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context, id: Int) = (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id, Intent(c, ReminderReceiver::class.java)))
    fun schedule(c: Context, id: Int, h: Int, m: Int, text: String, daily: Boolean) {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val i = Intent(c, ReminderReceiver::class.java).putExtra("id", id).putExtra("text", text).putExtra("h", h).putExtra("m", m).putExtra("daily", daily)
        val p = pi(c, id, i)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, p), p)
    }
    fun addWater(c: Context): Int {
        val p = prefs(c); val n = if (p.getString("wd", "") == today()) p.getInt("w", 0) + 1 else 1
        p.edit().putString("wd", today()).putInt("w", n).apply(); Care.log(c, "water"); hist(c, "Water glass #$n"); return n
    }
    fun water(c: Context) = if (prefs(c).getString("wd", "") == today()) prefs(c).getInt("w", 0) else 0
    fun week(c: Context): Pair<Int, Int> {
        val a = arr(c, "log"); var ok = 0; var no = 0; val wk = System.currentTimeMillis() - 7 * 86400000L
        for (k in 0 until a.length()) { val o = a.getJSONObject(k); if (o.getLong("t") > wk) { if (o.getBoolean("ok")) ok++ else no++ } }
        return ok to no
    }

    fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        c.startActivity(pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true
    }
    private fun web(c: Context, url: String) = c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun confirm(q: String, say: (String) -> Unit, act: () -> Unit) { pending = act; pendingAt = System.currentTimeMillis(); say(q) }
    fun waiting() = pending != null && System.currentTimeMillis() - pendingAt < 60000
    private fun findNumber(c: Context, who: String): String? {
        if (who.matches(Regex("[\\d +]+"))) return who.replace(" ", "")
        var num: String? = null
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$who%"), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
        return num
    }
    private fun callNow(c: Context, who: String, say: (String) -> Unit) {
        val n = findNumber(c, who)
        if (n == null) { say(L(c, "I couldn't find that contact, ${title(c)}.", "Ye contact mujhe nahi mila ${title(c)}.")); return }
        c.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); hist(c, "Call: $who")
        say(L(c, "Calling $who.", "$who ko call laga raha hoon."))
    }
    // Sending a message is an important action, so Jarvis always asks first.
    private fun messageDraft(c: Context, name: String, text: String, say: (String) -> Unit) {
        val n = findNumber(c, name); val t = title(c)
        if (n == null) { say(L(c, "I couldn't find $name in contacts.", "$name contacts mein nahi mila.")); return }
        confirm(L(c, "$t, send this to $name: \"$text\"?", "$t, $name ko ye bhejun: \"$text\"?"), say) {
            c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            hist(c, "Message drafted for $name"); say(L(c, "The message is ready. Just tap send.", "Message ready hai, bas Send dabao."))
        }
    }
    private fun runAct(c: Context, a: String, say: (String) -> Unit) {
        val p = a.split("|").map { it.trim() }; val arg = p.getOrElse(1) { "" }
        when (p[0].lowercase()) {
            "open" -> { val ok = openApp(c, arg.lowercase()); hist(c, if (ok) "Opened $arg" else "Failed to open $arg"); if (!ok) say(L(c, "I couldn't find $arg.", "$arg mujhe mila nahi.")) }
            "youtube" -> { web(c, "https://www.youtube.com/results?search_query=" + enc(arg)); hist(c, "YouTube: $arg") }
            "search" -> { web(c, "https://www.google.com/search?q=" + enc(arg)); hist(c, "Search: $arg") }
            "call" -> callNow(c, arg, say)
            "water" -> addWater(c)
            "message" -> messageDraft(c, arg, p.getOrElse(2) { "" }, say)
            "remind" -> {
                val m = Regex("(\\d{1,2}):(\\d{2})").find(arg)
                if (m != null) { val tx = p.getOrElse(2) { "reminder" }; addRem(c, m.groupValues[1].toInt(), m.groupValues[2].toInt(), tx, false); hist(c, "Reminder: $tx at $arg") }
            }
        }
    }

    fun handle(c: Context, raw: String, say0: (String) -> Unit) {
        val q = raw.lowercase().trim(); val p = prefs(c)
        chat.add("YOU" to raw); if (chat.size > 60) chat.removeAt(0)
        convUntil = System.currentTimeMillis() + 60000
        val say: (String) -> Unit = { lastReply = it; chat.add("JARVIS" to it); say0(it) }
        val t = title(c)
        val act = pending
        if (act != null) {
            pending = null
            if (System.currentTimeMillis() - pendingAt < 60000 && q.length < 25) {
                if (Regex("\\b(nahi|nahin|no|nope|don't|dont|cancel|never mind|mat|rehne do)\\b").containsMatchIn(q)) { say(L(c, "Okay $t, cancelled.", "Theek hai $t, rehne dete hain.")); return }
                if (Regex("\\b(haan|han|ha|yes|yeah|yep|ok|okay|sure|do it|go ahead|please|kar do|kardo|theek hai|bilkul)\\b").containsMatchIn(q)) { act(); return }
            }
        }
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(q)
        val modes = Regex("work|normal|friend|creator|silent|sleep|dnd")
        val rem = Regex("(remember( this| that)?|yaad rakh(o|na))[: ]*").find(q)
        val forget = Regex("(forget( this| that)?|bhool jao|bhul jao)[: ]*").find(q)
        val msg = Regex("^(message|msg|text|sms)\\s+(?:to\\s+)?(\\w+)\\s+(.+)$").find(q)
        when {
            rem != null -> { val f = q.substring(rem.range.last + 1).trim(); addMem(c, f); hist(c, "Memory saved: $f"); say(L(c, "Got it, $t. I'll remember that.", "Theek hai $t, maine yaad rakh liya.")) }
            forget != null -> {
                val k = q.substring(forget.range.last + 1).trim(); val a = mem(c); var n = 0; val b = JSONArray()
                for (i in 0 until a.length()) { if (k.isNotEmpty() && a.getString(i).lowercase().contains(k)) n++ else b.put(a.get(i)) }
                p.edit().putString("mem", b.toString()).apply(); say(if (n > 0) L(c, "Forgotten, $t.", "Bhula diya $t.") else L(c, "I couldn't find that in memory.", "Ye memory mein mila hi nahi."))
            }
            q.contains("mode") && modes.containsMatchIn(q) -> {
                val x = modes.find(q)!!.value; val mm = if (x == "dnd" || x == "sleep") "silent" else x
                p.edit().putString("mode", mm).apply(); hist(c, "Mode: $mm"); say(L(c, "Okay ${title(c)}, $mm mode is on.", "Okay ${title(c)}, ab $mm mode on hai."))
            }
            q.contains("only english") || q.contains("speak english") || q.contains("english mein") -> { p.edit().putString("lang", "english").apply(); say("Understood. I'll speak only English.") }
            q.contains("roman urdu") -> { p.edit().putString("lang", "roman").apply(); say("Theek hai $t, ab Roman Urdu mein baat karte hain.") }
            q.contains("hindi") && Regex("baat|bolo|mein|speak").containsMatchIn(q) -> { p.edit().putString("lang", "hindi").apply(); say("Theek hai $t, ab Hindi mein baat karenge.") }
            q.contains("what did i do") || q.contains("kya kya karwaya") || q.contains("history") -> {
                val l = histList(c, true)
                say(if (l.isEmpty()) L(c, "Nothing yet today, $t.", "Abhi tak aaj kuch nahi hua $t.") else L(c, "Today I did ${l.size} things. Latest: ", "Aaj maine ${l.size} kaam kiye. Aakhri: ") + l.takeLast(3).joinToString(". ") { it.substring(12) })
            }
            Regex("khana kha li|had (breakfast|lunch|dinner)|i ate|ate (breakfast|lunch|dinner)|nashta kar li").containsMatchIn(q) -> { Care.logMeal(c); hist(c, "Meal logged"); say(L(c, "Nice, noted. Eat well, $t.", "Achha kiya $t, note kar liya.")) }
            Regex("(workout|gym|walk|exercise) (done|kar li)|worked out").containsMatchIn(q) -> { Care.log(c, "workout"); hist(c, "Workout done"); say(L(c, "Great job, $t! Workout noted.", "Shabash $t! Workout note kar liya.")) }
            (q.contains("water") || q.contains("paani")) && Regex("drank|drink|had|\\bpi\\b|piya|pee|liya").containsMatchIn(q) -> {
                val n = addWater(c); say(L(c, "Nice, $t. That's $n glasses today.", "Shabash $t, aaj $n glass ho gaye."))
            }
            q.contains("reminder") || q.contains("alarm") || q.contains("remind me") || (q.contains("yaad") && m != null) -> {
                if (m == null) { say(L(c, "What time, $t?", "Kitne baje $t?")); return }
                var h = m.groupValues[1].toInt(); val mi = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (Regex("pm|shaam|raat|dopahar|evening|night").containsMatchIn(q) && h < 12) h += 12
                val txt = q.replace(Regex("\\b(reminder|alarm|remind|me|to|at|yaad|dilao|dilana|laga|do|lagao|baje|am|pm|roz|daily|every|day|subah|shaam|raat|dopahar|ka|ki|ke|ko|mujhe|set|kar|karo)\\b|\\d{1,2}(:\\d{2})?"), " ").replace(Regex("\\s+"), " ").trim().ifEmpty { "reminder" }
                addRem(c, h, mi, txt, Regex("roz|daily|har din|every day").containsMatchIn(q))
                hist(c, "Reminder: $txt at $h:%02d".format(mi))
                say(L(c, "Done, $t. I'll remind you at $h:%02d: $txt.".format(mi), "Theek hai $t, $h:%02d baje $txt yaad dilaunga.".format(mi)))
            }
            q.contains("youtube") && Regex("search|chalao|play|dhundo|lagao").containsMatchIn(q) -> {
                val k = q.replace(Regex("\\b(youtube|pe|par|on|search|chalao|play|dhundo|lagao|karo|video|ka|ki|ke|ko|mujhe|for)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                web(c, "https://www.youtube.com/results?search_query=" + enc(k)); hist(c, "YouTube: $k"); say(L(c, "Opening YouTube for $k.", "$k ke liye YouTube khol raha hoon."))
            }
            msg != null -> messageDraft(c, msg.groupValues[2], msg.groupValues[3], say)
            q.contains("search") || q.contains("dhundo") -> {
                val k = q.replace(Regex("\\b(search|dhundo|google|pe|par|karo|for|on)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                web(c, "https://www.google.com/search?q=" + enc(k)); hist(c, "Search: $k"); say(L(c, "Searching for $k.", "$k search kar raha hoon."))
            }
            Regex("\\b(kholo|khol|open|launch)\\b").containsMatchIn(q) -> {
                val n = q.replace(Regex("\\b(kholo|khol|open|launch|do|na|please|the|app)\\b"), "").replace(Regex("\\s+"), " ").trim()
                val ok = openApp(c, n); hist(c, if (ok) "Opened $n" else "Failed to open $n")
                say(if (ok) L(c, "Opening $n.", "$n khol raha hoon.") else L(c, "I couldn't find $n.", "$n mujhe mila nahi."))
            }
            q.contains("call") -> callNow(c, q.replace(Regex("\\b(call|karo|lagao|laga|ko|do|please|to)\\b"), "").replace(Regex("\\s+"), " ").trim(), say)
            q.startsWith("kaam kiya") || q.startsWith("task done") || q.startsWith("kaam nahi") || q.startsWith("task missed") -> {
                val ok = q.startsWith("kaam kiya") || q.startsWith("task done")
                val a = JSONArray(p.getString("log", "[]")); a.put(JSONObject().put("t", System.currentTimeMillis()).put("ok", ok).put("x", q))
                p.edit().putString("log", a.toString()).apply(); hist(c, q); say(L(c, "Noted, $t.", "Note kar liya $t."))
            }
            q.contains("report") -> { val (ok, no) = week(c); say(L(c, "$t, this week: $ok tasks done and $no missed. Water today: ${water(c)} glasses.", "$t, is hafte $ok kaam hue aur $no nahi hue. Aaj paani ${water(c)} glass.")) }
            q.contains("time") && q.length < 25 -> { val x = SimpleDateFormat("h:mm a", Locale.US).format(Date()); say(L(c, "It's $x, $t.", "Abhi $x ho rahe hain, $t.")) }
            q.contains("instagram") && Regex("ready|caption|post|hashtag|draft").containsMatchIn(q) -> {
                ask(c, raw, say, 500, "Prepare an Instagram post for this request: $raw. Give: 1) Caption (English motivational quote + Roman Urdu meaning) 2) Cover text (max 6 words) 3) 8 hashtags. Compact.") { r ->
                    chat.add("JARVIS" to r); addCreator(c, r)
                    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", r))
                    hist(c, "Instagram draft prepared"); lastReply = "Draft ready"
                    pending = { val ok = openApp(c, "instagram"); hist(c, if (ok) "Opened Instagram" else "Instagram open failed"); say(if (ok) L(c, "Opened Instagram. Paste the caption.", "Instagram khol diya, caption paste kar do.") else L(c, "Instagram isn't installed.", "Instagram install nahi hai.")) }
                    pendingAt = System.currentTimeMillis()
                    say0(L(c, "$t, the caption, cover text and hashtags are ready and copied. Want me to open Instagram?", "$t, caption, cover aur hashtags ready hain aur copy ho gaye. Instagram khol doon?"))
                }
            }
            else -> ask(c, raw, say)
        }
    }

    fun ask(c: Context, q: String, say: (String) -> Unit, max: Int = 160, prompt: String = q, onText: ((String) -> Unit)? = null) {
        val p = prefs(c); val prov = p.getString("provider", "gemini")!!
        val key = (if (prov == "gemini") p.getString("gkey", "") else p.getString("key", ""))!!
        if (key.isEmpty()) { say(L(c, "Please add your AI key in Setup, ${title(c)}.", "Setup mein AI key daal do ${title(c)}.")); return }
        state = "thinking"
        thread {
            try {
                val msgs = JSONArray(); var last = ""
                for ((who, txt) in chat.takeLast(7)) {
                    val role = if (who == "YOU") "user" else "assistant"
                    if (role == last) { val o = msgs.getJSONObject(msgs.length() - 1); o.put("content", o.getString("content") + "\n" + txt) }
                    else if (msgs.length() > 0 || role == "user") { msgs.put(JSONObject().put("role", role).put("content", txt)); last = role }
                }
                if (msgs.length() == 0 || last != "user") msgs.put(JSONObject().put("role", "user").put("content", q))
                msgs.getJSONObject(msgs.length() - 1).put("content", prompt)
                val tone = when (mode(c)) {
                    "work" -> "Work mode: serious, concise, professional. Address the user as Sir or Boss. No jokes."
                    "creator" -> "Creator mode: focused, practical, creative. Help with video ideas, hooks, scripts, English motivational quotes with Roman Urdu meaning, captions, cover text, hashtags."
                    "friend" -> "Friend mode: casual and playful, light humour when suitable. Call the user ${title(c)}."
                    else -> "Normal mode: friendly and relaxed. Call the user ${title(c)}."
                }
                val lang = when (p.getString("lang", "mix")) {
                    "english" -> "Reply only in English, warm and natural."
                    "roman" -> "Reply in Roman Urdu (Urdu written in English letters)."
                    "hindi" -> "Reply in Hinglish (Hindi in English letters)."
                    else -> "Speak like a warm close friend and assistant in a natural mix of simple Roman Urdu and basic English words (like 'Good evening', 'okay', 'sure', 'plan', 'reminder'). Not too much Urdu, never formal or robotic. Short natural spoken sentences with feeling; vary your phrasing. No bullet points, no emojis."
                }
                val prof = "User profile: name ${p.getString("uname", "")}, fitness goal ${p.getString("fgoal", "")}, food preference ${p.getString("food", "")}, about: ${p.getString("about", "")}."
                val sys = "You are JARVIS, a calm, confident, mature male AI assistant inspired by Iron Man's JARVIS, living on the user's Android phone. $tone $lang Keep replies to 1-2 short sentences unless asked for detail. If the user seems sad, stressed or upset: be soft and patient, listen first, ask what happened, no jokes, no lectures. You understand what the user means without exact commands. You can control the phone: ONLY when the user asks or clearly implies it, add action tags at the very end of your reply, one per line: [[ACT: open|app name]], [[ACT: youtube|search words]], [[ACT: search|query]], [[ACT: call|contact name]], [[ACT: remind|HH:MM 24h|text]], [[ACT: water]], [[ACT: message|contact name|message text]]. Example: user says 'cricket dekhna hai' -> short reply + [[ACT: youtube|cricket highlights]]. Never claim an action succeeded. $prof Saved memories about the user: ${mem(c)}. If the user's message reveals something important and lasting (goal, routine, preference, important person or project), end your reply with [[SAVE: short fact]]."
                val txt: String
                if (prov == "gemini") {
                    val contents = JSONArray()
                    for (k in 0 until msgs.length()) { val o = msgs.getJSONObject(k)
                        contents.put(JSONObject().put("role", if (o.getString("role") == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", o.getString("content"))))) }
                    val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                        .put("contents", contents).put("generationConfig", JSONObject().put("maxOutputTokens", max + 1500))
                    val model = p.getString("gmodel", "gemini-flash-latest")!!
                    val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"; con.doOutput = true
                    con.setRequestProperty("x-goog-api-key", key); con.setRequestProperty("Content-Type", "application/json")
                    con.outputStream.write(body.toString().toByteArray())
                    val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                    txt = JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                } else {
                    val body = JSONObject().put("model", "claude-haiku-4-5-20251001").put("max_tokens", max).put("system", sys).put("messages", msgs)
                    val con = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"; con.doOutput = true
                    con.setRequestProperty("x-api-key", key); con.setRequestProperty("anthropic-version", "2023-06-01"); con.setRequestProperty("content-type", "application/json")
                    con.outputStream.write(body.toString().toByteArray())
                    val r = (if (con.responseCode < 300) con.inputStream else con.errorStream).bufferedReader().readText()
                    txt = JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
                }
                val fact = Regex("\\[\\[SAVE:(.*?)\\]\\]").find(txt)?.groupValues?.get(1)?.trim() ?: ""
                val acts = Regex("\\[\\[ACT:(.*?)\\]\\]").findAll(txt).map { it.groupValues[1] }.toList()
                val clean = txt.replace(Regex("\\[\\[(SAVE|ACT):.*?\\]\\]"), "").trim()
                state = "idle"
                if (onText != null) onText(clean)
                else {
                    if (fact.isNotEmpty()) {
                        pending = { addMem(c, fact); hist(c, "Memory saved: $fact"); say(L(c, "Saved to memory.", "Memory mein save kar liya.")) }; pendingAt = System.currentTimeMillis()
                        say(L(c, "$clean Also, ${title(c)}, this seems important: $fact. Should I save it to memory?", "$clean Aur ${title(c)}, ye important lag raha hai: $fact. Memory mein save kar loon?"))
                    } else say(clean)
                    acts.forEach { runAct(c, it, say) }
                }
            } catch (e: Exception) { state = "idle"; say(L(c, "I couldn't reach the AI. Please check your key and model in Setup.", "AI se baat nahi ho pa rahi. Setup mein key aur model check kar lo ${title(c)}.")) }
        }
    }
}
